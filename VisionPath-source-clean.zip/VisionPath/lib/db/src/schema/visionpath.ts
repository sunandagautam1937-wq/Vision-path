import {
  doublePrecision,
  index,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export interface StoredFamilyContact {
  id: string;
  name: string;
  phone: string;
}

export const visionPathProfiles = pgTable("visionpath_profiles", {
  clerkUserId: text("clerk_user_id").primaryKey(),
  name: varchar("name", { length: 80 }).notNull(),
  heightCm: doublePrecision("height_cm").notNull(),
  ukShoeSize: doublePrecision("uk_shoe_size").notNull(),
  familyContacts: jsonb("family_contacts")
    .$type<StoredFamilyContact[]>()
    .notNull()
    .default([]),
  updatedAt: timestamp("updated_at", { withTimezone: true, mode: "date" })
    .notNull()
    .defaultNow(),
});

export const visionPathLocations = pgTable("visionpath_locations", {
  clerkUserId: text("clerk_user_id")
    .primaryKey()
    .references(() => visionPathProfiles.clerkUserId, { onDelete: "cascade" }),
  lat: doublePrecision("lat").notNull(),
  lng: doublePrecision("lng").notNull(),
  accuracyM: doublePrecision("accuracy_m").notNull(),
  capturedAt: timestamp("captured_at", { withTimezone: true, mode: "date" }).notNull(),
});

export const visionPathShareTokens = pgTable(
  "visionpath_share_tokens",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    clerkUserId: text("clerk_user_id")
      .notNull()
      .references(() => visionPathProfiles.clerkUserId, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    label: varchar("label", { length: 80 }).notNull().default("Family access"),
    createdAt: timestamp("created_at", { withTimezone: true, mode: "date" })
      .notNull()
      .defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true, mode: "date" }).notNull(),
    revokedAt: timestamp("revoked_at", { withTimezone: true, mode: "date" }),
  },
  (table) => [
    uniqueIndex("visionpath_share_tokens_hash_uq").on(table.tokenHash),
    index("visionpath_share_tokens_owner_idx").on(table.clerkUserId),
  ],
);

export const visionPathSosAlerts = pgTable(
  "visionpath_sos_alerts",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    clerkUserId: text("clerk_user_id")
      .notNull()
      .references(() => visionPathProfiles.clerkUserId, { onDelete: "cascade" }),
    lat: doublePrecision("lat"),
    lng: doublePrecision("lng"),
    message: text("message").notNull(),
    deliveryStatus: varchar("delivery_status", { length: 24 })
      .notNull()
      .default("recorded"),
    createdAt: timestamp("created_at", { withTimezone: true, mode: "date" })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("visionpath_sos_alerts_owner_created_idx").on(table.clerkUserId, table.createdAt)],
);
