# VisionPath – run locally on Windows (no Replit needed)

Everything below uses the project's real commands and ports.
**Frontend:** http://localhost:5173/  **API:** http://localhost:8080/api (the frontend proxies `/api` to it).

> Internet is required while running: Clerk sign-in, the object-detection model download, map tiles, routing and place search all use online services (listed at the end).

## 1. Install the prerequisites (one time)
1. **Node.js 20.19 or newer** (22 LTS recommended): https://nodejs.org. Check: `node -v`
2. **pnpm 10** (this project uses pnpm and its `pnpm-lock.yaml`): open PowerShell and run `npm install -g pnpm@10`. Check: `pnpm -v`
3. **Google Chrome**.
4. **A PostgreSQL database** – pick ONE:
   - **A. Hosted (easiest):** free project at https://neon.tech → copy its connection string.
   - **B. Docker Desktop:** `docker compose up -d` in the project folder (uses `docker-compose.yml`).
   - **C. Installed PostgreSQL 16:** https://www.postgresql.org/download/windows/ → create a database named `visionpath`.
5. **A Clerk account** (free): https://dashboard.clerk.com → create an application (enable Email or Google sign-in) → open **API keys** → copy the *Publishable key* (`pk_test_…`) and *Secret key* (`sk_test_…`). Use the **development** instance; it works on localhost.

## 2. Extract and open
Extract `VisionPath_Local_Ready.zip` (e.g. to `C:\VisionPath`). Open the `VisionPath` folder in VS Code → **Terminal → New Terminal**, or in File Explorer type `powershell` in the address bar.

## 3. Install dependencies
```powershell
pnpm install
```

## 4. Configure environment variables
```powershell
copy .env.example .env
notepad .env
```
Fill in:

| Variable | Meaning |
|---|---|
| `VITE_CLERK_PUBLISHABLE_KEY` | Clerk publishable key (`pk_test_…`) |
| `CLERK_SECRET_KEY` | Clerk secret key (`sk_test_…`) – keep private |
| `DATABASE_URL` | PostgreSQL URL, e.g. `postgresql://postgres:postgres@localhost:5432/visionpath` (Docker/local) or the Neon string |
| `API_PORT`, `FRONTEND_PORT` | optional, defaults 8080 / 5173 |
| `VITE_CLERK_PROXY_URL` | leave empty on localhost |

`.env` is ignored by git and is not in the ZIP. Never share real keys.
Check your settings without starting anything: `pnpm check:env`

## 5. Create the database tables (first time only)
```powershell
pnpm db:push
```
If it prints an error about the connection, fix `DATABASE_URL` first (see Troubleshooting).

## 6. Start the app (frontend + API together)
```powershell
pnpm dev
```
(or double-click `start-visionpath.bat`, which installs if needed and then runs `pnpm dev`).
Wait for: `API health: OK. Database: connected` and the line `Open in Chrome: http://localhost:5173/`.

## 7. Open in Chrome
Go to **http://localhost:5173/** → sign in → complete onboarding → your profile is saved to the database.
When Chrome asks, click **Allow** for **Location** and **Camera**. Both work on `http://localhost`.

## 8. Stop / restart
Press **Ctrl+C** in the terminal (it stops both servers). Start again with `pnpm dev`. Data stays in the database.

## Quick checks (optional)
- API alive: http://localhost:8080/api/healthz → `{"status":"ok"}`
- Database reachable: http://localhost:8080/api/readyz → `"database":"connected"`
- Tests: `pnpm --filter @workspace/vision-path test`  (and `pnpm --filter @workspace/api-server test`)
- Typecheck: `pnpm typecheck`   Production build: `pnpm build`

## Troubleshooting
| Problem | Fix |
|---|---|
| `pnpm` is not recognized | Reopen the terminal after `npm install -g pnpm@10`. |
| `Use pnpm instead` / install errors | Use `pnpm install`, not `npm install`. |
| Node version error from Vite | Install Node 20.19+ (`node -v`). |
| `Missing required settings` | Edit `.env`; values containing `replace_me` count as missing. |
| `Port 5173/8080 is already in use` | Close the old window, or change `FRONTEND_PORT` / `API_PORT` in `.env`. |
| "…could not reach the VisionPath server" | The API is not running. Look at the terminal for the API error. |
| "…API server is not responding (HTTP 500)" | API crashed or the proxy cannot reach it. Restart `pnpm dev`; read the terminal. |
| "…did not accept your sign-in (HTTP 401)" | Wrong/mismatched Clerk keys (both must be from the same Clerk app). Sign out/in. |
| "…server reported an error (HTTP 5xx)" | Usually the database: open `/api/readyz`; run `pnpm db:push`. |
| `relation "visionpath_profiles" does not exist` | Run `pnpm db:push`. |
| Database connection refused | Start PostgreSQL/Docker (`docker compose up -d`). For Neon keep `?sslmode=require` in the URL. |
| Sign-in page blank | Check `VITE_CLERK_PUBLISHABLE_KEY`; restart `pnpm dev` after editing `.env`. |
| Camera does not start | Chrome → lock icon → allow Camera; close other apps using the camera; first load needs internet for the model. |
| Location denied/unavailable | Allow Location in Chrome and Windows *Settings → Privacy → Location*. Indoors accuracy may be poor; navigation needs ≤50 m accuracy. |
| No voice for Hindi/other language | Windows must have that language's speech voice installed (*Settings → Time & language → Speech*); English voice is the fallback button. |

## Services, credentials and internet
| Service | Needs | Used for |
|---|---|---|
| Clerk | account + 2 keys, internet | sign-in / sessions |
| PostgreSQL | `DATABASE_URL` (local or hosted) | profile, locations, share links, SOS records |
| TensorFlow.js COCO-SSD model | internet on first camera start | object detection (runs in browser) |
| OpenStreetMap (tiles), OSRM, Nominatim, unpkg (Leaflet) | internet | map, walking routes, place search |

## Replit
Replit still works: its Secrets can hold the same variables, and `.replit` is unchanged.
