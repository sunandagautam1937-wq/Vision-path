# VisionPath final handoff and Replit testing guide

## What has been checked in this handoff

- ZIP integrity check passed.
- Existing route/language unit tests: 8 passed, 0 failed.
- The repository is a pnpm workspace. Use pnpm; the root preinstall intentionally rejects npm/yarn installs.
- Full TypeScript check and production build have not been verified in this environment because dependencies could not be installed (registry DNS/network unavailable).
- Real-device GPS, camera/model inference, SOS/database integration, actual SMS delivery, and Android TalkBack/TTS have not been verified here.

## Replit import and run

1. Upload/import this ZIP into a new Replit project. Keep the folder structure intact.
2. Let Replit detect the existing Node.js/pnpm workspace. If it asks for a command, use `pnpm install` and then run the VisionPath app's dev script from `artifacts/vision-path` (`pnpm dev`). The workspace config already exposes the app's configured Vite port.
3. If dependency installation fails, inspect Replit's install log first; do not switch to `npm install` because the repository intentionally uses pnpm and workspace dependencies.
4. The authentication screen requires a real Clerk publishable key and matching backend configuration. Do not put private/server secrets in client-side variables or commit them. API-backed features need the configured PostgreSQL database and schema.
5. Open the app through Replit's web preview. Camera and GPS APIs generally require a secure HTTPS origin and explicit browser permission.

## TalkBack note (important)

Android TalkBack is an operating-system screen reader; it is not implemented by this web app. VisionPath uses browser `speechSynthesis` for its own route/object narration, which is a separate audio path. If TalkBack is toggled on but touch still behaves normally and nothing is spoken, the TalkBack accessibility service or Android text-to-speech/audio setup may not be active correctly. A web-app code change cannot repair a disabled or broken Android service.

On the Android tablet, test TalkBack outside VisionPath first: enable TalkBack in Android Accessibility settings and tap a Settings item once. TalkBack should focus and announce it; double-tap activates it, and two-finger swipes scroll. If no Android screen speaks, check the selected TalkBack service, the Text-to-speech engine/voice data, media/accessibility volume, Bluetooth output, then restart the tablet. Test VisionPath's separate **Test voice** control only after the OS screen reader itself speaks.

## Safety limitations

- Object detection can miss or misidentify objects and cannot reliably estimate collision distance; it must not be the only mobility aid.
- SOS recording is not the same as sending an emergency alert. SMS/WhatsApp links require the user to review and send the message; no automatic emergency-service dispatch is claimed.
- Verify all features on a real device and with configured services before relying on them.
