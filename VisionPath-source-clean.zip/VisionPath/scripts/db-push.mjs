// Creates/updates the database tables:  pnpm db:push
import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";
import path from "node:path";
import { ROOT, loadEnv } from "./env.mjs";

loadEnv();
if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL is not set. Add it to .env (see .env.example).");
  process.exit(1);
}
const dbDir = path.join(ROOT, "lib", "db");
let bin;
try {
  const req = createRequire(path.join(dbDir, "package.json"));
  bin = path.join(path.dirname(req.resolve("drizzle-kit/package.json")), "bin.cjs");
} catch {
  console.error("drizzle-kit not found. Run `pnpm install` first.");
  process.exit(1);
}
const r = spawnSync(process.execPath, [bin, "push", "--config", "./drizzle.config.ts"], { cwd: dbDir, stdio: "inherit", env: process.env });
process.exit(r.status ?? 1);
