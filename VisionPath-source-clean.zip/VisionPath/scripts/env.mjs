// Tiny .env loader (no dependencies). Values already present in the real environment win.
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

export function loadEnv() {
  const file = path.join(ROOT, ".env");
  const loaded = existsSync(file);
  if (loaded) {
    for (const rawLine of readFileSync(file, "utf8").split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line || line.startsWith("#")) continue;
      const eq = line.indexOf("=");
      if (eq < 1) continue;
      const key = line.slice(0, eq).trim();
      let value = line.slice(eq + 1).trim();
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      if (value !== "" && process.env[key] === undefined) process.env[key] = value;
    }
  }
  return loaded;
}

export function checkEnv() {
  if (!process.env.CLERK_PUBLISHABLE_KEY && process.env.VITE_CLERK_PUBLISHABLE_KEY) {
    process.env.CLERK_PUBLISHABLE_KEY = process.env.VITE_CLERK_PUBLISHABLE_KEY;
  }
  const required = {
    VITE_CLERK_PUBLISHABLE_KEY: "Clerk publishable key (pk_test_...), from dashboard.clerk.com > API keys",
    CLERK_SECRET_KEY: "Clerk secret key (sk_test_...), from dashboard.clerk.com > API keys",
    DATABASE_URL: "PostgreSQL connection string, e.g. postgresql://user:password@localhost:5432/visionpath",
  };
  const missing = Object.entries(required).filter(([k]) => !process.env[k] || process.env[k].includes("replace_me"));
  const warnings = [];
  const pk = process.env.VITE_CLERK_PUBLISHABLE_KEY ?? "";
  if (pk && !/^pk_(test|live)_/.test(pk)) warnings.push("VITE_CLERK_PUBLISHABLE_KEY does not look like a Clerk key (expected pk_test_... or pk_live_...).");
  const sk = process.env.CLERK_SECRET_KEY ?? "";
  if (sk && !/^sk_(test|live)_/.test(sk)) warnings.push("CLERK_SECRET_KEY does not look like a Clerk key (expected sk_test_... or sk_live_...).");
  if (pk.startsWith("pk_live_")) warnings.push("A live Clerk key will not work on localhost. Use a development (pk_test_) instance for the demo.");
  return { missing, warnings, required };
}
