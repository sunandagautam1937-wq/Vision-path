// One-command local start for Windows/macOS/Linux:  pnpm dev
// Builds and starts the API (default :8080) and the Vite frontend (default :5173).
import { spawn, spawnSync } from "node:child_process";
import { createRequire } from "node:module";
import net from "node:net";
import path from "node:path";
import { ROOT, checkEnv, loadEnv } from "./env.mjs";

const hasEnvFile = loadEnv();
const { missing, warnings } = checkEnv();
const API_PORT = Number(process.env.API_PORT ?? 8080);
const WEB_PORT = Number(process.env.FRONTEND_PORT ?? 5173);
const checkOnly = process.argv.includes("--check");
const api = path.join(ROOT, "artifacts", "api-server");
const web = path.join(ROOT, "artifacts", "vision-path");

console.log(`\nVisionPath local launcher  (Node ${process.version}, ${process.platform})`);
console.log(`.env file: ${hasEnvFile ? "found" : "NOT found (copy .env.example to .env)"}`);
for (const w of warnings) console.log(`WARNING: ${w}`);
if (missing.length) {
  console.error("\nMissing required settings:");
  for (const [k, why] of missing) console.error(`  - ${k}: ${why}`);
  console.error("\nEdit the .env file in the project root, then run again. See README_LOCAL.md.");
  process.exit(1);
}
console.log("Required environment variables: all present (values not printed).");
if (checkOnly) process.exit(0);

const freePort = (port) => new Promise((resolve) => {
  const srv = net.createServer();
  srv.once("error", () => resolve(false));
  srv.once("listening", () => srv.close(() => resolve(true)));
  srv.listen(port, "0.0.0.0");
});
for (const [name, port] of [["API", API_PORT], ["Frontend", WEB_PORT]]) {
  if (!(await freePort(port))) {
    console.error(`\nPort ${port} (${name}) is already in use. Close the other VisionPath window or change ${name === "API" ? "API_PORT" : "FRONTEND_PORT"} in .env.`);
    process.exit(1);
  }
}

console.log("\n[1/3] Building API server...");
const build = spawnSync(process.execPath, ["build.mjs"], { cwd: api, stdio: "inherit", env: process.env });
if (build.status !== 0) {
  console.error("API build failed. Did you run `pnpm install`?");
  process.exit(1);
}

const children = [];
let stopping = false;
function stopAll(code = 0) {
  if (stopping) return;
  stopping = true;
  for (const child of children) {
    if (child.exitCode !== null) continue;
    if (process.platform === "win32") spawnSync("taskkill", ["/pid", String(child.pid), "/T", "/F"], { stdio: "ignore" });
    else child.kill("SIGTERM");
  }
  setTimeout(() => process.exit(code), 300);
}
process.on("SIGINT", () => stopAll(0));
process.on("SIGTERM", () => stopAll(0));

function run(name, args, cwd, env) {
  const child = spawn(process.execPath, args, { cwd, stdio: "inherit", env: { ...process.env, ...env } });
  child.on("exit", (code) => {
    if (!stopping) {
      console.error(`\n${name} stopped unexpectedly (exit code ${code}). Stopping everything.`);
      stopAll(1);
    }
  });
  children.push(child);
}

console.log("[2/3] Starting API server on port " + API_PORT + "...");
run("API server", ["--enable-source-maps", "dist/index.mjs"], api, { NODE_ENV: "development", PORT: String(API_PORT) });

let viteBin;
try {
  const req = createRequire(path.join(web, "package.json"));
  viteBin = path.join(path.dirname(req.resolve("vite/package.json")), "bin", "vite.js");
} catch {
  console.error("Could not find Vite. Run `pnpm install` first.");
  stopAll(1);
}
console.log("[3/3] Starting frontend on port " + WEB_PORT + "...");
run("Frontend", [viteBin, "--config", "vite.config.ts", "--host", "0.0.0.0"], web, { PORT: String(WEB_PORT), API_PORT: String(API_PORT), NODE_ENV: "development" });

// Report readiness so a broken database is visible immediately instead of as a vague profile error.
const base = `http://127.0.0.1:${API_PORT}/api`;
for (let i = 0; i < 40; i += 1) {
  await new Promise((r) => setTimeout(r, 750));
  try {
    const h = await fetch(`${base}/healthz`);
    if (!h.ok) continue;
    const r = await fetch(`${base}/readyz`);
    const body = await r.json().catch(() => ({}));
    console.log(`\nAPI health: OK.  Database: ${r.ok ? "connected" : "NOT reachable - " + (body.error ?? "check DATABASE_URL and run `pnpm db:push`")}`);
    console.log(`\n  Open in Chrome:  http://localhost:${WEB_PORT}/\n  Stop with Ctrl+C.\n`);
    break;
  } catch { /* API still starting */ }
}
