// Cross-platform replacement for the old `sh -c` preinstall hook (which fails on Windows cmd/PowerShell).
import { rmSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const agent = process.env.npm_config_user_agent ?? "";
if (!agent.startsWith("pnpm/")) {
  console.error("This project uses pnpm. Install it with:  npm install -g pnpm   then run:  pnpm install");
  process.exit(1);
}
for (const file of ["package-lock.json", "yarn.lock"]) rmSync(path.join(root, file), { force: true });
