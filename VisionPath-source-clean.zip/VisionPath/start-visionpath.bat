@echo off
cd /d "%~dp0"
where pnpm >nul 2>nul || (echo pnpm not found. Run: npm install -g pnpm & pause & exit /b 1)
if not exist node_modules (echo Installing dependencies... & call pnpm install || (pause & exit /b 1))
if not exist .env (echo .env not found. Copy .env.example to .env and fill it in. & pause & exit /b 1)
call pnpm dev
pause
