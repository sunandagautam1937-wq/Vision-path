# VisionPath — PROGRESS

## Pass: TalkBack/screen-reader accessibility + new cane logo (2026-10-29)

### Already present (inspected, kept)
Semantic `<main>`/`<h1>`, labelled buttons, countdown `role="timer"`, loading/error live regions in the camera detector, speech priority queue with per-object cooldown, TalkBackContext as a plain passthrough (no custom double-tap, so native TalkBack gestures are untouched).

### Changes
- `components/RouteAnnouncer.tsx` (new): "Skip to main content" link (visible on keyboard focus), two hidden live regions (polite/assertive), per-route `document.title`, and focus moved to the page heading on route change so the new screen is read.
- `utils/announce.ts` (new): `announce(message, politeness)` helper.
- `pages/Navigation.tsx`: added `<h1>` (sr-only); announcements for GPS found/waiting, searching/route ready/started/arrived/stopped, camera detection on/off; error/offline box changed from `aria-live="off"` (silent) to `role="alert"`; text fallback of the current step via live region **only** when in-app voice is not available (avoids double speech with TalkBack).
- `pages/Onboarding.tsx`: welcome screen wrapper `<div>` → `<main>`.
- `components/CaneLogo.tsx` (new) + `public/logo.svg` + `public/favicon.svg`: replaced the old hook/"?" symbol (and the plain orange favicon square) with a minimal white-cane mark (grip, shaft, banded tip, ground sweep) on the existing dark-theme gold-green tile. Alt text: "VisionPath logo: white cane". Used in AuthLanding and Onboarding (previously `aria-hidden`).
- Not changed: speech.ts (already queues, de-duplicates by priority, and 12 s cooldown per obstacle label/zone), SOS page, other pages.

### Follow-up fixes (2026-10-29, second pass)
- `RouteAnnouncer`: removed duplicate "<screen> screen" announcement when a heading receives focus (TalkBack already reads it); first-load/StrictMode re-run no longer steals focus; added CSS so programmatic focus on `[tabindex="-1"]` shows no big outline.
- `Navigation`: removed live-region "Navigation started"/"You have arrived" (already spoken by in-app voice); camera on/off announcement no longer fires on page load.
- `RouteAnnouncer` uses `type MouseEvent` import (React namespace issue resolved in source).
- ZIP diff vs original upload: no files lost; 4 files added (CaneLogo.tsx, RouteAnnouncer.tsx, announce.ts, PROGRESS.md), others modified.

### Test results (actual, this environment)
- `npm test` (8 unit tests): **8 passed, 0 failed** (re-run after second-pass edits).
- Partial `tsc --strict` on components/pages/App with dependency-resolution errors filtered: no errors in changed code; only environment errors (missing Vite `import.meta.env` types, missing `leaflet` css types). **This is not a real typecheck.**
- `pnpm typecheck` and `vite build`: **NOT RUN** — pnpm missing, dependencies not installed, no network access.
- Not run at all: browser/keyboard test, visual check of the logo, any Android/TalkBack test.

### Remaining limitations
- **Android TalkBack not verified.** Must test on a real device (Chrome + TalkBack): swipe order per screen, heading focus after tab change, skip link, SOS countdown/cancel, camera permission, overlap of live-region text with in-app speech (error/offline messages are both spoken and `role="alert"`, so may be read twice).
- Bottom tabs are `<button>`s, not links.
- Leaflet map is not screen-reader/keyboard navigable; use spoken/text steps.
- Camera detections are announced via in-app speech only.
- Before shipping run: `pnpm install && pnpm typecheck && pnpm build`.


## Pass: local (Windows) readiness (2026-10-29)

### Root cause of "Your profile could not be loaded or saved"
Traced: UI -> `fetch /api/visionpath/profile` -> Vite proxy (:8080) -> Express -> Clerk `getAuth` -> PostgreSQL (Drizzle). Outside Replit the request fails whenever (a) the API process is not running (it required `PORT` and a Bash-only `export` in its `dev` script), (b) `CLERK_SECRET_KEY`/`CLERK_PUBLISHABLE_KEY` are missing so Clerk middleware rejects/throws, (c) `DATABASE_URL` is missing/unreachable, or (d) tables were never created (`drizzle-kit push` was never run). The UI collapsed all of these into one generic message. **This was determined by code inspection; it could not be reproduced here** (no network, no dependencies, no Clerk or PostgreSQL).

### Changes
- `scripts/dev-local.mjs` (new): `pnpm dev` validates `.env`, checks ports, builds and starts API (:8080) + Vite (:5173), reports DB readiness, stops both on Ctrl+C (uses `taskkill` on Windows). No Bash needed.
- `scripts/db-push.mjs`, `scripts/env.mjs`, `scripts/require-pnpm.mjs` (new). The root `preinstall` used `sh -c` (breaks on Windows) -> replaced with Node script; same pnpm-only behaviour.
- Root `.env.example` (placeholders only), `docker-compose.yml` (optional local Postgres), `start-visionpath.bat`, `README_LOCAL.md`; `.env` added to `.gitignore`; `engines.node >=20.19`.
- `vite.config.ts`: `envDir` = repo root (single `.env`); proxy target uses `API_PORT` (default 8080, `127.0.0.1`).
- API: new `GET /api/readyz` (DB check, 503 when unreachable); dev-only error message in server log.
- `UserContext.tsx`: profile errors now state the real class of failure (API unreachable / 401 / 5xx / validation) instead of a single vague text; failures are still never reported as success, no fake data, auth not bypassed.
- Lockfile and package manager unchanged. No dependencies added.

### Test results (actual, this environment)
- Frontend unit tests (8): **pass**.
- `node --check` on all new scripts: pass. `pnpm check:env` logic exercised: fails correctly with no `.env`, passes with the example file after the `replace_me` placeholder rule was added.
- NOT RUN (reason: no network/registry access, pnpm and PostgreSQL unavailable, no Clerk keys): `pnpm install`, API tests, `pnpm typecheck`, `pnpm build`, API/frontend startup, `/healthz` and `/readyz`, DB connectivity, profile load/save, `db:push`. Partial `tsc` on edited files showed only missing-dependency noise.

### Feature status (from source inspection; nothing was exercised end to end)
| Feature | Status |
|---|---|
| Navigation/translation utilities | Implemented and tested (unit tests) |
| Auth (Clerk) + profile API + DB | Implemented; **unverified** (not run) |
| Object detection | Real model integrated: TF.js + COCO-SSD `lite_mobilenet_v2`, score >= 0.45, left/centre/right zone; **unverified** on device; no distance estimation; cannot guarantee collision avoidance |
| GPS + walking navigation | Partially implemented (Geolocation + OSRM foot route + reroute logic; needs field test) |
| Voice guidance | Implemented (Web Speech, 13 languages); voices depend on the PC |
| TalkBack/screen-reader access | Partially implemented; not tested on a device |
| SOS + cancel countdown | Partially implemented: records an SOS request, cancel exists; **no automatic delivery to contacts** |
| Family location sharing | Implemented in API (hashed tokens, 30-day expiry, revoke); unverified end to end |
| Offline mode, wearable support | Planned / missing |

### Remaining risks
- `publishableKeyFromHost` (Clerk) was not verified for `localhost` without running it; if sign-in fails, check the browser console first.
- First camera start downloads the model from the internet; there is no offline demo.
- Rehearse the full flow once on the showcase laptop (and Wi-Fi) before the event.


## Pass: public deployment preparation (2026-10-30)
- `app.ts`: in production the API also serves the built frontend (`artifacts/vision-path/dist/public`, override `STATIC_DIR`) with SPA fallback, so one Render service = one link.
- `render.yaml`, `vercel.json` (frontend-only, rewrite `/api` to the Render API; placeholder URL must be edited), `DEPLOY.md`.
- **Not deployed or tested**: no network/accounts here; the production static-serving code and Render/Vercel configs are unverified. Clerk dev-key behaviour on deployed domains and through a Vercel rewrite is unverified.
