# Deploy VisionPath to a public link

GitHub only stores code (GitHub Pages cannot run the Express API). Vercel hosts the frontend but cannot run this Express server as it is. So you need the API on a Node host. **Nothing here has been deployed or tested by the author** - follow and check each step.

## Option A (recommended): ONE link on Render (API + frontend together)
1. Push the project to GitHub (never commit `.env`).
2. Database: create a free Neon project (neon.tech), copy the connection string (keep `?sslmode=require`).
3. On your laptop put that string in `.env` as `DATABASE_URL`, run `pnpm db:push` once (creates tables).
4. Clerk dashboard: use your development keys (`pk_test_`, `sk_test_`).
5. render.com -> New -> Blueprint -> pick your GitHub repo (it reads `render.yaml`). Enter the 4 secrets:
   `VITE_CLERK_PUBLISHABLE_KEY`, `CLERK_PUBLISHABLE_KEY` (same pk_test), `CLERK_SECRET_KEY`, `DATABASE_URL`.
6. After the build, open `https://<your-app>.onrender.com/` . Check `/api/healthz` and `/api/readyz`.
Free Render sleeps after inactivity: open the link 1-2 minutes before the demo. Camera/GPS need HTTPS, which Render provides.

## Option B: Vercel (frontend) + Render (API)
1. Do Option A first (you need the Render API URL).
2. Edit `vercel.json`: replace `YOUR-RENDER-APP` with your Render app name.
3. vercel.com -> Import the GitHub repo. Environment variable: `VITE_CLERK_PUBLISHABLE_KEY`. Deploy.
Risk: sign-in cookies/handshake across a Vercel rewrite to another host may not work with Clerk development keys. If login fails on Vercel, use the Render link (Option A).

## If sign-in fails on the deployed link
Clerk dashboard -> check the keys match (same app), and that the deployed domain is allowed. Read the browser console and `/api/readyz`.
