import RouteAnnouncer from "@/components/RouteAnnouncer";
import { useEffect, useRef } from "react";
import { Switch, Route, Redirect, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { TooltipProvider } from "@/components/ui/tooltip";
import { UserProvider, useUser } from "@/contexts/UserContext";
import { TalkBackProvider, useTalkBack } from "@/contexts/TalkBackContext";
import ScreenReaderControls from "@/components/ScreenReaderControls";
import AuthLanding from "@/pages/AuthLanding";
import Onboarding from "@/pages/Onboarding";
import Dashboard from "@/pages/Dashboard";
import Navigation from "@/pages/Navigation";
import SOS from "@/pages/SOS";
import FamilyTracker from "@/pages/FamilyTracker";
import Profile from "@/pages/Profile";

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;


function stripBase(path: string): string {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || "/" : path;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "#cbd9b4",
    colorForeground: "#f2f1e7",
    colorMutedForeground: "#b5c0b1",
    colorDanger: "#f0b7ae",
    colorBackground: "#1d2921",
    colorInput: "#151e18",
    colorInputForeground: "#f2f1e7",
    colorNeutral: "#405247",
    fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif",
    borderRadius: "1rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-[#1d2921] rounded-2xl w-[440px] max-w-full overflow-hidden border border-[#405247]",
    card: "!shadow-none !border-0 !bg-transparent",
    footer: "!shadow-none !border-0 !bg-transparent",
    headerTitle: "!text-[#dce7c5]",
    headerSubtitle: "!text-[#b5c0b1]",
    formFieldLabel: "!text-[#d8dfd2]",
    formFieldInput: "!bg-[#151e18] !text-[#f2f1e7] !border-[#607366]",
    formButtonPrimary: "!bg-[#cbd9b4] !text-[#1a261e]",
    footerActionLink: "!text-[#dce7c5]",
    footerActionText: "!text-[#b5c0b1]",
    dividerText: "!text-[#b5c0b1]",
  },
};

function NavBar() {
  const [location, navigate] = useLocation();
  const { registerTap } = useTalkBack();

  const tabs = [
    { path: "/", label: "Home", icon: (active: boolean) => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill={active ? "var(--vp-accent-bright)" : "var(--vp-text-subtle)"}>
        <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
      </svg>
    )},
    { path: "/navigate", label: "Navigate", icon: (active: boolean) => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill={active ? "var(--vp-accent-bright)" : "var(--vp-text-subtle)"}>
        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
      </svg>
    )},
    { path: "/sos", label: "SOS", icon: (active: boolean) => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill={active ? "var(--vp-danger)" : "var(--vp-danger-muted)"}>
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
      </svg>
    )},
    { path: "/family", label: "Family", icon: (active: boolean) => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill={active ? "var(--vp-accent-bright)" : "var(--vp-text-subtle)"}>
        <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/>
      </svg>
    )},
    { path: "/profile", label: "Profile", icon: (active: boolean) => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill={active ? "var(--vp-accent-bright)" : "var(--vp-text-subtle)"}>
        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
      </svg>
    )},
  ];

  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  return (
    <div
      className="vp-bottom-nav fixed bottom-0 left-0 right-0 z-50"
      data-screen-reader-ignore
      style={{ background: "var(--vp-page-raised)", borderTop: "1px solid var(--vp-border)", paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <nav className="flex" aria-label="Main navigation">
        {tabs.map(tab => {
          const active = isActive(tab.path);
          const handler = registerTap(`${tab.label} tab`, () => navigate(tab.path));
          return (
            <button
              key={tab.path}
              onClick={handler}
              aria-label={`${tab.label} tab`}
              aria-current={active ? "page" : undefined}
              className="flex-1 flex flex-col items-center py-2.5 gap-0.5 text-[10px] font-medium transition-all"
              style={{ color: tab.path === "/sos" ? (active ? "var(--vp-danger)" : "var(--vp-danger-muted)") : (active ? "var(--vp-accent-bright)" : "var(--vp-text-subtle)") }}
            >
              {tab.icon(active)}
              {tab.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
}

function AppContent() {
  const { user, profileLoading, profileError, retryProfileLoad } = useUser();
  if (profileLoading) {
    return (
        <main className="min-h-screen flex items-center justify-center px-6" style={{ background: "var(--vp-page)", color: "var(--vp-accent-bright)" }}>
        <p role="status" aria-live="polite">Loading your secure profile…</p>
      </main>
    );
  }
  if (profileError) {
    return (
        <main className="min-h-screen flex flex-col items-center justify-center gap-4 px-6 text-center" style={{ background: "var(--vp-page)", color: "var(--vp-text)" }}>
        <p role="alert">{profileError}</p>
        <button
          type="button"
          onClick={retryProfileLoad}
          className="min-h-12 rounded-xl px-5 font-semibold"
            style={{ background: "var(--vp-accent)", color: "var(--vp-accent-ink)" }}
        >
          Retry
        </button>
      </main>
    );
  }
  if (!user) return <Onboarding />;
  return (
    <div className="flex flex-col min-h-screen" style={{ background: "var(--vp-page)", paddingBottom: "88px" }}>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/navigate" component={Navigation} />
        <Route path="/sos" component={SOS} />
        <Route path="/family" component={FamilyTracker} />
        <Route path="/profile" component={Profile} />
      </Switch>
      <NavBar />
    </div>
  );
}

function SignInPage() {
  return (
    <main className="min-h-[100dvh] flex items-center justify-center px-4 py-8" style={{ background: "var(--vp-page)" }}>
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
    </main>
  );
}

function SignUpPage() {
  return (
    <main className="min-h-[100dvh] flex items-center justify-center px-4 py-8" style={{ background: "var(--vp-page)" }}>
      <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
    </main>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const queryClient = useQueryClient();
  const previousUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const nextId = user?.id ?? null;
      if (previousUserIdRef.current !== undefined && previousUserIdRef.current !== nextId) {
        queryClient.clear();
      }
      previousUserIdRef.current = nextId;
    });
    return unsubscribe;
  }, [addListener, queryClient]);
  return null;
}

function AuthRoutes() {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) {
    return (
        <main className="min-h-screen flex items-center justify-center px-6" style={{ background: "var(--vp-page)", color: "var(--vp-accent-bright)" }}>
        <p role="status" aria-live="polite">Loading VisionPath…</p>
      </main>
    );
  }
  return (
    <Switch>
      <Route path="/family-view" component={FamilyTracker} />
      <Route path="/sign-in/*?">
        {isSignedIn ? <Redirect to="/" /> : <SignInPage />}
      </Route>
      <Route path="/sign-up/*?">
        {isSignedIn ? <Redirect to="/" /> : <SignUpPage />}
      </Route>
      <Route path="/">
        {isSignedIn ? <AppContent /> : <AuthLanding />}
      </Route>
      <Route>
        {isSignedIn ? <AppContent /> : <AuthLanding />}
      </Route>
    </Switch>
  );
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: "Welcome back", subtitle: "Sign in to continue to VisionPath" } },
        signUp: { start: { title: "Create your account", subtitle: "Set up your VisionPath account" } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <TooltipProvider>
          <UserProvider>
            <TalkBackProvider>
              <RouteAnnouncer />
              <AuthRoutes />
              <ScreenReaderControls />
            </TalkBackProvider>
          </UserProvider>
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  // Fail visibly and accessibly when deployment credentials are missing instead
  // of crashing the whole application with an uncaught module-level exception.
  if (!clerkPubKey) {
    return (
          <main className="min-h-[100dvh] flex items-center justify-center px-6 py-10" style={{ background: "var(--vp-page)", color: "var(--vp-text)" }}>
        <section className="w-full max-w-xl rounded-2xl border p-6" style={{ borderColor: "var(--vp-border-strong)", background: "var(--vp-surface)" }}>
          <h1 className="text-2xl font-bold mb-3" style={{ color: "var(--vp-accent-bright)" }}>VisionPath setup required</h1>
          <p role="alert" className="leading-relaxed mb-3">Authentication is not configured. Add a valid VITE_CLERK_PUBLISHABLE_KEY to the deployment environment and restart the app.</p>
          <p className="text-sm leading-relaxed" style={{ color: "var(--vp-text-muted)" }}>Sign-in, saved profiles, family sharing and SOS recording remain unavailable until the Clerk key and server/database configuration are set up. No demo authentication is enabled.</p>
        </section>
      </main>
    );
  }
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
