import { languageInfo, type LanguageCode, translate } from "./translations";

export type SpeechPriority = "routine" | "guidance" | "critical";
export type VoiceAvailability = "checking" | "available" | "unavailable" | "unsupported" | "error";
type SpeechOptions = { priority?: SpeechPriority; language?: LanguageCode; fallbackToSystemVoice?: boolean };
type SpeechStatusListener = (language: LanguageCode, status: VoiceAvailability) => void;
type SpeechTask = { text: string; language: LanguageCode; priority: SpeechPriority; fallbackToSystemVoice: boolean };

const priorityRank: Record<SpeechPriority, number> = { routine: 0, guidance: 1, critical: 2 };
const speechQueue: SpeechTask[] = [];
const statusListeners = new Set<SpeechStatusListener>();
const unavailableNoticeShown = new Set<LanguageCode>();
let activeUtterance: SpeechSynthesisUtterance | null = null;
let activeTask: SpeechTask | null = null;
let lastSpokenTask: SpeechTask | null = null;
let deferredTask: SpeechTask | null = null;
let currentLanguage: LanguageCode = "en";
let voiceListReady = false;
let resolvingQueue = false;
let userPaused = false;
let speechRevision = 0;

function speechAvailable(): boolean {
  return typeof window !== "undefined" &&
    "speechSynthesis" in window &&
    typeof SpeechSynthesisUtterance !== "undefined";
}

function getVoices(): SpeechSynthesisVoice[] {
  if (!speechAvailable()) return [];
  try {
    return window.speechSynthesis.getVoices();
  } catch {
    return [];
  }
}

function findVoice(language: LanguageCode): SpeechSynthesisVoice | undefined {
  const locale = languageInfo(language).locale.toLowerCase();
  const base = locale.split("-")[0];
  const voices = getVoices();
  return voices.find((voice) => voice.lang.toLowerCase() === locale)
    ?? voices.find((voice) => voice.lang.toLowerCase().split("-")[0] === base);
}

function findSystemVoice(): SpeechSynthesisVoice | undefined {
  const voices = getVoices();
  return voices.find((voice) => voice.default) ?? voices[0];
}

function emitStatus(language: LanguageCode, status: VoiceAvailability): void {
  statusListeners.forEach((listener) => listener(language, status));
}

function refreshVoiceStatus(language: LanguageCode): VoiceAvailability {
  if (!speechAvailable()) {
    emitStatus(language, "unsupported");
    return "unsupported";
  }
  const voices = getVoices();
  if (voices.length > 0) voiceListReady = true;
  const status = findVoice(language) ? "available" : voiceListReady ? "unavailable" : "checking";
  emitStatus(language, status);
  return status;
}

function listenForVoices(): void {
  if (!speechAvailable()) return;
  const synth = window.speechSynthesis;
  const refresh = () => {
    const voices = getVoices();
    if (voices.length) voiceListReady = true;
    refreshVoiceStatus(currentLanguage);
  };
  synth.addEventListener?.("voiceschanged", refresh);
  if (getVoices().length) voiceListReady = true;
  window.setTimeout(() => {
    voiceListReady = true;
    refresh();
  }, 5000);
}

listenForVoices();

export function getVoiceAvailability(language: LanguageCode): VoiceAvailability {
  return refreshVoiceStatus(language);
}

export function subscribeSpeechStatus(listener: SpeechStatusListener): () => void {
  statusListeners.add(listener);
  return () => statusListeners.delete(listener);
}

export function setSpeechLanguage(language: LanguageCode): void {
  currentLanguage = language;
  speechRevision += 1;
  speechQueue.length = 0;
  deferredTask = null;
  if (speechAvailable()) {
    activeUtterance = null;
    activeTask = null;
    window.speechSynthesis.cancel();
  }
  unavailableNoticeShown.delete(language);
  refreshVoiceStatus(language);
}

function cancelActive(): void {
  const hadActive = !!activeUtterance;
  activeUtterance = null;
  activeTask = null;
  if (hadActive && speechAvailable()) window.speechSynthesis.cancel();
}

function makeUtterance(task: SpeechTask, voice: SpeechSynthesisVoice): SpeechSynthesisUtterance {
  const utterance = new SpeechSynthesisUtterance(task.text);
  const requestedLocale = languageInfo(task.language).locale;
  utterance.lang = voice.lang || requestedLocale;
  utterance.voice = voice;
  utterance.rate = 0.94;
  utterance.pitch = 1;
  utterance.volume = 1;
  utterance.onstart = () => {
    lastSpokenTask = task;
    const requestedBase = requestedLocale.split("-")[0].toLowerCase();
    const voiceBase = voice.lang.split("-")[0].toLowerCase();
    emitStatus(task.language, voiceBase && voiceBase !== requestedBase ? "unavailable" : "available");
  };
  utterance.onend = () => {
    if (activeUtterance !== utterance) return;
    activeUtterance = null;
    activeTask = null;
    void processQueue();
  };
  utterance.onerror = () => {
    if (activeUtterance !== utterance) return;
    activeUtterance = null;
    activeTask = null;
    emitStatus(task.language, "error");
    void processQueue();
  };
  return utterance;
}

async function waitForVoiceList(): Promise<void> {
  if (voiceListReady || !speechAvailable()) return;
  if (getVoices().length) {
    voiceListReady = true;
    return;
  }
  await new Promise<void>((resolve) => {
    const synth = window.speechSynthesis;
    let timeout: number | undefined;
    const finish = () => {
      synth.removeEventListener?.("voiceschanged", onVoicesChanged);
      if (timeout !== undefined) window.clearTimeout(timeout);
      if (getVoices().length) voiceListReady = true;
      resolve();
    };
    const onVoicesChanged = () => {
      if (getVoices().length) finish();
    };
    synth.addEventListener?.("voiceschanged", onVoicesChanged);
    timeout = window.setTimeout(finish, 5000);
  });
}

function announceUnavailableLanguage(language: LanguageCode): void {
  if (language === "en" || unavailableNoticeShown.has(language)) return;
  unavailableNoticeShown.add(language);
  const englishVoice = findVoice("en");
  if (!englishVoice || !speechAvailable()) return;
  const info = languageInfo(language);
  const fallbackTask: SpeechTask = {
    language: "en",
    priority: "critical",
    text: translate("en", "voiceUnavailable", { language: info.name }),
    fallbackToSystemVoice: false,
  };
  const utterance = makeUtterance(fallbackTask, englishVoice);
  activeTask = fallbackTask;
  activeUtterance = utterance;
  try {
    window.speechSynthesis.speak(utterance);
  } catch {
    activeUtterance = null;
    activeTask = null;
  }
}

async function processQueue(): Promise<void> {
  if (resolvingQueue || activeUtterance || !speechQueue.length) return;
  if (userPaused && !speechQueue.some((task) => task.priority === "critical")) return;
  if (!speechAvailable()) {
    const task = speechQueue.shift();
    if (task) emitStatus(task.language, "unsupported");
    speechQueue.length = 0;
    return;
  }
  resolvingQueue = true;
  const task = speechQueue.shift()!;
  const revision = speechRevision;
  await waitForVoiceList();
  if (revision !== speechRevision) {
    resolvingQueue = false;
    void processQueue();
    return;
  }
  if (userPaused && task.priority !== "critical") {
    deferredTask = task;
    resolvingQueue = false;
    return;
  }
  const voice = findVoice(task.language) ?? (task.fallbackToSystemVoice ? findSystemVoice() : undefined);
  resolvingQueue = false;
  if (!voice) {
    emitStatus(task.language, "unavailable");
    speechQueue.splice(0, speechQueue.length, ...speechQueue.filter((queued) => queued.language !== task.language));
    announceUnavailableLanguage(task.language);
    if (!activeUtterance) void processQueue();
    return;
  }
  const utterance = makeUtterance(task, voice);
  activeTask = task;
  activeUtterance = utterance;
  try {
    if (window.speechSynthesis.paused) window.speechSynthesis.resume();
    window.speechSynthesis.speak(utterance);
  } catch {
    activeUtterance = null;
    activeTask = null;
    emitStatus(task.language, "error");
    void processQueue();
  }
}

export function speak(text: string, priorityOrOptions: boolean | SpeechOptions = false): void {
  const options = typeof priorityOrOptions === "boolean"
    ? { priority: priorityOrOptions ? "guidance" as const : "routine" as const }
    : priorityOrOptions;
  const task: SpeechTask = {
    text,
    language: options.language ?? currentLanguage,
    priority: options.priority ?? "routine",
    fallbackToSystemVoice: options.fallbackToSystemVoice ?? false,
  };
  if (!text.trim()) return;
  if (!speechAvailable()) {
    emitStatus(task.language, "unsupported");
    return;
  }
  if (userPaused && task.priority !== "critical") {
    deferredTask = task;
    return;
  }
  if (
    task.priority === "critical" &&
    activeUtterance &&
    speechAvailable() &&
    window.speechSynthesis.paused
  ) {
    cancelActive();
  }

  const currentRank = activeTask ? priorityRank[activeTask.priority] : -1;
  if (task.priority === "critical" && currentRank < priorityRank.critical) {
    speechQueue.splice(0, speechQueue.length, ...speechQueue.filter((queued) => queued.priority === "critical"));
    cancelActive();
  } else if (task.priority === "guidance" && currentRank < priorityRank.guidance) {
    speechQueue.splice(0, speechQueue.length, ...speechQueue.filter((queued) => queued.priority === "critical"));
    cancelActive();
  } else if (task.priority === "guidance") {
    speechQueue.splice(0, speechQueue.length, ...speechQueue.filter((queued) => queued.priority === "critical"));
  }

  if (task.priority === "critical" && speechQueue.filter((queued) => queued.priority === "critical").length >= 2) {
    return;
  }
  speechQueue.push(task);
  if (!activeUtterance) void processQueue();
}

export function stopSpeaking(): void {
  speechQueue.length = 0;
  deferredTask = null;
  userPaused = false;
  cancelActive();
}

export function repeatLastSpeech(): void {
  if (!lastSpokenTask) return;
  speak(lastSpokenTask.text, { priority: "guidance", language: lastSpokenTask.language });
}

export function pauseSpeech(): void {
  userPaused = true;
  if (activeTask && activeTask.priority !== "critical") {
    deferredTask = activeTask;
    cancelActive();
  } else if (speechAvailable() && window.speechSynthesis.speaking) {
    window.speechSynthesis.pause();
  }
}

export function resumeSpeech(): void {
  userPaused = false;
  if (deferredTask) {
    speechQueue.splice(0, speechQueue.length, ...speechQueue.filter((task) => task.priority === "critical"));
    speechQueue.unshift(deferredTask);
    deferredTask = null;
  } else if (speechAvailable() && window.speechSynthesis.paused) {
    window.speechSynthesis.resume();
  }
  void processQueue();
}

export function isSpeechPaused(): boolean {
  return userPaused || (speechAvailable() && window.speechSynthesis.paused);
}

export function isSpeaking(): boolean {
  return speechAvailable() && window.speechSynthesis.speaking;
}
