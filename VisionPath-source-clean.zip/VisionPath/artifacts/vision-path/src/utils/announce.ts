// Central screen-reader announcer. Messages are rendered by <RouteAnnouncer />
// into two hidden live regions (polite / assertive). Use for state changes only;
// spoken navigation guidance still goes through utils/speech.ts.
export type AnnouncePoliteness = "polite" | "assertive";
export const ANNOUNCE_EVENT = "visionpath:announce";

export function announce(message: string, politeness: AnnouncePoliteness = "polite"): void {
  if (typeof window === "undefined" || !message.trim()) return;
  window.dispatchEvent(new CustomEvent(ANNOUNCE_EVENT, { detail: { message, politeness } }));
}
