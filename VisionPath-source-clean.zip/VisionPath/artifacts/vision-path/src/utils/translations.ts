export const SUPPORTED_LANGUAGES = [
  { code: "en", name: "English", locale: "en-IN" },
  { code: "hi", name: "हिन्दी", locale: "hi-IN" },
  { code: "pa", name: "ਪੰਜਾਬੀ", locale: "pa-IN" },
  { code: "bn", name: "বাংলা", locale: "bn-IN" },
  { code: "te", name: "తెలుగు", locale: "te-IN" },
  { code: "ta", name: "தமிழ்", locale: "ta-IN" },
  { code: "mr", name: "मराठी", locale: "mr-IN" },
  { code: "gu", name: "ગુજરાતી", locale: "gu-IN" },
  { code: "kn", name: "ಕನ್ನಡ", locale: "kn-IN" },
  { code: "ml", name: "മലയാളം", locale: "ml-IN" },
  { code: "or", name: "ଓଡ଼ିଆ", locale: "or-IN" },
  { code: "as", name: "অসমীয়া", locale: "as-IN" },
  { code: "ur", name: "اردو", locale: "ur-IN" },
] as const;

export type LanguageCode = (typeof SUPPORTED_LANGUAGES)[number]["code"];
export type ActionKey =
  | "continueStraight" | "turnLeft" | "turnRight" | "sharpLeft" | "sharpRight"
  | "slightLeft" | "slightRight" | "uTurn" | "start" | "startHeading"
  | "arrive" | "roundabout" | "exitRoundabout" | "keepLeft" | "keepRight"
  | "keep" | "merge" | "endLeft" | "endRight" | "continue";

type TextKey =
  | "guidanceForSteps" | "guidanceInSteps" | "navigationStarted" | "arrived"
  | "gpsWait" | "gpsDenied" | "gpsUnavailable" | "gpsLost" | "gpsTimeout" | "gpsInaccurate"
  | "offline" | "placeNotFound" | "routeFailed" | "rerouting" | "rerouteFailed" | "voiceChecking"
  | "voiceAvailable" | "voiceUnavailable" | "speechUnsupported" | "speechError"
  | "languageSelected" | "languageSelectorLabel" | "talkBackEnabled" | "talkBackDisabled"
  | "obstacleAlert" | "objectDetected" | "obstacle"
  | "sosCountdown" | "sosCancelled" | "sosRecorded" | "sosRecordFailed" | "sosMessage";

interface TranslationEntry {
  actions: Record<ActionKey, string>;
  directions: Record<string, string>;
  text: Record<TextKey, string>;
  zones: Record<"left" | "centre" | "right", string>;
  objects: Record<string, string>;
  streetSuffix: string;
}

const commonDirections = {
  north: "north", south: "south", east: "east", west: "west",
  "north-east": "north-east", "north-west": "north-west",
  "south-east": "south-east", "south-west": "south-west",
};

const entries: Record<LanguageCode, TranslationEntry> = {
  en: {
    actions: {
      continueStraight: "Continue straight", turnLeft: "Turn left", turnRight: "Turn right",
      sharpLeft: "Turn sharp left", sharpRight: "Turn sharp right", slightLeft: "Bear left",
      slightRight: "Bear right", uTurn: "Make a U-turn", start: "Start walking",
      startHeading: "Start heading {direction}", arrive: "You have arrived",
      roundabout: "Enter the roundabout", exitRoundabout: "Exit the roundabout",
      keepLeft: "Keep left", keepRight: "Keep right", keep: "Keep going",
      merge: "Merge", endLeft: "At the end of the road, turn left",
      endRight: "At the end of the road, turn right", continue: "Continue",
    },
    directions: commonDirections, streetSuffix: " onto {street}",
    text: {
      languageSelectorLabel: "Voice guidance language",
      talkBackEnabled: "In-app voice helper is on. Tap once to hear a label, then tap twice to select.",
      talkBackDisabled: "In-app voice helper is off.",
      guidanceForSteps: "{action} for {count} steps.", guidanceInSteps: "{action} in {count} steps.",
      navigationStarted: "Navigation started.", arrived: "You have arrived at your destination.",
      gpsWait: "Waiting for your location. Please allow location access.",
      gpsDenied: "Location permission was denied. Allow location access in your device settings.",
      gpsUnavailable: "Your location is unavailable. Move to an open area and try again.",
      gpsLost: "GPS signal lost. Waiting to reconnect.",
      gpsTimeout: "Location request timed out. Check GPS and try again.",
      gpsInaccurate: "GPS accuracy is too low for reliable guidance. Wait for a better signal.",
      offline: "Internet connection lost. Online route search is unavailable.",
      placeNotFound: "Location not found. Try a more specific address.",
      routeFailed: "Could not calculate a route. Please try again.",
      rerouting: "You are off the route. Recalculating a pedestrian route.",
      rerouteFailed: "A pedestrian reroute failed. Navigation has stopped; choose a route again.",
      voiceChecking: "Checking for a speech voice in {language}.",
      voiceAvailable: "A {language} speech voice is available.",
      voiceUnavailable: "A {language} speech voice is not installed. Install a {language} voice in your device text-to-speech settings, or choose English.",
      speechUnsupported: "Speech playback is not supported by this browser. Screen-reader text remains available.",
      speechError: "Speech playback failed. Check your device text-to-speech settings.",
      languageSelected: "Voice guidance language set to {language}.",
      obstacleAlert: "Warning. {object} detected {zone}.",
      objectDetected: "Camera object detected: {object} {zone}. Distance is not measured.",
      obstacle: "obstacle",
      sosCountdown: "SOS request will be recorded in {count} seconds. Tap Cancel to stop.",
      sosCancelled: "SOS countdown cancelled.",
      sosRecorded: "The SOS request was recorded in VisionPath. No message was sent.",
      sosRecordFailed: "Could not record the SOS request. No message was sent.",
      sosMessage: "Emergency SOS from {name}. I urgently need help. My location: {location}. Please call me or come to help. Sent via VisionPath.",
    },
    zones: { left: "on the left", centre: "straight ahead", right: "on the right" },
    objects: {
      person: "person", bicycle: "bicycle", car: "car", motorcycle: "motorcycle", bus: "bus",
      train: "train", truck: "truck", bench: "bench", chair: "chair", couch: "sofa",
      "potted plant": "plant", "dining table": "table", backpack: "backpack", umbrella: "umbrella",
      dog: "dog", bird: "bird", "traffic light": "traffic light", "stop sign": "stop sign",
      suitcase: "suitcase", stroller: "stroller",
    },
  },
  hi: {
    actions: {
      continueStraight: "सीधे चलते रहें", turnLeft: "बाएँ मुड़ें", turnRight: "दाएँ मुड़ें",
      sharpLeft: "तेज़ी से बाएँ मुड़ें", sharpRight: "तेज़ी से दाएँ मुड़ें",
      slightLeft: "हल्का बाएँ मुड़ें", slightRight: "हल्का दाएँ मुड़ें", uTurn: "यू-टर्न लें",
      start: "चलना शुरू करें", startHeading: "{direction} दिशा में चलना शुरू करें",
      arrive: "आप पहुँच गए हैं", roundabout: "गोल चक्कर में प्रवेश करें",
      exitRoundabout: "गोल चक्कर से बाहर निकलें", keepLeft: "बाईं ओर रहें",
      keepRight: "दाईं ओर रहें", keep: "आगे बढ़ते रहें", merge: "रास्ते में मिलें",
      endLeft: "सड़क के अंत में बाएँ मुड़ें", endRight: "सड़क के अंत में दाएँ मुड़ें",
      continue: "आगे बढ़ें",
    },
    directions: { north: "उत्तर", south: "दक्षिण", east: "पूर्व", west: "पश्चिम", "north-east": "उत्तर-पूर्व", "north-west": "उत्तर-पश्चिम", "south-east": "दक्षिण-पूर्व", "south-west": "दक्षिण-पश्चिम" },
    streetSuffix: " {street} सड़क पर",
    text: {
      languageSelectorLabel: "आवाज़ में मार्गदर्शन की भाषा",
      talkBackEnabled: "ऐप की आवाज़ चालू है। नाम सुनने के लिए एक बार टैप करें और चुनने के लिए दो बार टैप करें।",
      talkBackDisabled: "ऐप की आवाज़ बंद है।",
      guidanceForSteps: "{count} कदम {action}।", guidanceInSteps: "{count} कदम बाद {action}।",
      navigationStarted: "नेविगेशन शुरू हुआ।", arrived: "आप अपने गंतव्य पर पहुँच गए हैं।",
      gpsWait: "आपकी लोकेशन का इंतज़ार है। कृपया लोकेशन की अनुमति दें।",
      gpsDenied: "लोकेशन की अनुमति नहीं मिली। डिवाइस सेटिंग में लोकेशन की अनुमति दें।",
      gpsUnavailable: "आपकी लोकेशन उपलब्ध नहीं है। खुले स्थान पर जाकर फिर कोशिश करें।",
      gpsLost: "जीपीएस सिग्नल चला गया है। दोबारा जुड़ने का इंतज़ार है।",
      gpsTimeout: "लोकेशन मिलने में समय समाप्त हो गया। जीपीएस जाँचकर फिर कोशिश करें।",
      gpsInaccurate: "जीपीएस की सटीकता भरोसेमंद मार्गदर्शन के लिए कम है। बेहतर सिग्नल का इंतज़ार करें।",
      offline: "इंटरनेट कनेक्शन नहीं है। ऑनलाइन रास्ता खोजना उपलब्ध नहीं है।",
      placeNotFound: "लोकेशन नहीं मिली। अधिक स्पष्ट पता लिखकर देखें।",
      routeFailed: "रास्ता नहीं बन पाया। कृपया फिर कोशिश करें।",
      rerouting: "आप रास्ते से हट गए हैं। पैदल चलने का नया रास्ता निकाला जा रहा है।",
      rerouteFailed: "पैदल चलने का नया रास्ता नहीं बन पाया। नेविगेशन रोक दिया गया है; फिर से रास्ता चुनें।",
      voiceChecking: "{language} की आवाज़ खोजी जा रही है।",
      voiceAvailable: "{language} की बोलने वाली आवाज़ उपलब्ध है।",
      voiceUnavailable: "{language} की आवाज़ इंस्टॉल नहीं है। डिवाइस की टेक्स्ट-टू-स्पीच सेटिंग में इसे इंस्टॉल करें या अंग्रेज़ी चुनें।",
      speechUnsupported: "इस ब्राउज़र में आवाज़ चलाने की सुविधा नहीं है। स्क्रीन रीडर से पढ़ने योग्य टेक्स्ट उपलब्ध रहेगा।",
      speechError: "आवाज़ नहीं चल पाई। डिवाइस की टेक्स्ट-टू-स्पीच सेटिंग जाँचें।",
      languageSelected: "आवाज़ की भाषा {language} चुनी गई है।",
       obstacleAlert: "सावधान। {zone} {object} है।",
       objectDetected: "कैमरे में {zone} {object} दिखा है। दूरी का अनुमान नहीं लगाया गया है।",
       obstacle: "बाधा",
       sosCountdown: "SOS अनुरोध {count} सेकंड में दर्ज होगा। रोकने के लिए रद्द करें पर टैप करें।",
       sosCancelled: "SOS की उलटी गिनती रद्द कर दी गई।",
       sosRecorded: "SOS अनुरोध VisionPath में दर्ज हुआ। कोई संदेश नहीं भेजा गया।",
       sosRecordFailed: "SOS अनुरोध दर्ज नहीं हो सका। कोई संदेश नहीं भेजा गया।",
       sosMessage: "{name} की ओर से आपातकालीन SOS। मुझे तुरंत मदद चाहिए। मेरा स्थान: {location}। कृपया मुझे कॉल करें या मदद के लिए आएँ। VisionPath के माध्यम से भेजा गया।",
    },
    zones: { left: "बाईं ओर", centre: "ठीक सामने", right: "दाईं ओर" },
    objects: {
      person: "व्यक्ति", bicycle: "साइकिल", car: "कार", motorcycle: "मोटरसाइकिल", bus: "बस",
      train: "ट्रेन", truck: "ट्रक", bench: "बेंच", chair: "कुर्सी", couch: "सोफ़ा",
      "potted plant": "गमले का पौधा", "dining table": "मेज़", backpack: "बैग", umbrella: "छाता",
      dog: "कुत्ता", bird: "पक्षी", "traffic light": "ट्रैफ़िक लाइट", "stop sign": "स्टॉप साइन",
      suitcase: "सूटकेस", stroller: "बच्चों की गाड़ी",
    },
  },
  pa: {
    actions: {
      continueStraight: "ਸਿੱਧੇ ਚੱਲਦੇ ਰਹੋ", turnLeft: "ਖੱਬੇ ਮੁੜੋ", turnRight: "ਸੱਜੇ ਮੁੜੋ",
      sharpLeft: "ਤੇਜ਼ੀ ਨਾਲ ਖੱਬੇ ਮੁੜੋ", sharpRight: "ਤੇਜ਼ੀ ਨਾਲ ਸੱਜੇ ਮੁੜੋ",
      slightLeft: "ਹੌਲੀ ਜਿਹੇ ਖੱਬੇ ਮੁੜੋ", slightRight: "ਹੌਲੀ ਜਿਹੇ ਸੱਜੇ ਮੁੜੋ", uTurn: "ਯੂ-ਟਰਨ ਲਵੋ",
      start: "ਚੱਲਣਾ ਸ਼ੁਰੂ ਕਰੋ", startHeading: "{direction} ਵੱਲ ਚੱਲਣਾ ਸ਼ੁਰੂ ਕਰੋ",
      arrive: "ਤੁਸੀਂ ਪਹੁੰਚ ਗਏ ਹੋ", roundabout: "ਗੋਲ ਚੱਕਰ ਵਿੱਚ ਦਾਖ਼ਲ ਹੋਵੋ",
      exitRoundabout: "ਗੋਲ ਚੱਕਰ ਤੋਂ ਬਾਹਰ ਨਿਕਲੋ", keepLeft: "ਖੱਬੇ ਪਾਸੇ ਰਹੋ",
      keepRight: "ਸੱਜੇ ਪਾਸੇ ਰਹੋ", keep: "ਅੱਗੇ ਵਧਦੇ ਰਹੋ", merge: "ਰਸਤੇ ਵਿੱਚ ਮਿਲੋ",
      endLeft: "ਸੜਕ ਦੇ ਅੰਤ 'ਤੇ ਖੱਬੇ ਮੁੜੋ", endRight: "ਸੜਕ ਦੇ ਅੰਤ 'ਤੇ ਸੱਜੇ ਮੁੜੋ",
      continue: "ਅੱਗੇ ਵਧੋ",
    },
    directions: { north: "ਉੱਤਰ", south: "ਦੱਖਣ", east: "ਪੂਰਬ", west: "ਪੱਛਮ", "north-east": "ਉੱਤਰ-ਪੂਰਬ", "north-west": "ਉੱਤਰ-ਪੱਛਮ", "south-east": "ਦੱਖਣ-ਪੂਰਬ", "south-west": "ਦੱਖਣ-ਪੱਛਮ" },
    streetSuffix: " {street} ਸੜਕ ਵੱਲ",
    text: {
      languageSelectorLabel: "ਆਵਾਜ਼ ਰਾਹੀਂ ਰਾਹ-ਦਿਖਾਈ ਦੀ ਭਾਸ਼ਾ",
      talkBackEnabled: "ਐਪ ਦੀ ਆਵਾਜ਼ ਚਾਲੂ ਹੈ। ਨਾਂ ਸੁਣਨ ਲਈ ਇੱਕ ਵਾਰ ਅਤੇ ਚੁਣਨ ਲਈ ਦੋ ਵਾਰ ਟੈਪ ਕਰੋ।",
      talkBackDisabled: "ਐਪ ਦੀ ਆਵਾਜ਼ ਬੰਦ ਹੈ।",
      guidanceForSteps: "{count} ਕਦਮ {action}।", guidanceInSteps: "{count} ਕਦਮਾਂ ਬਾਅਦ {action}।",
      navigationStarted: "ਰਾਹ-ਦਿਖਾਈ ਸ਼ੁਰੂ ਹੋ ਗਈ ਹੈ।", arrived: "ਤੁਸੀਂ ਆਪਣੀ ਮੰਜ਼ਿਲ 'ਤੇ ਪਹੁੰਚ ਗਏ ਹੋ।",
      gpsWait: "ਤੁਹਾਡੀ ਥਾਂ ਦੀ ਉਡੀਕ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ ਲੋਕੇਸ਼ਨ ਦੀ ਇਜਾਜ਼ਤ ਦਿਓ।",
      gpsDenied: "ਲੋਕੇਸ਼ਨ ਦੀ ਇਜਾਜ਼ਤ ਨਹੀਂ ਮਿਲੀ। ਡਿਵਾਈਸ ਸੈਟਿੰਗਾਂ ਵਿੱਚ ਲੋਕੇਸ਼ਨ ਦੀ ਇਜਾਜ਼ਤ ਦਿਓ।",
      gpsUnavailable: "ਤੁਹਾਡੀ ਥਾਂ ਨਹੀਂ ਮਿਲ ਰਹੀ। ਖੁੱਲ੍ਹੀ ਥਾਂ 'ਤੇ ਜਾ ਕੇ ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼ ਕਰੋ।",
      gpsLost: "GPS ਸਿਗਨਲ ਚਲਾ ਗਿਆ ਹੈ। ਮੁੜ ਜੁੜਨ ਦੀ ਉਡੀਕ ਹੈ।",
      gpsTimeout: "ਲੋਕੇਸ਼ਨ ਲੱਭਣ ਦਾ ਸਮਾਂ ਮੁੱਕ ਗਿਆ। GPS ਜਾਂਚ ਕੇ ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼ ਕਰੋ।",
      gpsInaccurate: "GPS ਦੀ ਸਟੀਕਤਾ ਭਰੋਸੇਯੋਗ ਰਾਹ-ਦਿਖਾਈ ਲਈ ਘੱਟ ਹੈ। ਵਧੀਆ ਸਿਗਨਲ ਦੀ ਉਡੀਕ ਕਰੋ।",
      offline: "ਇੰਟਰਨੈੱਟ ਕਨੈਕਸ਼ਨ ਨਹੀਂ ਹੈ। ਆਨਲਾਈਨ ਰਸਤਾ ਲੱਭਣਾ ਉਪਲਬਧ ਨਹੀਂ।",
      placeNotFound: "ਥਾਂ ਨਹੀਂ ਮਿਲੀ। ਹੋਰ ਸਪਸ਼ਟ ਪਤਾ ਅਜ਼ਮਾਓ।",
      routeFailed: "ਰਸਤਾ ਨਹੀਂ ਬਣ ਸਕਿਆ। ਕਿਰਪਾ ਕਰਕੇ ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼ ਕਰੋ।",
      rerouting: "ਤੁਸੀਂ ਰਸਤੇ ਤੋਂ ਹਟ ਗਏ ਹੋ। ਪੈਦਲ ਚੱਲਣ ਲਈ ਨਵਾਂ ਰਸਤਾ ਕੱਢਿਆ ਜਾ ਰਿਹਾ ਹੈ।",
      rerouteFailed: "ਪੈਦਲ ਚੱਲਣ ਲਈ ਨਵਾਂ ਰਸਤਾ ਨਹੀਂ ਬਣ ਸਕਿਆ। ਰਾਹ-ਦਿਖਾਈ ਰੋਕ ਦਿੱਤੀ ਹੈ; ਮੁੜ ਰਸਤਾ ਚੁਣੋ।",
      voiceChecking: "{language} ਦੀ ਆਵਾਜ਼ ਲੱਭੀ ਜਾ ਰਹੀ ਹੈ।",
      voiceAvailable: "{language} ਦੀ ਬੋਲਣ ਵਾਲੀ ਆਵਾਜ਼ ਉਪਲਬਧ ਹੈ।",
      voiceUnavailable: "{language} ਦੀ ਆਵਾਜ਼ ਇੰਸਟਾਲ ਨਹੀਂ ਹੈ। ਡਿਵਾਈਸ ਦੀ ਟੈਕਸਟ-ਟੂ-ਸਪੀਚ ਸੈਟਿੰਗ ਵਿੱਚ ਇੰਸਟਾਲ ਕਰੋ ਜਾਂ ਅੰਗਰੇਜ਼ੀ ਚੁਣੋ।",
      speechUnsupported: "ਇਸ ਬ੍ਰਾਊਜ਼ਰ ਵਿੱਚ ਆਵਾਜ਼ ਚਲਾਉਣ ਦੀ ਸਹੂਲਤ ਨਹੀਂ ਹੈ। ਸਕ੍ਰੀਨ ਰੀਡਰ ਲਈ ਲਿਖਤ ਉਪਲਬਧ ਰਹੇਗੀ।",
      speechError: "ਆਵਾਜ਼ ਨਹੀਂ ਚੱਲੀ। ਡਿਵਾਈਸ ਦੀ ਟੈਕਸਟ-ਟੂ-ਸਪੀਚ ਸੈਟਿੰਗ ਜਾਂਚੋ।",
      languageSelected: "ਆਵਾਜ਼ ਦੀ ਭਾਸ਼ਾ {language} ਚੁਣੀ ਗਈ ਹੈ।",
       obstacleAlert: "ਸਾਵਧਾਨ। {zone} {object} ਹੈ।",
       objectDetected: "ਕੈਮਰੇ ਵਿੱਚ {zone} {object} ਦਿੱਸਿਆ ਹੈ। ਦੂਰੀ ਨਹੀਂ ਮਾਪੀ ਗਈ।",
       obstacle: "ਰੁਕਾਵਟ",
       sosCountdown: "SOS ਬੇਨਤੀ {count} ਸਕਿੰਟਾਂ ਵਿੱਚ ਦਰਜ ਹੋਵੇਗੀ। ਰੋਕਣ ਲਈ ਰੱਦ ਕਰੋ 'ਤੇ ਟੈਪ ਕਰੋ।",
       sosCancelled: "SOS ਦੀ ਉਲਟੀ ਗਿਣਤੀ ਰੱਦ ਕਰ ਦਿੱਤੀ ਗਈ ਹੈ।",
       sosRecorded: "SOS ਬੇਨਤੀ VisionPath ਵਿੱਚ ਦਰਜ ਹੋ ਗਈ। ਕੋਈ ਸੁਨੇਹਾ ਨਹੀਂ ਭੇਜਿਆ ਗਿਆ।",
       sosRecordFailed: "SOS ਬੇਨਤੀ ਦਰਜ ਨਹੀਂ ਹੋ ਸਕੀ। ਕੋਈ ਸੁਨੇਹਾ ਨਹੀਂ ਭੇਜਿਆ ਗਿਆ।",
       sosMessage: "{name} ਵੱਲੋਂ ਐਮਰਜੈਂਸੀ SOS। ਮੈਨੂੰ ਤੁਰੰਤ ਮਦਦ ਦੀ ਲੋੜ ਹੈ। ਮੇਰੀ ਥਾਂ: {location}। ਕਿਰਪਾ ਕਰਕੇ ਮੈਨੂੰ ਫ਼ੋਨ ਕਰੋ ਜਾਂ ਮਦਦ ਲਈ ਆਓ। VisionPath ਰਾਹੀਂ ਭੇਜਿਆ ਗਿਆ।",
    },
    zones: { left: "ਖੱਬੇ ਪਾਸੇ", centre: "ਬਿਲਕੁਲ ਸਾਹਮਣੇ", right: "ਸੱਜੇ ਪਾਸੇ" },
    objects: {
      person: "ਵਿਅਕਤੀ", bicycle: "ਸਾਈਕਲ", car: "ਕਾਰ", motorcycle: "ਮੋਟਰਸਾਈਕਲ", bus: "ਬੱਸ",
      train: "ਰੇਲਗੱਡੀ", truck: "ਟਰੱਕ", bench: "ਬੈਂਚ", chair: "ਕੁਰਸੀ", couch: "ਸੋਫ਼ਾ",
      "potted plant": "ਗਮਲੇ ਵਾਲਾ ਪੌਦਾ", "dining table": "ਮੇਜ਼", backpack: "ਬੈਗ", umbrella: "ਛਤਰੀ",
      dog: "ਕੁੱਤਾ", bird: "ਪੰਛੀ", "traffic light": "ਟ੍ਰੈਫ਼ਿਕ ਲਾਈਟ", "stop sign": "ਸਟਾਪ ਸਾਈਨ",
      suitcase: "ਸੂਟਕੇਸ", stroller: "ਬੱਚਿਆਂ ਦੀ ਗੱਡੀ",
    },
  },
  bn: {
    actions: {
      continueStraight: "সোজা চলতে থাকুন", turnLeft: "বাঁদিকে ঘুরুন", turnRight: "ডানদিকে ঘুরুন",
      sharpLeft: "তীব্রভাবে বাঁদিকে ঘুরুন", sharpRight: "তীব্রভাবে ডানদিকে ঘুরুন",
      slightLeft: "সামান্য বাঁদিকে ঘুরুন", slightRight: "সামান্য ডানদিকে ঘুরুন", uTurn: "ইউ-টার্ন নিন",
      start: "হাঁটা শুরু করুন", startHeading: "{direction} দিকে হাঁটা শুরু করুন",
      arrive: "আপনি পৌঁছে গেছেন", roundabout: "গোলচত্বরে প্রবেশ করুন",
      exitRoundabout: "গোলচত্বর থেকে বেরিয়ে আসুন", keepLeft: "বাঁদিকে থাকুন",
      keepRight: "ডানদিকে থাকুন", keep: "এগিয়ে চলুন", merge: "রাস্তায় মিশুন",
      endLeft: "রাস্তার শেষে বাঁদিকে ঘুরুন", endRight: "রাস্তার শেষে ডানদিকে ঘুরুন",
      continue: "এগিয়ে চলুন",
    },
    directions: { north: "উত্তর", south: "দক্ষিণ", east: "পূর্ব", west: "পশ্চিম", "north-east": "উত্তর-পূর্ব", "north-west": "উত্তর-পশ্চিম", "south-east": "দক্ষিণ-পূর্ব", "south-west": "দক্ষিণ-পশ্চিম" },
    streetSuffix: " {street} সড়ক ধরে",
    text: {
      languageSelectorLabel: "কণ্ঠস্বরের পথনির্দেশের ভাষা",
      talkBackEnabled: "অ্যাপের কণ্ঠস্বর চালু। নাম শুনতে একবার এবং বেছে নিতে দুবার ট্যাপ করুন।",
      talkBackDisabled: "অ্যাপের কণ্ঠস্বর বন্ধ।",
      guidanceForSteps: "{count} কদম {action}।", guidanceInSteps: "{count} কদম পরে {action}।",
      navigationStarted: "পথনির্দেশ শুরু হয়েছে।", arrived: "আপনি আপনার গন্তব্যে পৌঁছে গেছেন।",
      gpsWait: "আপনার অবস্থানের জন্য অপেক্ষা করা হচ্ছে। অনুগ্রহ করে অবস্থানের অনুমতি দিন।",
      gpsDenied: "অবস্থানের অনুমতি দেওয়া হয়নি। ডিভাইসের সেটিংসে অবস্থানের অনুমতি দিন।",
      gpsUnavailable: "আপনার অবস্থান পাওয়া যাচ্ছে না। খোলা জায়গায় গিয়ে আবার চেষ্টা করুন।",
      gpsLost: "জিপিএস সংকেত হারিয়ে গেছে। আবার সংযোগের জন্য অপেক্ষা করা হচ্ছে।",
      gpsTimeout: "অবস্থানের অনুরোধের সময় শেষ হয়েছে। জিপিএস দেখে আবার চেষ্টা করুন।",
      gpsInaccurate: "নির্ভরযোগ্য পথনির্দেশের জন্য জিপিএসের নির্ভুলতা কম। ভালো সংকেতের জন্য অপেক্ষা করুন।",
      offline: "ইন্টারনেট সংযোগ নেই। অনলাইনে পথ খোঁজা যাচ্ছে না।",
      placeNotFound: "জায়গাটি পাওয়া যায়নি। আরও নির্দিষ্ট ঠিকানা দিয়ে চেষ্টা করুন।",
      routeFailed: "পথ নির্ণয় করা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।",
      rerouting: "আপনি পথ থেকে সরে গেছেন। নতুন হাঁটার পথ হিসাব করা হচ্ছে।",
      rerouteFailed: "নতুন হাঁটার পথ তৈরি করা যায়নি। পথনির্দেশ বন্ধ হয়েছে; আবার পথ বেছে নিন।",
      voiceChecking: "{language} ভাষার কণ্ঠস্বর খোঁজা হচ্ছে।",
      voiceAvailable: "{language} ভাষার কণ্ঠস্বর পাওয়া গেছে।",
      voiceUnavailable: "{language} ভাষার কণ্ঠস্বর ইনস্টল করা নেই। ডিভাইসের টেক্সট-টু-স্পিচ সেটিংসে এটি ইনস্টল করুন অথবা ইংরেজি বেছে নিন।",
      speechUnsupported: "এই ব্রাউজারে কথা বলার সুবিধা নেই। স্ক্রিন রিডারের জন্য লেখা পাওয়া যাবে।",
      speechError: "কণ্ঠস্বর চালানো যায়নি। ডিভাইসের টেক্সট-টু-স্পিচ সেটিং পরীক্ষা করুন।",
      languageSelected: "কণ্ঠস্বরের ভাষা {language} নির্বাচন করা হয়েছে।",
       obstacleAlert: "সতর্কতা। {zone} {object} রয়েছে।",
       objectDetected: "ক্যামেরায় {zone} {object} দেখা গেছে। দূরত্ব মাপা হয়নি।",
       obstacle: "বাধা",
       sosCountdown: "SOS অনুরোধটি {count} সেকেন্ডের মধ্যে নথিভুক্ত হবে। থামাতে বাতিল চাপুন।",
       sosCancelled: "SOS-এর কাউন্টডাউন বাতিল করা হয়েছে।",
       sosRecorded: "VisionPath-এ SOS অনুরোধ নথিভুক্ত হয়েছে। কোনো বার্তা পাঠানো হয়নি।",
       sosRecordFailed: "SOS অনুরোধ নথিভুক্ত করা যায়নি। কোনো বার্তা পাঠানো হয়নি।",
       sosMessage: "{name}-এর জরুরি SOS। আমার অবিলম্বে সাহায্য প্রয়োজন। আমার অবস্থান: {location}। অনুগ্রহ করে আমাকে ফোন করুন বা সাহায্য করতে আসুন। VisionPath-এর মাধ্যমে পাঠানো হয়েছে।",
    },
    zones: { left: "বাঁদিকে", centre: "সামনে", right: "ডানদিকে" },
    objects: {
      person: "ব্যক্তি", bicycle: "সাইকেল", car: "গাড়ি", motorcycle: "মোটরসাইকেল", bus: "বাস",
      train: "ট্রেন", truck: "ট্রাক", bench: "বেঞ্চ", chair: "চেয়ার", couch: "সোফা",
      "potted plant": "টবের গাছ", "dining table": "টেবিল", backpack: "ব্যাগ", umbrella: "ছাতা",
      dog: "কুকুর", bird: "পাখি", "traffic light": "ট্রাফিক লাইট", "stop sign": "স্টপ সাইন",
      suitcase: "স্যুটকেস", stroller: "শিশুর গাড়ি",
    },
  },
  te: {
    actions: {
      continueStraight: "నేరుగా కొనసాగండి", turnLeft: "ఎడమవైపు తిరగండి", turnRight: "కుడివైపు తిరగండి",
      sharpLeft: "తీవ్రంగా ఎడమవైపు తిరగండి", sharpRight: "తీవ్రంగా కుడివైపు తిరగండి",
      slightLeft: "కొద్దిగా ఎడమవైపు తిరగండి", slightRight: "కొద్దిగా కుడివైపు తిరగండి", uTurn: "యూ-టర్న్ తీసుకోండి",
      start: "నడక ప్రారంభించండి", startHeading: "{direction} వైపు నడక ప్రారంభించండి",
      arrive: "మీరు చేరుకున్నారు", roundabout: "రౌండ్‌అబౌట్‌లోకి ప్రవేశించండి",
      exitRoundabout: "రౌండ్‌అబౌట్‌ నుంచి బయటకు వెళ్లండి", keepLeft: "ఎడమవైపు ఉండండి",
      keepRight: "కుడివైపు ఉండండి", keep: "కొనసాగండి", merge: "దారిలో కలవండి",
      endLeft: "రోడ్డు చివర ఎడమవైపు తిరగండి", endRight: "రోడ్డు చివర కుడివైపు తిరగండి",
      continue: "కొనసాగండి",
    },
    directions: { north: "ఉత్తరం", south: "దక్షిణం", east: "తూర్పు", west: "పడమర", "north-east": "ఈశాన్యం", "north-west": "వాయువ్యం", "south-east": "ఆగ్నేయం", "south-west": "నైరుతి" },
    streetSuffix: " {street} రోడ్డుపై",
    text: {
      languageSelectorLabel: "వాయిస్ మార్గదర్శక భాష",
      talkBackEnabled: "యాప్ వాయిస్ సహాయం ఆన్‌లో ఉంది. పేరు వినడానికి ఒకసారి, ఎంచుకోవడానికి రెండుసార్లు నొక్కండి.",
      talkBackDisabled: "యాప్ వాయిస్ సహాయం ఆఫ్‌లో ఉంది.",
      guidanceForSteps: "{count} అడుగులు {action}.", guidanceInSteps: "{count} అడుగుల తర్వాత {action}.",
      navigationStarted: "దారి సూచన ప్రారంభమైంది.", arrived: "మీరు మీ గమ్యస్థానానికి చేరుకున్నారు.",
      gpsWait: "మీ స్థానం కోసం వేచి ఉంది. దయచేసి లొకేషన్ అనుమతించండి.",
      gpsDenied: "లొకేషన్ అనుమతి నిరాకరించబడింది. పరికర సెట్టింగ్‌లలో అనుమతి ఇవ్వండి.",
      gpsUnavailable: "మీ స్థానం అందుబాటులో లేదు. బహిరంగ ప్రదేశానికి వెళ్లి మళ్లీ ప్రయత్నించండి.",
      gpsLost: "GPS సిగ్నల్ పోయింది. మళ్లీ కనెక్ట్ అయ్యే వరకు వేచి ఉంది.",
      gpsTimeout: "లొకేషన్ అభ్యర్థన సమయం ముగిసింది. GPS తనిఖీ చేసి మళ్లీ ప్రయత్నించండి.",
      gpsInaccurate: "నమ్మకమైన మార్గదర్శకానికి GPS ఖచ్చితత్వం తక్కువగా ఉంది. మెరుగైన సిగ్నల్ కోసం వేచి ఉండండి.",
      offline: "ఇంటర్నెట్ కనెక్షన్ లేదు. ఆన్‌లైన్ దారి శోధన అందుబాటులో లేదు.",
      placeNotFound: "ప్రదేశం కనబడలేదు. మరింత నిర్దిష్ట చిరునామాతో ప్రయత్నించండి.",
      routeFailed: "దారిని లెక్కించలేకపోయాం. దయచేసి మళ్లీ ప్రయత్నించండి.",
      rerouting: "మీరు దారి తప్పారు. కొత్త నడక దారిని లెక్కిస్తున్నాం.",
      rerouteFailed: "కొత్త నడక దారిని కనుగొనలేకపోయాం. మార్గదర్శకాన్ని ఆపాం; మళ్లీ దారిని ఎంచుకోండి.",
      voiceChecking: "{language} వాయిస్ కోసం తనిఖీ చేస్తోంది.",
      voiceAvailable: "{language} మాట్లాడే వాయిస్ అందుబాటులో ఉంది.",
      voiceUnavailable: "{language} వాయిస్ ఇన్‌స్టాల్ కాలేదు. పరికరంలోని టెక్స్ట్-టు-స్పీచ్ సెట్టింగ్‌లలో ఇన్‌స్టాల్ చేయండి లేదా ఇంగ్లీష్ ఎంచుకోండి.",
      speechUnsupported: "ఈ బ్రౌజర్‌లో వాయిస్ ప్లేబ్యాక్‌కు మద్దతు లేదు. స్క్రీన్ రీడర్ కోసం వచనం అందుబాటులో ఉంటుంది.",
      speechError: "వాయిస్ ప్లేబ్యాక్ విఫలమైంది. పరికర టెక్స్ట్-టు-స్పీచ్ సెట్టింగ్‌లను తనిఖీ చేయండి.",
      languageSelected: "వాయిస్ మార్గదర్శక భాష {language}గా ఎంచుకున్నారు.",
       obstacleAlert: "హెచ్చరిక. {zone} {object} ఉంది.",
       objectDetected: "కెమెరాలో {zone} {object} కనిపించింది. దూరం కొలవబడలేదు.",
       obstacle: "అడ్డంకి",
       sosCountdown: "SOS అభ్యర్థన {count} సెకన్లలో నమోదు అవుతుంది. ఆపడానికి రద్దు చేయండి.",
       sosCancelled: "SOS కౌంట్‌డౌన్ రద్దు చేయబడింది.",
       sosRecorded: "SOS అభ్యర్థన VisionPath‌లో నమోదు చేయబడింది. సందేశం పంపబడలేదు.",
       sosRecordFailed: "SOS అభ్యర్థనను నమోదు చేయలేకపోయాం. సందేశం పంపబడలేదు.",
       sosMessage: "{name} నుండి అత్యవసర SOS. నాకు వెంటనే సహాయం కావాలి. నా స్థానం: {location}. దయచేసి నాకు కాల్ చేయండి లేదా సహాయం చేయడానికి రండి. VisionPath ద్వారా పంపబడింది.",
    },
    zones: { left: "ఎడమవైపు", centre: "నేరుగా ముందు", right: "కుడివైపు" },
    objects: {
      person: "వ్యక్తి", bicycle: "సైకిల్", car: "కారు", motorcycle: "మోటార్‌సైకిల్", bus: "బస్సు",
      train: "రైలు", truck: "ట్రక్కు", bench: "బెంచీ", chair: "కుర్చీ", couch: "సోఫా",
      "potted plant": "కుండీలో మొక్క", "dining table": "బల్ల", backpack: "బ్యాగ్", umbrella: "గొడుగు",
      dog: "కుక్క", bird: "పక్షి", "traffic light": "ట్రాఫిక్ లైట్", "stop sign": "స్టాప్ సైన్",
      suitcase: "సూట్‌కేస్", stroller: "పిల్లల బండి",
    },
  },
  ta: {
    actions: {
      continueStraight: "நேராகத் தொடர்ந்து செல்லவும்", turnLeft: "இடதுபுறம் திரும்பவும்", turnRight: "வலதுபுறம் திரும்பவும்",
      sharpLeft: "தீவிரமாக இடதுபுறம் திரும்பவும்", sharpRight: "தீவிரமாக வலதுபுறம் திரும்பவும்",
      slightLeft: "சற்றே இடதுபுறம் திரும்பவும்", slightRight: "சற்றே வலதுபுறம் திரும்பவும்", uTurn: "யூ-டர்ன் எடுக்கவும்",
      start: "நடக்கத் தொடங்கவும்", startHeading: "{direction} திசையில் நடக்கத் தொடங்கவும்",
      arrive: "நீங்கள் வந்துவிட்டீர்கள்", roundabout: "சுற்றுவட்டச் சாலையில் நுழையவும்",
      exitRoundabout: "சுற்றுவட்டச் சாலையிலிருந்து வெளியேறவும்", keepLeft: "இடதுபுறமாகச் செல்லவும்",
      keepRight: "வலதுபுறமாகச் செல்லவும்", keep: "தொடர்ந்து செல்லவும்", merge: "சாலையில் இணையவும்",
      endLeft: "சாலையின் முடிவில் இடதுபுறம் திரும்பவும்", endRight: "சாலையின் முடிவில் வலதுபுறம் திரும்பவும்",
      continue: "தொடர்ந்து செல்லவும்",
    },
    directions: { north: "வடக்கு", south: "தெற்கு", east: "கிழக்கு", west: "மேற்கு", "north-east": "வடகிழக்கு", "north-west": "வடமேற்கு", "south-east": "தென்கிழக்கு", "south-west": "தென்மேற்கு" },
    streetSuffix: " {street} சாலையில்",
    text: {
      languageSelectorLabel: "குரல் வழிகாட்டல் மொழி",
      talkBackEnabled: "செயலி குரல் உதவி இயக்கத்தில் உள்ளது. பெயரைக் கேட்க ஒருமுறை, தேர்ந்தெடுக்க இருமுறை தட்டவும்.",
      talkBackDisabled: "செயலி குரல் உதவி நிறுத்தப்பட்டுள்ளது.",
      guidanceForSteps: "{count} அடிகள் {action}.", guidanceInSteps: "{count} அடிகள் கழித்து {action}.",
      navigationStarted: "வழிகாட்டல் தொடங்கியது.", arrived: "நீங்கள் உங்கள் இலக்கை அடைந்துவிட்டீர்கள்.",
      gpsWait: "உங்கள் இருப்பிடத்திற்காகக் காத்திருக்கிறது. இருப்பிட அனுமதியை வழங்கவும்.",
      gpsDenied: "இருப்பிட அனுமதி மறுக்கப்பட்டது. சாதன அமைப்புகளில் இருப்பிட அனுமதியை வழங்கவும்.",
      gpsUnavailable: "உங்கள் இருப்பிடம் கிடைக்கவில்லை. திறந்த இடத்திற்குச் சென்று மீண்டும் முயற்சிக்கவும்.",
      gpsLost: "GPS இணைப்பு துண்டிக்கப்பட்டது. மீண்டும் இணையும் வரை காத்திருக்கிறது.",
      gpsTimeout: "இருப்பிடக் கோரிக்கைக்கான நேரம் முடிந்தது. GPS-ஐச் சரிபார்த்து மீண்டும் முயற்சிக்கவும்.",
      gpsInaccurate: "நம்பகமான வழிகாட்டலுக்கு GPS துல்லியம் குறைவாக உள்ளது. சிறந்த சிக்னலுக்காகக் காத்திருக்கவும்.",
      offline: "இணைய இணைப்பு இல்லை. இணையவழி பாதைத் தேடல் கிடைக்கவில்லை.",
      placeNotFound: "இடம் கிடைக்கவில்லை. இன்னும் குறிப்பான முகவரியை முயற்சிக்கவும்.",
      routeFailed: "பாதையைக் கணக்கிட முடியவில்லை. மீண்டும் முயற்சிக்கவும்.",
      rerouting: "நீங்கள் பாதையிலிருந்து விலகியுள்ளீர்கள். புதிய நடைபாதை கணக்கிடப்படுகிறது.",
      rerouteFailed: "புதிய நடைபாதையைக் கணக்கிட முடியவில்லை. வழிகாட்டல் நிறுத்தப்பட்டது; மீண்டும் பாதையைத் தேர்ந்தெடுக்கவும்.",
      voiceChecking: "{language} குரல் உள்ளதா எனச் சரிபார்க்கிறது.",
      voiceAvailable: "{language} குரல் கிடைக்கிறது.",
      voiceUnavailable: "{language} குரல் நிறுவப்படவில்லை. சாதனத்தின் உரை-பேச்சு அமைப்புகளில் நிறுவவும் அல்லது ஆங்கிலத்தைத் தேர்ந்தெடுக்கவும்.",
      speechUnsupported: "இந்த உலாவியில் குரல் இயக்கம் ஆதரிக்கப்படவில்லை. திரை வாசிப்புக்கான உரை கிடைக்கும்.",
      speechError: "குரலை இயக்க முடியவில்லை. சாதனத்தின் உரை-பேச்சு அமைப்புகளைச் சரிபார்க்கவும்.",
      languageSelected: "குரல் வழிகாட்டல் மொழி {language} எனத் தேர்ந்தெடுக்கப்பட்டது.",
       obstacleAlert: "எச்சரிக்கை. {zone} {object} உள்ளது.",
       objectDetected: "கேமராவில் {zone} {object} தென்பட்டது. தூரம் அளவிடப்படவில்லை.",
       obstacle: "தடை",
       sosCountdown: "SOS கோரிக்கை {count} விநாடிகளில் பதிவு செய்யப்படும். நிறுத்த ரத்துசெய் என்பதைத் தட்டவும்.",
       sosCancelled: "SOS கவுண்ட்டவுன் ரத்து செய்யப்பட்டது.",
       sosRecorded: "SOS கோரிக்கை VisionPath-இல் பதிவு செய்யப்பட்டது. எந்தச் செய்தியும் அனுப்பப்படவில்லை.",
       sosRecordFailed: "SOS கோரிக்கையைப் பதிவு செய்ய முடியவில்லை. எந்தச் செய்தியும் அனுப்பப்படவில்லை.",
       sosMessage: "{name} அனுப்பும் அவசர SOS. எனக்கு உடனடி உதவி தேவை. எனது இருப்பிடம்: {location}. தயவுசெய்து என்னை அழைக்கவும் அல்லது உதவிக்கு வரவும். VisionPath வழியாக அனுப்பப்பட்டது.",
    },
    zones: { left: "இடதுபுறத்தில்", centre: "நேராக முன்னால்", right: "வலதுபுறத்தில்" },
    objects: {
      person: "நபர்", bicycle: "மிதிவண்டி", car: "கார்", motorcycle: "மோட்டார் சைக்கிள்", bus: "பேருந்து",
      train: "ரயில்", truck: "லாரி", bench: "நாற்காலி", chair: "நாற்காலி", couch: "சோபா",
      "potted plant": "தொட்டிச் செடி", "dining table": "மேசை", backpack: "முதுகுப்பை", umbrella: "குடை",
      dog: "நாய்", bird: "பறவை", "traffic light": "போக்குவரத்து விளக்கு", "stop sign": "நிறுத்தக் குறி",
      suitcase: "பெட்டிப்பை", stroller: "குழந்தை வண்டி",
    },
  },
  mr: {
    actions: {
      continueStraight: "सरळ पुढे चालत राहा", turnLeft: "डावीकडे वळा", turnRight: "उजवीकडे वळा",
      sharpLeft: "तीव्र डावीकडे वळा", sharpRight: "तीव्र उजवीकडे वळा",
      slightLeft: "थोडे डावीकडे वळा", slightRight: "थोडे उजवीकडे वळा", uTurn: "यू-टर्न घ्या",
      start: "चालायला सुरुवात करा", startHeading: "{direction} दिशेने चालायला सुरुवात करा",
      arrive: "तुम्ही पोहोचला आहात", roundabout: "गोलाकार चौकात प्रवेश करा",
      exitRoundabout: "गोलाकार चौकातून बाहेर पडा", keepLeft: "डावीकडे राहा",
      keepRight: "उजवीकडे राहा", keep: "पुढे चालत राहा", merge: "रस्त्यात सामील व्हा",
      endLeft: "रस्त्याच्या शेवटी डावीकडे वळा", endRight: "रस्त्याच्या शेवटी उजवीकडे वळा",
      continue: "पुढे जा",
    },
    directions: { north: "उत्तर", south: "दक्षिण", east: "पूर्व", west: "पश्चिम", "north-east": "ईशान्य", "north-west": "वायव्य", "south-east": "आग्नेय", "south-west": "नैऋत्य" },
    streetSuffix: " {street} रस्त्यावर",
    text: {
      languageSelectorLabel: "आवाज मार्गदर्शनाची भाषा",
      talkBackEnabled: "अॅपचा आवाज सुरू आहे. नाव ऐकण्यासाठी एकदा आणि निवडण्यासाठी दोनदा टॅप करा.",
      talkBackDisabled: "अॅपचा आवाज बंद आहे.",
      guidanceForSteps: "{count} पावले {action}.", guidanceInSteps: "{count} पावलांनंतर {action}.",
      navigationStarted: "मार्गदर्शन सुरू झाले.", arrived: "तुम्ही तुमच्या ठिकाणी पोहोचला आहात.",
      gpsWait: "तुमच्या ठिकाणाची वाट पाहत आहे. कृपया लोकेशनची परवानगी द्या.",
      gpsDenied: "लोकेशनची परवानगी नाकारली गेली. डिव्हाइस सेटिंग्जमध्ये परवानगी द्या.",
      gpsUnavailable: "तुमचे ठिकाण उपलब्ध नाही. मोकळ्या जागेत जाऊन पुन्हा प्रयत्न करा.",
      gpsLost: "GPS सिग्नल तुटला आहे. पुन्हा जोडण्याची वाट पाहत आहे.",
      gpsTimeout: "लोकेशन विनंतीची वेळ संपली. GPS तपासून पुन्हा प्रयत्न करा.",
      gpsInaccurate: "विश्वासार्ह मार्गदर्शनासाठी GPS अचूकता कमी आहे. चांगल्या सिग्नलची वाट पाहा.",
      offline: "इंटरनेट जोडणी नाही. ऑनलाइन मार्ग शोधता येणार नाही.",
      placeNotFound: "ठिकाण सापडले नाही. अधिक नेमका पत्ता टाकून पाहा.",
      routeFailed: "मार्ग काढता आला नाही. कृपया पुन्हा प्रयत्न करा.",
      rerouting: "तुम्ही मार्गापासून दूर गेला आहात. पायी जाण्याचा नवीन मार्ग काढत आहे.",
      rerouteFailed: "पायी जाण्याचा नवीन मार्ग काढता आला नाही. मार्गदर्शन थांबवले आहे; पुन्हा मार्ग निवडा.",
      voiceChecking: "{language} आवाज उपलब्ध आहे का ते तपासत आहे.",
      voiceAvailable: "{language} आवाज उपलब्ध आहे.",
      voiceUnavailable: "{language} आवाज इन्स्टॉल केलेला नाही. डिव्हाइसच्या टेक्स्ट-टू-स्पीच सेटिंग्जमध्ये इन्स्टॉल करा किंवा इंग्रजी निवडा.",
      speechUnsupported: "या ब्राउझरमध्ये आवाज चालवण्याची सुविधा नाही. स्क्रीन रीडरसाठी मजकूर उपलब्ध राहील.",
      speechError: "आवाज चालवता आला नाही. डिव्हाइसची टेक्स्ट-टू-स्पीच सेटिंग तपासा.",
      languageSelected: "आवाज मार्गदर्शनाची भाषा {language} निवडली आहे.",
       obstacleAlert: "सावधान. {zone} {object} आहे.",
       objectDetected: "कॅमेऱ्यात {zone} {object} दिसत आहे. अंतर मोजलेले नाही.",
       obstacle: "अडथळा",
       sosCountdown: "SOS विनंती {count} सेकंदांत नोंदवली जाईल. थांबवण्यासाठी रद्द करा दाबा.",
       sosCancelled: "SOS ची उलटी गिनती रद्द केली.",
       sosRecorded: "SOS विनंती VisionPath मध्ये नोंदवली. कोणताही संदेश पाठवला नाही.",
       sosRecordFailed: "SOS विनंती नोंदवता आली नाही. कोणताही संदेश पाठवला नाही.",
       sosMessage: "{name} कडून आपत्कालीन SOS. मला तातडीने मदत हवी आहे. माझे ठिकाण: {location}. कृपया मला फोन करा किंवा मदतीसाठी या. VisionPath द्वारे पाठवले.",
    },
    zones: { left: "डावीकडे", centre: "अगदी समोर", right: "उजवीकडे" },
    objects: {
      person: "व्यक्ती", bicycle: "सायकल", car: "कार", motorcycle: "मोटारसायकल", bus: "बस",
      train: "रेल्वे", truck: "ट्रक", bench: "बाक", chair: "खुर्ची", couch: "सोफा",
      "potted plant": "कुंडीतील रोप", "dining table": "टेबल", backpack: "पाठीवरील पिशवी", umbrella: "छत्री",
      dog: "कुत्रा", bird: "पक्षी", "traffic light": "वाहतूक दिवा", "stop sign": "थांबा चिन्ह",
      suitcase: "सूटकेस", stroller: "बाळाची गाडी",
    },
  },
  gu: {
    actions: {
      continueStraight: "સીધા આગળ વધતા રહો", turnLeft: "ડાબે વળો", turnRight: "જમણે વળો",
      sharpLeft: "તીવ્ર ડાબે વળો", sharpRight: "તીવ્ર જમણે વળો",
      slightLeft: "થોડા ડાબે વળો", slightRight: "થોડા જમણે વળો", uTurn: "યુ-ટર્ન લો",
      start: "ચાલવાનું શરૂ કરો", startHeading: "{direction} દિશામાં ચાલવાનું શરૂ કરો",
      arrive: "તમે પહોંચી ગયા છો", roundabout: "ગોળ ચક્કરમાં પ્રવેશો",
      exitRoundabout: "ગોળ ચક્કરમાંથી બહાર નીકળો", keepLeft: "ડાબી બાજુ રહો",
      keepRight: "જમણી બાજુ રહો", keep: "આગળ વધતા રહો", merge: "રસ્તામાં જોડાઓ",
      endLeft: "રસ્તાના અંતે ડાબે વળો", endRight: "રસ્તાના અંતે જમણે વળો",
      continue: "આગળ વધો",
    },
    directions: { north: "ઉત્તર", south: "દક્ષિણ", east: "પૂર્વ", west: "પશ્ચિમ", "north-east": "ઉત્તર-પૂર્વ", "north-west": "ઉત્તર-પશ્ચિમ", "south-east": "દક્ષિણ-પૂર્વ", "south-west": "દક્ષિણ-પશ્ચિમ" },
    streetSuffix: " {street} માર્ગ પર",
    text: {
      languageSelectorLabel: "અવાજ માર્ગદર્શનની ભાષા",
      talkBackEnabled: "ઍપનો અવાજ ચાલુ છે. નામ સાંભળવા એકવાર અને પસંદ કરવા બેવાર ટૅપ કરો.",
      talkBackDisabled: "ઍપનો અવાજ બંધ છે.",
      guidanceForSteps: "{count} પગલાં {action}.", guidanceInSteps: "{count} પગલાં પછી {action}.",
      navigationStarted: "માર્ગદર્શન શરૂ થયું.", arrived: "તમે તમારા ગંતવ્ય પર પહોંચી ગયા છો.",
      gpsWait: "તમારા સ્થાનની રાહ જોઈ રહ્યા છીએ. કૃપા કરીને સ્થાનની પરવાનગી આપો.",
      gpsDenied: "સ્થાનની પરવાનગી નકારી કાઢવામાં આવી. ઉપકરણ સેટિંગ્સમાં પરવાનગી આપો.",
      gpsUnavailable: "તમારું સ્થાન ઉપલબ્ધ નથી. ખુલ્લી જગ્યાએ જઈને ફરી પ્રયાસ કરો.",
      gpsLost: "GPS સિગ્નલ ખોવાઈ ગયું છે. ફરી જોડાવાની રાહ જોવાઈ રહી છે.",
      gpsTimeout: "સ્થાન વિનંતીનો સમય પૂરો થયો. GPS તપાસીને ફરી પ્રયાસ કરો.",
      gpsInaccurate: "વિશ્વસનીય માર્ગદર્શન માટે GPSની ચોકસાઈ ઓછી છે. સારા સિગ્નલની રાહ જુઓ.",
      offline: "ઇન્ટરનેટ કનેક્શન નથી. ઑનલાઇન માર્ગ શોધી શકાતો નથી.",
      placeNotFound: "સ્થળ મળ્યું નથી. વધુ ચોક્કસ સરનામું અજમાવો.",
      routeFailed: "માર્ગ ગણતરી થઈ શકી નથી. કૃપા કરીને ફરી પ્રયાસ કરો.",
      rerouting: "તમે માર્ગથી દૂર ગયા છો. ચાલવાનો નવો માર્ગ ગણતરીમાં છે.",
      rerouteFailed: "ચાલવાનો નવો માર્ગ મળી શક્યો નથી. માર્ગદર્શન બંધ થયું છે; ફરી માર્ગ પસંદ કરો.",
      voiceChecking: "{language} અવાજ તપાસી રહ્યા છીએ.",
      voiceAvailable: "{language} અવાજ ઉપલબ્ધ છે.",
      voiceUnavailable: "{language} અવાજ ઇન્સ્ટોલ નથી. ઉપકરણની ટેક્સ્ટ-ટુ-સ્પીચ સેટિંગ્સમાં ઇન્સ્ટોલ કરો અથવા અંગ્રેજી પસંદ કરો.",
      speechUnsupported: "આ બ્રાઉઝરમાં અવાજ ચલાવવાની સુવિધા નથી. સ્ક્રીન રીડર માટે લખાણ ઉપલબ્ધ રહેશે.",
      speechError: "અવાજ ચલાવી શકાયો નથી. ઉપકરણની ટેક્સ્ટ-ટુ-સ્પીચ સેટિંગ્સ તપાસો.",
      languageSelected: "અવાજ માર્ગદર્શનની ભાષા {language} પસંદ કરી છે.",
       obstacleAlert: "ચેતવણી. {zone} {object} છે.",
       objectDetected: "કેમેરામાં {zone} {object} દેખાય છે. અંતર માપવામાં આવ્યું નથી.",
       obstacle: "અવરોધ",
       sosCountdown: "SOS વિનંતી {count} સેકન્ડમાં નોંધાશે. રોકવા માટે રદ કરો પર ટૅપ કરો.",
       sosCancelled: "SOS કાઉન્ટડાઉન રદ થયું.",
       sosRecorded: "SOS વિનંતી VisionPathમાં નોંધાઈ. કોઈ સંદેશ મોકલાયો નથી.",
       sosRecordFailed: "SOS વિનંતી નોંધાઈ શકી નથી. કોઈ સંદેશ મોકલાયો નથી.",
       sosMessage: "{name} તરફથી કટોકટીનો SOS. મને તાત્કાલિક મદદ જોઈએ છે. મારું સ્થાન: {location}. કૃપા કરીને મને ફોન કરો અથવા મદદ કરવા આવો. VisionPath દ્વારા મોકલાયો.",
    },
    zones: { left: "ડાબી બાજુ", centre: "બરાબર સામે", right: "જમણી બાજુ" },
    objects: {
      person: "વ્યક્તિ", bicycle: "સાયકલ", car: "કાર", motorcycle: "મોટરસાયકલ", bus: "બસ",
      train: "ટ્રેન", truck: "ટ્રક", bench: "બેંચ", chair: "ખુરશી", couch: "સોફા",
      "potted plant": "કુંડાનો છોડ", "dining table": "ટેબલ", backpack: "થેલો", umbrella: "છત્રી",
      dog: "કૂતરો", bird: "પક્ષી", "traffic light": "ટ્રાફિક લાઇટ", "stop sign": "સ્ટોપ ચિહ્ન",
      suitcase: "સૂટકેસ", stroller: "બાળગાડી",
    },
  },
  kn: {
    actions: {
      continueStraight: "ನೇರವಾಗಿ ಮುಂದುವರಿಯಿರಿ", turnLeft: "ಎಡಕ್ಕೆ ತಿರುಗಿ", turnRight: "ಬಲಕ್ಕೆ ತಿರುಗಿ",
      sharpLeft: "ತೀವ್ರವಾಗಿ ಎಡಕ್ಕೆ ತಿರುಗಿ", sharpRight: "ತೀವ್ರವಾಗಿ ಬಲಕ್ಕೆ ತಿರುಗಿ",
      slightLeft: "ಸ್ವಲ್ಪ ಎಡಕ್ಕೆ ತಿರುಗಿ", slightRight: "ಸ್ವಲ್ಪ ಬಲಕ್ಕೆ ತಿರುಗಿ", uTurn: "ಯು-ಟರ್ನ್ ತೆಗೆದುಕೊಳ್ಳಿ",
      start: "ನಡೆಯಲು ಪ್ರಾರಂಭಿಸಿ", startHeading: "{direction} ದಿಕ್ಕಿನಲ್ಲಿ ನಡೆಯಲು ಪ್ರಾರಂಭಿಸಿ",
      arrive: "ನೀವು ತಲುಪಿದ್ದೀರಿ", roundabout: "ವೃತ್ತದಲ್ಲಿ ಪ್ರವೇಶಿಸಿ",
      exitRoundabout: "ವೃತ್ತದಿಂದ ಹೊರಬನ್ನಿ", keepLeft: "ಎಡಭಾಗದಲ್ಲಿರಿ",
      keepRight: "ಬಲಭಾಗದಲ್ಲಿರಿ", keep: "ಮುಂದುವರಿಯಿರಿ", merge: "ರಸ್ತೆಗೆ ಸೇರಿಕೊಳ್ಳಿ",
      endLeft: "ರಸ್ತೆಯ ಕೊನೆಯಲ್ಲಿ ಎಡಕ್ಕೆ ತಿರುಗಿ", endRight: "ರಸ್ತೆಯ ಕೊನೆಯಲ್ಲಿ ಬಲಕ್ಕೆ ತಿರುಗಿ",
      continue: "ಮುಂದುವರಿಯಿರಿ",
    },
    directions: { north: "ಉತ್ತರ", south: "ದಕ್ಷಿಣ", east: "ಪೂರ್ವ", west: "ಪಶ್ಚಿಮ", "north-east": "ಈಶಾನ್ಯ", "north-west": "ವಾಯವ್ಯ", "south-east": "ಆಗ್ನೇಯ", "south-west": "ನೈಋತ್ಯ" },
    streetSuffix: " {street} ರಸ್ತೆಯಲ್ಲಿ",
    text: {
      languageSelectorLabel: "ಧ್ವನಿ ಮಾರ್ಗದರ್ಶನದ ಭಾಷೆ",
      talkBackEnabled: "ಆ್ಯಪ್ ಧ್ವನಿ ಸಹಾಯಕ ಆನ್ ಆಗಿದೆ. ಹೆಸರನ್ನು ಕೇಳಲು ಒಮ್ಮೆ, ಆಯ್ಕೆ ಮಾಡಲು ಎರಡು ಬಾರಿ ಟ್ಯಾಪ್ ಮಾಡಿ.",
      talkBackDisabled: "ಆ್ಯಪ್ ಧ್ವನಿ ಸಹಾಯಕ ಆಫ್ ಆಗಿದೆ.",
      guidanceForSteps: "{count} ಹೆಜ್ಜೆ {action}.", guidanceInSteps: "{count} ಹೆಜ್ಜೆಗಳ ನಂತರ {action}.",
      navigationStarted: "ಮಾರ್ಗದರ್ಶನ ಪ್ರಾರಂಭವಾಗಿದೆ.", arrived: "ನೀವು ನಿಮ್ಮ ಗಮ್ಯಸ್ಥಾನವನ್ನು ತಲುಪಿದ್ದೀರಿ.",
      gpsWait: "ನಿಮ್ಮ ಸ್ಥಳಕ್ಕಾಗಿ ಕಾಯಲಾಗುತ್ತಿದೆ. ದಯವಿಟ್ಟು ಸ್ಥಳ ಅನುಮತಿಯನ್ನು ನೀಡಿ.",
      gpsDenied: "ಸ್ಥಳ ಅನುಮತಿಯನ್ನು ನಿರಾಕರಿಸಲಾಗಿದೆ. ಸಾಧನ ಸೆಟ್ಟಿಂಗ್‌ಗಳಲ್ಲಿ ಅನುಮತಿ ನೀಡಿ.",
      gpsUnavailable: "ನಿಮ್ಮ ಸ್ಥಳ ಲಭ್ಯವಿಲ್ಲ. ತೆರೆದ ಪ್ರದೇಶಕ್ಕೆ ಹೋಗಿ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.",
      gpsLost: "GPS ಸಂಕೇತ ಕಳೆದುಹೋಗಿದೆ. ಮತ್ತೆ ಸಂಪರ್ಕಕ್ಕಾಗಿ ಕಾಯಲಾಗುತ್ತಿದೆ.",
      gpsTimeout: "ಸ್ಥಳ ವಿನಂತಿಯ ಸಮಯ ಮುಗಿದಿದೆ. GPS ಪರಿಶೀಲಿಸಿ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.",
      gpsInaccurate: "ವಿಶ್ವಾಸಾರ್ಹ ಮಾರ್ಗದರ್ಶನಕ್ಕೆ GPS ನಿಖರತೆ ಕಡಿಮೆಯಾಗಿದೆ. ಉತ್ತಮ ಸಂಕೇತಕ್ಕಾಗಿ ಕಾಯಿರಿ.",
      offline: "ಇಂಟರ್ನೆಟ್ ಸಂಪರ್ಕವಿಲ್ಲ. ಆನ್‌ಲೈನ್ ಮಾರ್ಗ ಹುಡುಕಲು ಸಾಧ್ಯವಿಲ್ಲ.",
      placeNotFound: "ಸ್ಥಳ ಕಂಡುಬಂದಿಲ್ಲ. ಹೆಚ್ಚು ನಿರ್ದಿಷ್ಟ ವಿಳಾಸವನ್ನು ಪ್ರಯತ್ನಿಸಿ.",
      routeFailed: "ಮಾರ್ಗ ಲೆಕ್ಕಾಚಾರ ಸಾಧ್ಯವಾಗಲಿಲ್ಲ. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.",
      rerouting: "ನೀವು ಮಾರ್ಗದಿಂದ ಹೊರಗೆ ಹೋಗಿದ್ದೀರಿ. ಹೊಸ ಕಾಲ್ನಡಿಗೆ ಮಾರ್ಗವನ್ನು ಲೆಕ್ಕಿಸಲಾಗುತ್ತಿದೆ.",
      rerouteFailed: "ಹೊಸ ಕಾಲ್ನಡಿಗೆ ಮಾರ್ಗ ಸಿಗಲಿಲ್ಲ. ಮಾರ್ಗದರ್ಶನ ನಿಲ್ಲಿಸಲಾಗಿದೆ; ಮತ್ತೆ ಮಾರ್ಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ.",
      voiceChecking: "{language} ಧ್ವನಿಗಾಗಿ ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ.",
      voiceAvailable: "{language} ಧ್ವನಿ ಲಭ್ಯವಿದೆ.",
      voiceUnavailable: "{language} ಧ್ವನಿ ಸ್ಥಾಪಿತವಾಗಿಲ್ಲ. ಸಾಧನದ ಪಠ್ಯ-ಧ್ವನಿ ಸೆಟ್ಟಿಂಗ್‌ಗಳಲ್ಲಿ ಸ್ಥಾಪಿಸಿ ಅಥವಾ ಇಂಗ್ಲಿಷ್ ಆಯ್ಕೆಮಾಡಿ.",
      speechUnsupported: "ಈ ಬ್ರೌಸರ್‌ನಲ್ಲಿ ಧ್ವನಿ ಪ್ಲೇಬ್ಯಾಕ್ ಬೆಂಬಲಿತವಲ್ಲ. ಸ್ಕ್ರೀನ್ ರೀಡರ್ ಪಠ್ಯ ಲಭ್ಯವಿರುತ್ತದೆ.",
      speechError: "ಧ್ವನಿ ಪ್ಲೇಬ್ಯಾಕ್ ವಿಫಲವಾಗಿದೆ. ಸಾಧನದ ಪಠ್ಯ-ಧ್ವನಿ ಸೆಟ್ಟಿಂಗ್‌ಗಳನ್ನು ಪರಿಶೀಲಿಸಿ.",
      languageSelected: "ಧ್ವನಿ ಮಾರ್ಗದರ್ಶನದ ಭಾಷೆಯನ್ನು {language} ಎಂದು ಆಯ್ಕೆ ಮಾಡಲಾಗಿದೆ.",
       obstacleAlert: "ಎಚ್ಚರಿಕೆ. {zone} {object} ಇದೆ.",
       objectDetected: "ಕ್ಯಾಮೆರಾದಲ್ಲಿ {zone} {object} ಕಾಣಿಸಿದೆ. ದೂರವನ್ನು ಅಳೆಯಲಾಗಿಲ್ಲ.",
       obstacle: "ಅಡಚಣೆ",
       sosCountdown: "SOS ವಿನಂತಿಯನ್ನು {count} ಸೆಕೆಂಡುಗಳಲ್ಲಿ ದಾಖಲಿಸಲಾಗುತ್ತದೆ. ನಿಲ್ಲಿಸಲು ರದ್ದುಮಾಡಿ ಎಂದು ಟ್ಯಾಪ್ ಮಾಡಿ.",
       sosCancelled: "SOS ಕೌಂಟ್‌ಡೌನ್ ರದ್ದುಗೊಳಿಸಲಾಗಿದೆ.",
       sosRecorded: "SOS ವಿನಂತಿಯನ್ನು VisionPath‌ನಲ್ಲಿ ದಾಖಲಿಸಲಾಗಿದೆ. ಯಾವುದೇ ಸಂದೇಶವನ್ನು ಕಳುಹಿಸಲಾಗಿಲ್ಲ.",
       sosRecordFailed: "SOS ವಿನಂತಿಯನ್ನು ದಾಖಲಿಸಲಾಗಲಿಲ್ಲ. ಯಾವುದೇ ಸಂದೇಶವನ್ನು ಕಳುಹಿಸಲಾಗಿಲ್ಲ.",
       sosMessage: "{name} ಅವರ ತುರ್ತು SOS. ನನಗೆ ತಕ್ಷಣ ಸಹಾಯ ಬೇಕು. ನನ್ನ ಸ್ಥಳ: {location}. ದಯವಿಟ್ಟು ನನಗೆ ಕರೆ ಮಾಡಿ ಅಥವಾ ಸಹಾಯಕ್ಕೆ ಬನ್ನಿ. VisionPath ಮೂಲಕ ಕಳುಹಿಸಲಾಗಿದೆ.",
    },
    zones: { left: "ಎಡಭಾಗದಲ್ಲಿ", centre: "ನೇರವಾಗಿ ಮುಂದೆ", right: "ಬಲಭಾಗದಲ್ಲಿ" },
    objects: {
      person: "ವ್ಯಕ್ತಿ", bicycle: "ಸೈಕಲ್", car: "ಕಾರು", motorcycle: "ಮೋಟಾರ್‌ಸೈಕಲ್", bus: "ಬಸ್",
      train: "ರೈಲು", truck: "ಟ್ರಕ್", bench: "ಬೆಂಚ್", chair: "ಕುರ್ಚಿ", couch: "ಸೋಫಾ",
      "potted plant": "ಕುಂಡದ ಗಿಡ", "dining table": "ಮೇಜು", backpack: "ಬೆನ್ನುಚೀಲ", umbrella: "ಛತ್ರಿ",
      dog: "ನಾಯಿ", bird: "ಹಕ್ಕಿ", "traffic light": "ಸಂಚಾರ ದೀಪ", "stop sign": "ನಿಲುಗಡೆ ಸೂಚನೆ",
      suitcase: "ಸೂಟ್‌ಕೇಸ್", stroller: "ಮಗುವಿನ ಗಾಡಿ",
    },
  },
  ml: {
    actions: {
      continueStraight: "നേരെ തുടരുക", turnLeft: "ഇടത്തോട്ട് തിരിയുക", turnRight: "വലത്തോട്ട് തിരിയുക",
      sharpLeft: "കുത്തനെ ഇടത്തോട്ട് തിരിയുക", sharpRight: "കുത്തനെ വലത്തോട്ട് തിരിയുക",
      slightLeft: "അൽപ്പം ഇടത്തോട്ട് തിരിയുക", slightRight: "അൽപ്പം വലത്തോട്ട് തിരിയുക", uTurn: "യു-ടേൺ എടുക്കുക",
      start: "നടക്കാൻ തുടങ്ങുക", startHeading: "{direction} ദിശയിൽ നടക്കാൻ തുടങ്ങുക",
      arrive: "നിങ്ങൾ എത്തിച്ചേർന്നു", roundabout: "റൗണ്ട്എബൗട്ടിലേക്ക് പ്രവേശിക്കുക",
      exitRoundabout: "റൗണ്ട്എബൗട്ടിൽ നിന്ന് പുറത്തുകടക്കുക", keepLeft: "ഇടതുവശം ചേർന്ന് പോകുക",
      keepRight: "വലതുവശം ചേർന്ന് പോകുക", keep: "തുടരുക", merge: "റോഡിൽ ചേരുക",
      endLeft: "റോഡിന്റെ അറ്റത്ത് ഇടത്തോട്ട് തിരിയുക", endRight: "റോഡിന്റെ അറ്റത്ത് വലത്തോട്ട് തിരിയുക",
      continue: "തുടരുക",
    },
    directions: { north: "വടക്ക്", south: "തെക്ക്", east: "കിഴക്ക്", west: "പടിഞ്ഞാറ്", "north-east": "വടക്കുകിഴക്ക്", "north-west": "വടക്കുപടിഞ്ഞാറ്", "south-east": "തെക്കുകിഴക്ക്", "south-west": "തെക്കുപടിഞ്ഞാറ്" },
    streetSuffix: " {street} റോഡിലൂടെ",
    text: {
      languageSelectorLabel: "ശബ്ദ വഴികാട്ടൽ ഭാഷ",
      talkBackEnabled: "ആപ്പിലെ ശബ്ദസഹായി ഓണാണ്. പേര് കേൾക്കാൻ ഒരിക്കൽ, തിരഞ്ഞെടുക്കാൻ രണ്ടുതവണ ടാപ്പ് ചെയ്യുക.",
      talkBackDisabled: "ആപ്പിലെ ശബ്ദസഹായി ഓഫാണ്.",
      guidanceForSteps: "{count} ചുവടുകൾ {action}.", guidanceInSteps: "{count} ചുവടുകൾ കഴിഞ്ഞ് {action}.",
      navigationStarted: "വഴികാട്ടൽ ആരംഭിച്ചു.", arrived: "നിങ്ങൾ ലക്ഷ്യസ്ഥാനത്ത് എത്തിച്ചേർന്നു.",
      gpsWait: "നിങ്ങളുടെ സ്ഥാനം കാത്തിരിക്കുന്നു. ലൊക്കേഷൻ അനുമതി നൽകുക.",
      gpsDenied: "ലൊക്കേഷൻ അനുമതി നിഷേധിച്ചു. ഉപകരണ ക്രമീകരണങ്ങളിൽ അനുമതി നൽകുക.",
      gpsUnavailable: "നിങ്ങളുടെ സ്ഥാനം ലഭ്യമല്ല. തുറസ്സായ സ്ഥലത്തേക്ക് പോയി വീണ്ടും ശ്രമിക്കുക.",
      gpsLost: "GPS സിഗ്നൽ നഷ്ടപ്പെട്ടു. വീണ്ടും ബന്ധിപ്പിക്കാൻ കാത്തിരിക്കുന്നു.",
      gpsTimeout: "ലൊക്കേഷൻ അഭ്യർത്ഥനയുടെ സമയം കഴിഞ്ഞു. GPS പരിശോധിച്ച് വീണ്ടും ശ്രമിക്കുക.",
      gpsInaccurate: "വിശ്വസനീയമായ വഴികാട്ടലിന് GPS കൃത്യത കുറവാണ്. മെച്ചപ്പെട്ട സിഗ്നലിനായി കാത്തിരിക്കുക.",
      offline: "ഇന്റർനെറ്റ് ബന്ധമില്ല. ഓൺലൈൻ വഴി തിരയാൻ കഴിയില്ല.",
      placeNotFound: "സ്ഥലം കണ്ടെത്താനായില്ല. കൂടുതൽ വ്യക്തമായ വിലാസം നൽകി ശ്രമിക്കുക.",
      routeFailed: "വഴി കണക്കാക്കാനായില്ല. വീണ്ടും ശ്രമിക്കുക.",
      rerouting: "നിങ്ങൾ വഴിയിൽ നിന്ന് മാറിയിരിക്കുന്നു. പുതിയ നടപ്പാത കണക്കാക്കുന്നു.",
      rerouteFailed: "പുതിയ നടപ്പാത കണ്ടെത്താനായില്ല. വഴികാട്ടൽ നിർത്തി; വീണ്ടും വഴി തിരഞ്ഞെടുക്കുക.",
      voiceChecking: "{language} ശബ്ദത്തിനായി പരിശോധിക്കുന്നു.",
      voiceAvailable: "{language} ശബ്ദം ലഭ്യമാണ്.",
      voiceUnavailable: "{language} ശബ്ദം ഇൻസ്റ്റാൾ ചെയ്തിട്ടില്ല. ഉപകരണത്തിലെ ടെക്സ്റ്റ്-ടു-സ്പീച്ച് ക്രമീകരണത്തിൽ ഇൻസ്റ്റാൾ ചെയ്യുക അല്ലെങ്കിൽ ഇംഗ്ലീഷ് തിരഞ്ഞെടുക്കുക.",
      speechUnsupported: "ഈ ബ്രൗസറിൽ ശബ്ദ പ്ലേബാക്ക് പിന്തുണയ്ക്കുന്നില്ല. സ്ക്രീൻ റീഡറിനുള്ള എഴുത്ത് ലഭ്യമാണ്.",
      speechError: "ശബ്ദം പ്ലേ ചെയ്യാനായില്ല. ഉപകരണത്തിലെ ടെക്സ്റ്റ്-ടു-സ്പീച്ച് ക്രമീകരണം പരിശോധിക്കുക.",
      languageSelected: "ശബ്ദ വഴികാട്ടൽ ഭാഷ {language} ആയി തിരഞ്ഞെടുത്തു.",
       obstacleAlert: "മുന്നറിയിപ്പ്. {zone} {object} ഉണ്ട്.",
       objectDetected: "ക്യാമറയിൽ {zone} {object} കണ്ടു. ദൂരം അളന്നിട്ടില്ല.",
       obstacle: "തടസ്സം",
       sosCountdown: "SOS അഭ്യർത്ഥന {count} സെക്കൻഡിനുള്ളിൽ രേഖപ്പെടുത്തും. നിർത്താൻ റദ്ദാക്കുക തൊടുക.",
       sosCancelled: "SOS കൗണ്ട്ഡൗൺ റദ്ദാക്കി.",
       sosRecorded: "SOS അഭ്യർത്ഥന VisionPath-ൽ രേഖപ്പെടുത്തി. സന്ദേശമൊന്നും അയച്ചിട്ടില്ല.",
       sosRecordFailed: "SOS അഭ്യർത്ഥന രേഖപ്പെടുത്താനായില്ല. സന്ദേശമൊന്നും അയച്ചിട്ടില്ല.",
       sosMessage: "{name}-ന്റെ അടിയന്തര SOS. എനിക്ക് ഉടൻ സഹായം വേണം. എന്റെ സ്ഥലം: {location}. ദയവായി എന്നെ വിളിക്കുകയോ സഹായിക്കാൻ വരുകയോ ചെയ്യുക. VisionPath വഴി അയച്ചത്.",
    },
    zones: { left: "ഇടതുവശത്ത്", centre: "നേരെ മുന്നിൽ", right: "വലതുവശത്ത്" },
    objects: {
      person: "വ്യക്തി", bicycle: "സൈക്കിൾ", car: "കാർ", motorcycle: "മോട്ടോർസൈക്കിൾ", bus: "ബസ്",
      train: "ട്രെയിൻ", truck: "ട്രക്ക്", bench: "ബെഞ്ച്", chair: "കസേര", couch: "സോഫ",
      "potted plant": "ചട്ടിച്ചെടി", "dining table": "മേശ", backpack: "ബാഗ്", umbrella: "കുട",
      dog: "നായ", bird: "പക്ഷി", "traffic light": "ട്രാഫിക് ലൈറ്റ്", "stop sign": "സ്റ്റോപ്പ് അടയാളം",
      suitcase: "സ്യൂട്ട്കേസ്", stroller: "കുഞ്ഞുവണ്ടി",
    },
  },
  or: {
    actions: {
      continueStraight: "ସିଧା ଆଗକୁ ଚାଲନ୍ତୁ", turnLeft: "ବାମକୁ ମୋଡ଼ନ୍ତୁ", turnRight: "ଡାହାଣକୁ ମୋଡ଼ନ୍ତୁ",
      sharpLeft: "ତୀବ୍ର ଭାବେ ବାମକୁ ମୋଡ଼ନ୍ତୁ", sharpRight: "ତୀବ୍ର ଭାବେ ଡାହାଣକୁ ମୋଡ଼ନ୍ତୁ",
      slightLeft: "ସାମାନ୍ୟ ବାମକୁ ମୋଡ଼ନ୍ତୁ", slightRight: "ସାମାନ୍ୟ ଡାହାଣକୁ ମୋଡ଼ନ୍ତୁ", uTurn: "ୟୁ-ଟର୍ଣ୍ଣ ନିଅନ୍ତୁ",
      start: "ଚାଲିବା ଆରମ୍ଭ କରନ୍ତୁ", startHeading: "{direction} ଦିଗରେ ଚାଲିବା ଆରମ୍ଭ କରନ୍ତୁ",
      arrive: "ଆପଣ ପହଞ୍ଚିଗଲେ", roundabout: "ଗୋଲ ଛକରେ ପ୍ରବେଶ କରନ୍ତୁ",
      exitRoundabout: "ଗୋଲ ଛକରୁ ବାହାରକୁ ଯାଆନ୍ତୁ", keepLeft: "ବାମ ପଟେ ରୁହନ୍ତୁ",
      keepRight: "ଡାହାଣ ପଟେ ରୁହନ୍ତୁ", keep: "ଆଗକୁ ବଢ଼ନ୍ତୁ", merge: "ରାସ୍ତାରେ ମିଶନ୍ତୁ",
      endLeft: "ରାସ୍ତା ଶେଷରେ ବାମକୁ ମୋଡ଼ନ୍ତୁ", endRight: "ରାସ୍ତା ଶେଷରେ ଡାହାଣକୁ ମୋଡ଼ନ୍ତୁ",
      continue: "ଆଗକୁ ବଢ଼ନ୍ତୁ",
    },
    directions: { north: "ଉତ୍ତର", south: "ଦକ୍ଷିଣ", east: "ପୂର୍ବ", west: "ପଶ୍ଚିମ", "north-east": "ଉତ୍ତର-ପୂର୍ବ", "north-west": "ଉତ୍ତର-ପଶ୍ଚିମ", "south-east": "ଦକ୍ଷିଣ-ପୂର୍ବ", "south-west": "ଦକ୍ଷିଣ-ପଶ୍ଚିମ" },
    streetSuffix: " {street} ରାସ୍ତାରେ",
    text: {
      languageSelectorLabel: "ଧ୍ୱନି ଦିଗଦର୍ଶନର ଭାଷା",
      talkBackEnabled: "ଆପ୍‌ର ଧ୍ୱନି ସହାୟକ ଚାଲୁ ଅଛି। ନାମ ଶୁଣିବାକୁ ଥରେ ଏବଂ ବାଛିବାକୁ ଦୁଇଥର ଟ୍ୟାପ୍ କରନ୍ତୁ।",
      talkBackDisabled: "ଆପ୍‌ର ଧ୍ୱନି ସହାୟକ ବନ୍ଦ ଅଛି।",
      guidanceForSteps: "{count} ପାଦକ୍ଷେପ {action}।", guidanceInSteps: "{count} ପାଦକ୍ଷେପ ପରେ {action}।",
      navigationStarted: "ଦିଗଦର୍ଶନ ଆରମ୍ଭ ହେଲା।", arrived: "ଆପଣ ଗନ୍ତବ୍ୟସ୍ଥଳରେ ପହଞ୍ଚିଛନ୍ତି।",
      gpsWait: "ଆପଣଙ୍କ ଅବସ୍ଥାନ ପାଇଁ ଅପେକ୍ଷା କରାଯାଉଛି। ଅବସ୍ଥାନ ଅନୁମତି ଦିଅନ୍ତୁ।",
      gpsDenied: "ଅବସ୍ଥାନ ଅନୁମତି ମିଳିଲା ନାହିଁ। ଡିଭାଇସ୍ ସେଟିଂରେ ଅନୁମତି ଦିଅନ୍ତୁ।",
      gpsUnavailable: "ଆପଣଙ୍କ ଅବସ୍ଥାନ ମିଳୁନାହିଁ। ଖୋଲା ସ୍ଥାନକୁ ଯାଇ ପୁଣି ଚେଷ୍ଟା କରନ୍ତୁ।",
      gpsLost: "GPS ସଙ୍କେତ ହଜିଗଲା। ପୁଣି ସଂଯୋଗ ହେବାକୁ ଅପେକ୍ଷା କରାଯାଉଛି।",
      gpsTimeout: "ଅବସ୍ଥାନ ଅନୁରୋଧର ସମୟ ଶେଷ ହେଲା। GPS ଯାଞ୍ଚ କରି ପୁଣି ଚେଷ୍ଟା କରନ୍ତୁ।",
      gpsInaccurate: "ଭରସାଯୋଗ୍ୟ ଦିଗଦର୍ଶନ ପାଇଁ GPS ସଠିକତା କମ୍ ଅଛି। ଭଲ ସଙ୍କେତ ପାଇଁ ଅପେକ୍ଷା କରନ୍ତୁ।",
      offline: "ଇଣ୍ଟରନେଟ୍ ସଂଯୋଗ ନାହିଁ। ଅନଲାଇନ୍ ରାସ୍ତା ଖୋଜିବା ସମ୍ଭବ ନୁହେଁ।",
      placeNotFound: "ସ୍ଥାନ ମିଳିଲା ନାହିଁ। ଅଧିକ ସ୍ପଷ୍ଟ ଠିକଣା ଦେଇ ଚେଷ୍ଟା କରନ୍ତୁ।",
      routeFailed: "ରାସ୍ତା ଗଣନା ହୋଇପାରିଲା ନାହିଁ। ପୁଣି ଚେଷ୍ଟା କରନ୍ତୁ।",
      rerouting: "ଆପଣ ରାସ୍ତାରୁ ବାହାରିଯାଇଛନ୍ତି। ନୂଆ ପାଦଚଲା ରାସ୍ତା ଗଣନା ହେଉଛି।",
      rerouteFailed: "ନୂଆ ପାଦଚଲା ରାସ୍ତା ମିଳିଲା ନାହିଁ। ଦିଗଦର୍ଶନ ବନ୍ଦ; ପୁଣି ରାସ୍ତା ବାଛନ୍ତୁ।",
      voiceChecking: "{language} ଧ୍ୱନି ଯାଞ୍ଚ କରାଯାଉଛି।",
      voiceAvailable: "{language} ଧ୍ୱନି ଉପଲବ୍ଧ ଅଛି।",
      voiceUnavailable: "{language} ଧ୍ୱନି ସ୍ଥାପିତ ହୋଇନାହିଁ। ଡିଭାଇସର ଟେକ୍ସ୍ଟ-ଟୁ-ସ୍ପିଚ୍ ସେଟିଂରେ ସ୍ଥାପନ କରନ୍ତୁ କିମ୍ବା ଇଂରାଜୀ ବାଛନ୍ତୁ।",
      speechUnsupported: "ଏହି ବ୍ରାଉଜରରେ ଧ୍ୱନି ଚାଲିବା ସୁବିଧା ନାହିଁ। ସ୍କ୍ରିନ୍ ରିଡର ପାଇଁ ଲେଖା ଉପଲବ୍ଧ ରହିବ।",
      speechError: "ଧ୍ୱନି ଚାଲିଲା ନାହିଁ। ଡିଭାଇସର ଟେକ୍ସ୍ଟ-ଟୁ-ସ୍ପିଚ୍ ସେଟିଂ ଯାଞ୍ଚ କରନ୍ତୁ।",
      languageSelected: "ଧ୍ୱନି ଦିଗଦର୍ଶନର ଭାଷା {language} ବଛାଯାଇଛି।",
       obstacleAlert: "ସତର୍କତା। {zone} {object} ଅଛି।",
       objectDetected: "କ୍ୟାମେରାରେ {zone} {object} ଦେଖାଗଲା। ଦୂରତା ମପାଯାଇନାହିଁ।",
       obstacle: "ବାଧା",
       sosCountdown: "SOS ଅନୁରୋଧ {count} ସେକେଣ୍ଡରେ ରେକର୍ଡ ହେବ। ବନ୍ଦ କରିବାକୁ ବାତିଲ୍ ଦବାନ୍ତୁ।",
       sosCancelled: "SOS କାଉଣ୍ଟଡାଉନ୍ ବାତିଲ୍ ହୋଇଛି।",
       sosRecorded: "VisionPathରେ SOS ଅନୁରୋଧ ରେକର୍ଡ ହୋଇଛି। କୌଣସି ବାର୍ତ୍ତା ପଠାଯାଇନାହିଁ।",
       sosRecordFailed: "SOS ଅନୁରୋଧ ରେକର୍ଡ ହୋଇପାରିଲା ନାହିଁ। କୌଣସି ବାର୍ତ୍ତା ପଠାଯାଇନାହିଁ।",
       sosMessage: "{name}ଙ୍କ ଜରୁରୀ SOS। ମୋତେ ତୁରନ୍ତ ସାହାଯ୍ୟ ଦରକାର। ମୋର ଅବସ୍ଥାନ: {location}। ଦୟାକରି ମୋତେ ଫୋନ୍ କରନ୍ତୁ କିମ୍ବା ସାହାଯ୍ୟ ପାଇଁ ଆସନ୍ତୁ। VisionPath ମାଧ୍ୟମରେ ପଠାଯାଇଛି।",
    },
    zones: { left: "ବାମ ପଟେ", centre: "ଠିକ୍ ସାମ୍ନାରେ", right: "ଡାହାଣ ପଟେ" },
    objects: {
      person: "ବ୍ୟକ୍ତି", bicycle: "ସାଇକେଲ୍", car: "କାର୍", motorcycle: "ମୋଟରସାଇକେଲ୍", bus: "ବସ୍",
      train: "ଟ୍ରେନ୍", truck: "ଟ୍ରକ୍", bench: "ବେଞ୍ଚ୍", chair: "ଚେୟାର୍", couch: "ସୋଫା",
      "potted plant": "କୁଣ୍ଡର ଗଛ", "dining table": "ଟେବୁଲ୍", backpack: "ବ୍ୟାଗ୍", umbrella: "ଛତା",
      dog: "କୁକୁର", bird: "ପକ୍ଷୀ", "traffic light": "ଟ୍ରାଫିକ୍ ଲାଇଟ୍", "stop sign": "ଷ୍ଟପ୍ ସଙ୍କେତ",
      suitcase: "ସୁଟକେସ୍", stroller: "ଶିଶୁ ଗାଡ଼ି",
    },
  },
  as: {
    actions: {
      continueStraight: "পোনে পোনে গৈ থাকক", turnLeft: "বাওঁফালে ঘূৰক", turnRight: "সোঁফালে ঘূৰক",
      sharpLeft: "তীব্ৰভাৱে বাওঁফালে ঘূৰক", sharpRight: "তীব্ৰভাৱে সোঁফালে ঘূৰক",
      slightLeft: "অলপ বাওঁফালে ঘূৰক", slightRight: "অলপ সোঁফালে ঘূৰক", uTurn: "ইউ-টাৰ্ণ লওক",
      start: "খোজ কাঢ়িবলৈ আৰম্ভ কৰক", startHeading: "{direction} দিশে খোজ কাঢ়িবলৈ আৰম্ভ কৰক",
      arrive: "আপুনি পালেহি", roundabout: "ঘূৰণীয়া চক্ৰপথত প্ৰৱেশ কৰক",
      exitRoundabout: "ঘূৰণীয়া চক্ৰপথৰ পৰা ওলাই যাওক", keepLeft: "বাওঁফালে থাকক",
      keepRight: "সোঁফালে থাকক", keep: "আগবাঢ়ি যাওক", merge: "পথত মিলি যাওক",
      endLeft: "পথৰ শেষত বাওঁফালে ঘূৰক", endRight: "পথৰ শেষত সোঁফালে ঘূৰক",
      continue: "আগবাঢ়ি যাওক",
    },
    directions: { north: "উত্তৰ", south: "দক্ষিণ", east: "পূব", west: "পশ্চিম", "north-east": "উত্তৰ-পূব", "north-west": "উত্তৰ-পশ্চিম", "south-east": "দক্ষিণ-পূব", "south-west": "দক্ষিণ-পশ্চিম" },
    streetSuffix: " {street} পথত",
    text: {
      languageSelectorLabel: "কণ্ঠস্বৰৰ পথ-নিৰ্দেশনাৰ ভাষা",
      talkBackEnabled: "এপৰ কণ্ঠস্বৰ সহায়কটো চলি আছে। নাম শুনিবলৈ এবাৰ আৰু বাছনি কৰিবলৈ দুবাৰ টেপ কৰক।",
      talkBackDisabled: "এপৰ কণ্ঠস্বৰ সহায়কটো বন্ধ আছে।",
      guidanceForSteps: "{count} খোজ {action}।", guidanceInSteps: "{count} খোজৰ পিছত {action}।",
      navigationStarted: "পথ-নিৰ্দেশনা আৰম্ভ হৈছে।", arrived: "আপুনি গন্তব্যস্থানত উপস্থিত হৈছে।",
      gpsWait: "আপোনাৰ অৱস্থানৰ বাবে অপেক্ষা কৰা হৈছে। অনুগ্ৰহ কৰি অৱস্থানৰ অনুমতি দিয়ক।",
      gpsDenied: "অৱস্থানৰ অনুমতি দিয়া হোৱা নাই। ডিভাইচৰ ছেটিংছত অনুমতি দিয়ক।",
      gpsUnavailable: "আপোনাৰ অৱস্থান পোৱা নাই। মুকলি ঠাইলৈ গৈ পুনৰ চেষ্টা কৰক।",
      gpsLost: "GPS সংকেত হেৰাইছে। পুনৰ সংযোগৰ বাবে অপেক্ষা কৰা হৈছে।",
      gpsTimeout: "অৱস্থানৰ অনুৰোধৰ সময় শেষ হৈছে। GPS পৰীক্ষা কৰি পুনৰ চেষ্টা কৰক।",
      gpsInaccurate: "বিশ্বাসযোগ্য পথ-নিৰ্দেশৰ বাবে GPSৰ সঠিকতা কম। ভাল সংকেতৰ বাবে অপেক্ষা কৰক।",
      offline: "ইণ্টাৰনেট সংযোগ নাই। অনলাইন পথ বিচৰা সম্ভৱ নহয়।",
      placeNotFound: "ঠাইখন পোৱা নগ'ল। অধিক নিৰ্দিষ্ট ঠিকনা দি চেষ্টা কৰক।",
      routeFailed: "পথ গণনা কৰিব পৰা নগ'ল। অনুগ্ৰহ কৰি পুনৰ চেষ্টা কৰক।",
      rerouting: "আপুনি পথৰ পৰা আঁতৰি গৈছে। নতুন খোজকাঢ়ি যোৱাৰ পথ গণনা কৰা হৈছে।",
      rerouteFailed: "নতুন খোজকাঢ়ি যোৱাৰ পথ পোৱা নগ'ল। পথ-নিৰ্দেশ বন্ধ কৰা হৈছে; পুনৰ পথ বাছক।",
      voiceChecking: "{language} কণ্ঠস্বৰ বিচৰা হৈছে।",
      voiceAvailable: "{language} কণ্ঠস্বৰ উপলব্ধ।",
      voiceUnavailable: "{language} কণ্ঠস্বৰ ইনষ্টল কৰা নাই। ডিভাইচৰ টেক্সট-টু-স্পীচ ছেটিংছত ইনষ্টল কৰক অথবা ইংৰাজী বাছক।",
      speechUnsupported: "এই ব্ৰাউজাৰত কণ্ঠস্বৰ চলোৱা সমৰ্থিত নহয়। স্ক্ৰীণ ৰিডাৰৰ বাবে লিখনী উপলব্ধ থাকিব।",
      speechError: "কণ্ঠস্বৰ চলাব পৰা নগ'ল। ডিভাইচৰ টেক্সট-টু-স্পীচ ছেটিংছ পৰীক্ষা কৰক।",
      languageSelected: "কণ্ঠস্বৰ পথ-নিৰ্দেশনাৰ ভাষা {language} বাছনি কৰা হৈছে।",
      obstacleAlert: "সাৱধান। {zone} {object} আছে।",
      objectDetected: "কেমেৰাত {zone} {object} দেখা গৈছে। দূৰত্ব জোখা হোৱা নাই।",
      obstacle: "বাধা",
      sosCountdown: "SOS অনুৰোধ {count} ছেকেণ্ডত ৰেকৰ্ড কৰা হ’ব। বন্ধ কৰিবলৈ বাতিল টিপক।",
      sosCancelled: "SOS কাউণ্টডাউন বাতিল কৰা হৈছে।",
      sosRecorded: "VisionPathত SOS অনুৰোধ ৰেকৰ্ড কৰা হৈছে। কোনো বাৰ্তা পঠিওৱা হোৱা নাই।",
      sosRecordFailed: "SOS অনুৰোধ ৰেকৰ্ড কৰিব পৰা নগ’ল। কোনো বাৰ্তা পঠিওৱা হোৱা নাই।",
      sosMessage: "{name}ৰ জৰুৰী SOS। মোক তৎক্ষণাৎ সহায় লাগে। মোৰ অৱস্থান: {location}। অনুগ্ৰহ কৰি মোক ফোন কৰক বা সহায় কৰিবলৈ আহক। VisionPathৰ জৰিয়তে পঠিওৱা হৈছে।",
    },
    zones: { left: "বাওঁফালে", centre: "ঠিক সন্মুখত", right: "সোঁফালে" },
    objects: {
      person: "ব্যক্তি", bicycle: "চাইকেল", car: "গাড়ী", motorcycle: "মটৰচাইকেল", bus: "বাছ",
      train: "ৰেল", truck: "ট্ৰাক", bench: "বেঞ্চ", chair: "চকী", couch: "চোফা",
      "potted plant": "টাবৰ গছ", "dining table": "মেজ", backpack: "বেগ", umbrella: "ছাতি",
      dog: "কুকুৰ", bird: "চৰাই", "traffic light": "ট্ৰেফিক লাইট", "stop sign": "ষ্টপ চিহ্ন",
      suitcase: "ছুটকেছ", stroller: "শিশুৰ গাড়ী",
    },
  },
  ur: {
    actions: {
      continueStraight: "سیدھے چلتے رہیں", turnLeft: "بائیں مڑیں", turnRight: "دائیں مڑیں",
      sharpLeft: "تیزی سے بائیں مڑیں", sharpRight: "تیزی سے دائیں مڑیں",
      slightLeft: "ذرا بائیں مڑیں", slightRight: "ذرا دائیں مڑیں", uTurn: "یو ٹرن لیں",
      start: "چلنا شروع کریں", startHeading: "{direction} کی سمت چلنا شروع کریں",
      arrive: "آپ پہنچ گئے ہیں", roundabout: "گول چکر میں داخل ہوں",
      exitRoundabout: "گول چکر سے باہر نکلیں", keepLeft: "بائیں جانب رہیں",
      keepRight: "دائیں جانب رہیں", keep: "آگے بڑھتے رہیں", merge: "سڑک میں شامل ہوں",
      endLeft: "سڑک کے آخر میں بائیں مڑیں", endRight: "سڑک کے آخر میں دائیں مڑیں",
      continue: "آگے بڑھیں",
    },
    directions: { north: "شمال", south: "جنوب", east: "مشرق", west: "مغرب", "north-east": "شمال مشرق", "north-west": "شمال مغرب", "south-east": "جنوب مشرق", "south-west": "جنوب مغرب" },
    streetSuffix: " {street} سڑک پر",
    text: {
      languageSelectorLabel: "آواز کی رہنمائی کی زبان",
      talkBackEnabled: "ایپ کی آواز کی سہولت آن ہے۔ نام سننے کے لیے ایک بار اور منتخب کرنے کے لیے دو بار ٹیپ کریں۔",
      talkBackDisabled: "ایپ کی آواز کی سہولت بند ہے۔",
      guidanceForSteps: "{count} قدم {action}۔", guidanceInSteps: "{count} قدم بعد {action}۔",
      navigationStarted: "راستہ دکھانا شروع ہو گیا ہے۔", arrived: "آپ اپنی منزل پر پہنچ گئے ہیں۔",
      gpsWait: "آپ کے مقام کا انتظار ہے۔ براہ کرم مقام کی اجازت دیں۔",
      gpsDenied: "مقام کی اجازت نہیں دی گئی۔ آلے کی ترتیبات میں مقام کی اجازت دیں۔",
      gpsUnavailable: "آپ کا مقام دستیاب نہیں۔ کھلی جگہ پر جا کر دوبارہ کوشش کریں۔",
      gpsLost: "GPS سگنل ختم ہو گیا ہے۔ دوبارہ رابطے کا انتظار ہے۔",
      gpsTimeout: "مقام کی درخواست کا وقت ختم ہو گیا۔ GPS دیکھ کر دوبارہ کوشش کریں۔",
      gpsInaccurate: "قابلِ اعتماد رہنمائی کے لیے GPS کی درستگی کم ہے۔ بہتر سگنل کا انتظار کریں۔",
      offline: "انٹرنیٹ رابطہ نہیں ہے۔ آن لائن راستہ تلاش نہیں کیا جا سکتا۔",
      placeNotFound: "جگہ نہیں ملی۔ زیادہ واضح پتہ درج کر کے کوشش کریں۔",
      routeFailed: "راستہ نہیں بن سکا۔ براہ کرم دوبارہ کوشش کریں۔",
      rerouting: "آپ راستے سے ہٹ گئے ہیں۔ نیا پیدل راستہ نکالا جا رہا ہے۔",
      rerouteFailed: "نیا پیدل راستہ نہیں مل سکا۔ رہنمائی روک دی گئی ہے؛ دوبارہ راستہ منتخب کریں۔",
      voiceChecking: "{language} کی آواز تلاش کی جا رہی ہے۔",
      voiceAvailable: "{language} کی آواز دستیاب ہے۔",
      voiceUnavailable: "{language} کی آواز انسٹال نہیں ہے۔ آلے کی متن سے آواز کی ترتیبات میں انسٹال کریں یا انگریزی منتخب کریں۔",
      speechUnsupported: "یہ براؤزر آواز چلانے کی سہولت نہیں دیتا۔ اسکرین ریڈر کے لیے متن دستیاب رہے گا۔",
      speechError: "آواز نہیں چل سکی۔ آلے کی متن سے آواز کی ترتیبات دیکھیں۔",
      languageSelected: "آواز کی رہنمائی کی زبان {language} منتخب کی گئی ہے۔",
       obstacleAlert: "خبردار۔ {zone} {object} ہے۔",
       objectDetected: "کیمرے میں {zone} {object} نظر آیا۔ فاصلہ نہیں ناپا گیا۔",
       obstacle: "رکاوٹ",
       sosCountdown: "SOS درخواست {count} سیکنڈ میں درج کی جائے گی۔ روکنے کے لیے منسوخ کریں پر ٹیپ کریں۔",
       sosCancelled: "SOS کی الٹی گنتی منسوخ کر دی گئی۔",
       sosRecorded: "VisionPath میں SOS درخواست درج ہو گئی۔ کوئی پیغام نہیں بھیجا گیا۔",
       sosRecordFailed: "SOS درخواست درج نہیں ہو سکی۔ کوئی پیغام نہیں بھیجا گیا۔",
       sosMessage: "{name} کی طرف سے ہنگامی SOS۔ مجھے فوری مدد چاہیے۔ میرا مقام: {location}۔ براہ کرم مجھے کال کریں یا مدد کے لیے آئیں۔ VisionPath کے ذریعے بھیجا گیا۔",
    },
    zones: { left: "بائیں طرف", centre: "بالکل سامنے", right: "دائیں طرف" },
    objects: {
      person: "شخص", bicycle: "سائیکل", car: "گاڑی", motorcycle: "موٹر سائیکل", bus: "بس",
      train: "ٹرین", truck: "ٹرک", bench: "بینچ", chair: "کرسی", couch: "صوفہ",
      "potted plant": "گملے کا پودا", "dining table": "میز", backpack: "بیگ", umbrella: "چھتری",
      dog: "کتا", bird: "پرندہ", "traffic light": "ٹریفک لائٹ", "stop sign": "اسٹاپ کا نشان",
      suitcase: "سوٹ کیس", stroller: "بچے کی گاڑی",
    },
  },
};

export function normalizeLanguage(value: string | null | undefined): LanguageCode {
  return SUPPORTED_LANGUAGES.some((item) => item.code === value)
    ? (value as LanguageCode)
    : "en";
}

export function languageInfo(language: LanguageCode) {
  return SUPPORTED_LANGUAGES.find((item) => item.code === language) ?? SUPPORTED_LANGUAGES[0];
}

export function translate(
  language: LanguageCode,
  key: TextKey,
  values: Record<string, string | number> = {},
): string {
  const template = entries[language]?.text[key] ?? entries.en.text[key];
  return template.replace(/\{(\w+)\}/g, (_, name: string) => String(values[name] ?? ""));
}

const modifierAction: Record<string, ActionKey> = {
  left: "turnLeft", right: "turnRight", "sharp left": "sharpLeft",
  "sharp right": "sharpRight", "slight left": "slightLeft", "slight right": "slightRight",
  uturn: "uTurn",
};

export interface NavigationInstruction {
  instruction: string;
  maneuver?: string;
  modifier?: string;
  streetName?: string;
}

export function localizedAction(step: NavigationInstruction, language: LanguageCode): string {
  const entry = entries[language] ?? entries.en;
  const type = step.maneuver ?? "";
  const modifier = (step.modifier ?? "").toLowerCase();
  let key: ActionKey;
  if (type === "depart") {
    if (modifier && entry.directions[modifier]) {
      const heading = entry.actions.startHeading.replace("{direction}", entry.directions[modifier]);
      key = "startHeading";
      const street = step.streetName ? entry.streetSuffix.replace("{street}", step.streetName) : "";
      return heading + street;
    }
    key = "start";
  } else if (type === "arrive") key = "arrive";
  else if (type === "turn") key = modifierAction[modifier] ?? "continue";
  else if (type === "continue") key = "continueStraight";
  else if (type === "roundabout") key = "roundabout";
  else if (type === "exit roundabout") key = "exitRoundabout";
  else if (type === "fork") key = modifier === "left" ? "keepLeft" : modifier === "right" ? "keepRight" : "keep";
  else if (type === "merge") key = "merge";
  else if (type === "end of road") key = modifier.includes("left") ? "endLeft" : "endRight";
  else key = "continue";

  const action = entry.actions[key] ?? entries.en.actions[key];
  const street = step.streetName ? entry.streetSuffix.replace("{street}", step.streetName) : "";
  return action + street;
}

export function localizedCompassDirection(degrees: number, language: LanguageCode): string {
  const keys = ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"];
  const key = keys[Math.round(degrees / 45) % keys.length];
  if (language === "en") return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"][Math.round(degrees / 45) % 8];
  return entries[language].directions[key] ?? entries.en.directions[key];
}

export function localizedZoneName(zone: "left" | "centre" | "right", language: LanguageCode): string {
  return entries[language].zones[zone] ?? entries.en.zones[zone];
}

export function localizedObjectName(label: string, language: LanguageCode): string {
  const entry = entries[language];
  return entry.objects[label.toLowerCase()] ?? entry.text.obstacle;
}

export function localizedInstruction(
  step: NavigationInstruction,
  language: LanguageCode,
  count: number,
  upcoming = false,
): string {
  const entry = entries[language] ?? entries.en;
  const number = formatLocalizedNumber(count, language);
  const action = localizedAction(step, language);
  return (upcoming ? entry.text.guidanceInSteps : entry.text.guidanceForSteps)
    .replace("{count}", number)
    .replace("{action}", action);
}

const stepUnits: Record<LanguageCode, string> = {
  en: "steps", hi: "कदम", pa: "ਕਦਮ", bn: "কদম", te: "అడుగులు", ta: "அடிகள்",
  mr: "पावले", gu: "પગલાં", kn: "ಹೆಜ್ಜೆಗಳು", ml: "ചുവടുകൾ", or: "ପାଦକ୍ଷେପ",
  as: "খোজ", ur: "قدم",
};

function formatLocalizedNumber(count: number, language: LanguageCode): string {
  // Some JavaScript runtimes default these locales to Western digits. Explicitly
  // select the native numbering system used by the language for spoken guidance.
  const numberingSystem: Partial<Record<LanguageCode, string>> = {
    hi: "deva", mr: "deva", ta: "tamldec", te: "telu", kn: "knda", ml: "mlym",
    bn: "beng", pa: "guru", gu: "gujr", or: "orya", as: "beng", ur: "arab",
  };
  return new Intl.NumberFormat(languageInfo(language).locale, {
    maximumFractionDigits: 0,
    ...(numberingSystem[language] ? { numberingSystem: numberingSystem[language] } : {}),
  }).format(Math.max(0, Number.isFinite(count) ? count : 0));
}

export function localizedStepCount(count: number, language: LanguageCode): string {
  return `${formatLocalizedNumber(count, language)} ${stepUnits[language]}`;
}

export function localizedObstacle(
  label: string,
  zone: "left" | "centre" | "right",
  language: LanguageCode,
): string {
  const entry = entries[language] ?? entries.en;
  const object = entry.objects[label.toLowerCase()] ?? entry.text.obstacle;
  return entry.text.objectDetected
    .replace("{object}", object)
    .replace("{zone}", entry.zones[zone]);
}

export function gpsErrorMessage(code: number, language: LanguageCode): string {
  if (code === 1) return translate(language, "gpsDenied");
  if (code === 2) return translate(language, "gpsUnavailable");
  if (code === 3) return translate(language, "gpsTimeout");
  return translate(language, "gpsLost");
}
