import test from "node:test";
import assert from "node:assert/strict";
import { decodePolyline, fetchRoute, getDistanceMeter, getRouteProgress } from "./navigation.ts";

test("decodes standard encoded pedestrian route geometry", () => {
  const points = decodePolyline("_p~iF~ps|U_ulLnnqC_mqNvxq`@");
  assert.equal(points.length, 3);
  assert.ok(Math.abs(points[0][0] - 38.5) < 0.00001);
  assert.ok(Math.abs(points[0][1] + 120.2) < 0.00001);
  assert.ok(Math.abs(points[2][0] - 43.252) < 0.00001);
});

test("returns route progress and cross-track distance", () => {
  const geometry = [[0, 0], [0, 0.001]];
  const onRoute = getRouteProgress(0, 0.0005, geometry);
  const offRoute = getRouteProgress(0.001, 0.0005, geometry);
  assert.ok(onRoute);
  assert.ok(offRoute);
  assert.ok(Math.abs(onRoute.distanceAlongM - 55.6) < 2);
  assert.ok(onRoute.distanceFromRouteM < 1);
  assert.ok(offRoute.distanceFromRouteM > 100);
  assert.ok(Math.abs(getDistanceMeter(0, 0, 0, 0.001) - 111.2) < 2);
});

test("requests the dedicated foot router and accepts walking-only steps", async (context) => {
  const originalFetch = globalThis.fetch;
  let requestedUrl;
  globalThis.fetch = async (input) => {
    requestedUrl = new URL(String(input));
    return new Response(JSON.stringify({
      code: "Ok",
      routes: [{
        distance: 100,
        duration: 120,
        geometry: "_p~iF~ps|U_ulLnnqC_mqNvxq`@",
        legs: [{ steps: [{ distance: 100, mode: "walking", maneuver: { type: "continue" } }] }],
      }],
    }), { status: 200, headers: { "Content-Type": "application/json" } });
  };
  context.after(() => { globalThis.fetch = originalFetch; });

  const route = await fetchRoute(28.6, 77.2, 28.61, 77.21);
  assert.equal(requestedUrl.hostname, "routing.openstreetmap.de");
  assert.match(requestedUrl.pathname, /routed-foot/);
  assert.equal(route?.travelMode, "walking");
  assert.equal(route?.steps[0].startDistanceM, 0);
  assert.equal(route?.steps[0].endDistanceM, 100);
});

test("fails closed when a response contains driving steps", async (context) => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(JSON.stringify({
    code: "Ok",
    routes: [{
      distance: 100,
      duration: 120,
      geometry: "_p~iF~ps|U_ulLnnqC_mqNvxq`@",
      legs: [{ steps: [{ distance: 100, mode: "driving", maneuver: { type: "continue" } }] }],
    }],
  }), { status: 200, headers: { "Content-Type": "application/json" } });
  context.after(() => { globalThis.fetch = originalFetch; });

  assert.equal(await fetchRoute(28.6, 77.2, 28.61, 77.21), null);
});

test("returns no route on network failure or invalid coordinates", async (context) => {
  const originalFetch = globalThis.fetch;
  let requests = 0;
  globalThis.fetch = async () => {
    requests += 1;
    throw new Error("network unavailable");
  };
  context.after(() => { globalThis.fetch = originalFetch; });

  assert.equal(await fetchRoute(28.6, 77.2, 28.61, 77.21), null);
  assert.equal(await fetchRoute(91, 77.2, 28.61, 77.21), null);
  assert.equal(requests, 1);
});
