export interface RouteStep {
  instruction: string;
  distanceM: number;
  startDistanceM: number;
  endDistanceM: number;
  maneuver?: string;
  modifier?: string;
  streetName?: string;
}

export interface RouteData {
  steps: RouteStep[];
  totalDistanceM: number;
  totalDurationS: number;
  polyline: [number, number][];
  travelMode: "walking";
  provider: "OpenStreetMap foot routing";
}

interface OSMRouteStep {
  distance: number;
  name?: string;
  mode?: string;
  maneuver?: { type?: string; modifier?: string };
}

interface OSMRouteResponse {
  code?: string;
  routes?: Array<{
    distance: number;
    duration: number;
    geometry?: string;
    legs: Array<{ steps: OSMRouteStep[] }>;
  }>;
}

function readPolylineValue(encoded: string, state: { index: number }): number {
  let result = 0;
  let shift = 0;
  while (state.index < encoded.length && shift <= 30) {
    const byte = encoded.charCodeAt(state.index++) - 63;
    if (byte < 0 || byte > 63) throw new Error("Invalid route geometry");
    result |= (byte & 0x1f) << shift;
    shift += 5;
    if (byte < 0x20) return result & 1 ? ~(result >> 1) : result >> 1;
  }
  throw new Error("Incomplete route geometry");
}

export function decodePolyline(encoded: string): [number, number][] {
  const points: [number, number][] = [];
  const state = { index: 0 };
  let lat = 0;
  let lng = 0;
  while (state.index < encoded.length && points.length < 20_000) {
    lat += readPolylineValue(encoded, state);
    lng += readPolylineValue(encoded, state);
    const point: [number, number] = [lat / 1e5, lng / 1e5];
    if (!Number.isFinite(point[0]) || Math.abs(point[0]) > 90
      || !Number.isFinite(point[1]) || Math.abs(point[1]) > 180) {
      throw new Error("Invalid route coordinates");
    }
    points.push(point);
  }
  if (state.index < encoded.length || points.length < 2) throw new Error("Invalid route geometry");
  return points;
}

function isCoordinateValid(lat: number, lng: number): boolean {
  return Number.isFinite(lat) && lat >= -90 && lat <= 90
    && Number.isFinite(lng) && lng >= -180 && lng <= 180;
}

export async function fetchRoute(
  fromLat: number,
  fromLng: number,
  toLat: number,
  toLng: number,
): Promise<RouteData | null> {
  if (!isCoordinateValid(fromLat, fromLng) || !isCoordinateValid(toLat, toLng)) return null;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12_000);
  try {
    // The host's routed-foot graph is the routing profile. The `driving` path token is
    // part of this server's OSRM-compatible API syntax, not a request to use car data.
    const url = new URL(
      `https://routing.openstreetmap.de/routed-foot/route/v1/driving/${fromLng},${fromLat};${toLng},${toLat}`,
    );
    url.searchParams.set("steps", "true");
    url.searchParams.set("annotations", "false");
    url.searchParams.set("geometries", "polyline");
    url.searchParams.set("overview", "full");
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) return null;
    const data = await response.json() as OSMRouteResponse;
    const route = data.code === "Ok" ? data.routes?.[0] : undefined;
    if (!route || !Array.isArray(route.legs) || !Number.isFinite(route.distance)
      || !Number.isFinite(route.duration) || route.distance <= 0 || !route.geometry) return null;

    const rawSteps = route.legs.flatMap((leg) => leg.steps ?? []);
    // Fail closed if the configured pedestrian service does not identify every step as walking.
    if (rawSteps.length === 0 || rawSteps.some((step) => step.mode !== "walking")) return null;

    let cumulativeDistance = 0;
    const steps: RouteStep[] = rawSteps.map((step) => {
      const distance = Number(step.distance);
      if (!Number.isFinite(distance) || distance < 0) throw new Error("Invalid route step");
      const startDistanceM = cumulativeDistance;
      cumulativeDistance += distance;
      return {
        instruction: buildInstruction(step.maneuver, step.name ?? ""),
        distanceM: distance,
        startDistanceM,
        endDistanceM: cumulativeDistance,
        maneuver: step.maneuver?.type,
        modifier: step.maneuver?.modifier,
        streetName: (step.name ?? "").slice(0, 120),
      };
    });
    const polyline = decodePolyline(route.geometry);
    if (steps.length === 0 || cumulativeDistance <= 0) return null;
    return {
      steps,
      totalDistanceM: route.distance,
      totalDurationS: route.duration,
      polyline,
      travelMode: "walking",
      provider: "OpenStreetMap foot routing",
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

function buildInstruction(
  maneuver: { type?: string; modifier?: string } | undefined,
  name: string,
): string {
  if (!maneuver) return `Continue on ${name || "the path"}`;
  const type = maneuver.type || "";
  const modifier = maneuver.modifier || "";
  const street = name ? ` onto ${name}` : "";
  switch (type) {
    case "depart": return `Start heading ${modifier}${street}`;
    case "arrive": return "Arrive at your destination";
    case "turn":
      if (modifier === "left") return `Turn left${street}`;
      if (modifier === "right") return `Turn right${street}`;
      if (modifier === "sharp left") return `Turn sharp left${street}`;
      if (modifier === "sharp right") return `Turn sharp right${street}`;
      if (modifier === "slight left") return `Bear left${street}`;
      if (modifier === "slight right") return `Bear right${street}`;
      return `Turn${street}`;
    case "continue": return `Continue straight${street}`;
    case "roundabout": return `Enter the roundabout${street}`;
    case "exit roundabout": return `Exit the roundabout${street}`;
    case "fork":
      if (modifier === "left") return `Keep left${street}`;
      if (modifier === "right") return `Keep right${street}`;
      return `Keep to the path${street}`;
    case "merge": return `Merge${street}`;
    case "end of road": return `At the end of the path, turn ${modifier}${street}`;
    default: return `Continue${street}`;
  }
}

let lastGeocodeAt = 0;

export async function geocodeAddress(
  query: string,
): Promise<{ lat: number; lng: number; displayName: string } | null> {
  const trimmed = query.trim().slice(0, 200);
  if (!trimmed) return null;
  const waitMs = Math.max(0, 1_000 - (Date.now() - lastGeocodeAt));
  if (waitMs) await new Promise((resolve) => setTimeout(resolve, waitMs));
  lastGeocodeAt = Date.now();

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10_000);
  try {
    const url = new URL("https://nominatim.openstreetmap.org/search");
    url.searchParams.set("q", trimmed);
    url.searchParams.set("format", "jsonv2");
    url.searchParams.set("limit", "1");
    const response = await fetch(url, {
      headers: { Accept: "application/json" },
      signal: controller.signal,
    });
    if (!response.ok) return null;
    const data = await response.json() as Array<{ lat?: string; lon?: string; display_name?: string }>;
    const lat = Number(data[0]?.lat);
    const lng = Number(data[0]?.lon);
    if (!isCoordinateValid(lat, lng)) return null;
    return { lat, lng, displayName: String(data[0]?.display_name ?? "").slice(0, 300) };
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

export function getRouteProgress(
  lat: number,
  lng: number,
  polyline: [number, number][],
): { distanceAlongM: number; distanceFromRouteM: number } | null {
  if (!isCoordinateValid(lat, lng) || polyline.length < 2) return null;
  const metresPerDegreeLat = 111_132;
  let cumulativeM = 0;
  let bestDistanceM = Number.POSITIVE_INFINITY;
  let bestAlongM = 0;

  for (let index = 0; index < polyline.length - 1; index += 1) {
    const [startLat, startLng] = polyline[index];
    const [endLat, endLng] = polyline[index + 1];
    const meanLat = ((startLat + endLat + lat) / 3) * Math.PI / 180;
    const metresPerDegreeLng = Math.max(1, 111_320 * Math.cos(meanLat));
    const startX = startLng * metresPerDegreeLng;
    const startY = startLat * metresPerDegreeLat;
    const endX = endLng * metresPerDegreeLng;
    const endY = endLat * metresPerDegreeLat;
    const pointX = lng * metresPerDegreeLng;
    const pointY = lat * metresPerDegreeLat;
    const dx = endX - startX;
    const dy = endY - startY;
    const segmentLengthSquared = dx * dx + dy * dy;
    const fraction = segmentLengthSquared > 0
      ? Math.max(0, Math.min(1, ((pointX - startX) * dx + (pointY - startY) * dy) / segmentLengthSquared))
      : 0;
    const nearestX = startX + fraction * dx;
    const nearestY = startY + fraction * dy;
    const distance = Math.hypot(pointX - nearestX, pointY - nearestY);
    const segmentLength = getDistanceMeter(startLat, startLng, endLat, endLng);
    if (distance < bestDistanceM) {
      bestDistanceM = distance;
      bestAlongM = cumulativeM + segmentLength * fraction;
    }
    cumulativeM += segmentLength;
  }
  return Number.isFinite(bestDistanceM)
    ? { distanceAlongM: bestAlongM, distanceFromRouteM: bestDistanceM }
    : null;
}

export function getDistanceMeter(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const radiusM = 6_371_000;
  const deltaLat = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLng = ((lng2 - lng1) * Math.PI) / 180;
  const a = Math.sin(deltaLat / 2) ** 2
    + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(deltaLng / 2) ** 2;
  return radiusM * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
