import test from "node:test";
import assert from "node:assert/strict";
import {
  SUPPORTED_LANGUAGES,
  languageInfo,
  localizedInstruction,
  localizedObstacle,
  translate,
} from "./translations.ts";

test("exposes all 13 supported languages using native-script names and Indian locales", () => {
  assert.equal(SUPPORTED_LANGUAGES.length, 13);
  assert.deepEqual(SUPPORTED_LANGUAGES.map(({ code }) => code), [
    "en", "hi", "pa", "bn", "te", "ta", "mr", "gu", "kn", "ml", "or", "as", "ur",
  ]);
  assert.equal(languageInfo("hi").locale, "hi-IN");
  assert.equal(languageInfo("pa").locale, "pa-IN");
  assert.equal(languageInfo("te").locale, "te-IN");
  assert.equal(languageInfo("ta").locale, "ta-IN");
  assert.equal(languageInfo("mr").locale, "mr-IN");
  assert.equal(languageInfo("ur").name, "اردو");
});

test("formats representative spoken step instructions naturally", () => {
  const continueStraight = { instruction: "", maneuver: "continue" };
  assert.equal(localizedInstruction(continueStraight, "en", 20), "Continue straight for 20 steps.");
  assert.equal(localizedInstruction(continueStraight, "hi", 20), "२० कदम सीधे चलते रहें।");
  assert.equal(localizedInstruction(continueStraight, "ta", 20), "௨௦ அடிகள் நேராகத் தொடர்ந்து செல்லவும்.");
  assert.equal(localizedInstruction(continueStraight, "te", 20), "౨౦ అడుగులు నేరుగా కొనసాగండి.");
  assert.equal(localizedInstruction(continueStraight, "mr", 20), "२० पावले सरळ पुढे चालत राहा.");
});

test("all language dictionaries provide GPS, arrival, voice, reroute, SOS and object-detection text", () => {
  const textKeys = [
    "arrived", "gpsWait", "gpsDenied", "gpsUnavailable", "gpsLost", "gpsTimeout",
    "gpsInaccurate", "offline", "routeFailed", "rerouting", "rerouteFailed",
    "voiceUnavailable", "speechUnsupported", "speechError", "sosCountdown",
    "sosCancelled", "sosRecorded", "sosRecordFailed",
  ];
  for (const { code } of SUPPORTED_LANGUAGES) {
    for (const key of textKeys) {
      const text = translate(code, key, { count: 5, language: languageInfo(code).name });
      assert.ok(text.length > 0, `${code} missing ${key}`);
      assert.doesNotMatch(text, /\{\w+\}/, `${code} has an unresolved ${key} placeholder`);
    }
    const alert = localizedObstacle("person", "centre", code);
    assert.ok(alert.length > 0, `${code} has no object-detection alert`);
    assert.doesNotMatch(alert, /\{\w+\}/);
  }
});
