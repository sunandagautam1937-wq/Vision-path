export const UK_SHOE_SIZES: Record<number, number> = {
  1: 22.0, 2: 22.7, 3: 23.3, 4: 24.0, 5: 24.6, 6: 25.3, 7: 26.0,
  8: 26.7, 9: 27.3, 10: 28.0, 11: 28.7, 12: 29.3, 13: 30.0,
  14: 30.7, 15: 31.3
};

export function getFootLengthCm(ukSize: number): number {
  const sizes = Object.keys(UK_SHOE_SIZES).map(Number);
  const lower = sizes.filter(s => s <= ukSize).pop();
  const upper = sizes.filter(s => s >= ukSize).shift();
  if (lower === undefined || upper === undefined) return 26.0;
  if (lower === upper) return UK_SHOE_SIZES[lower];
  const t = (ukSize - lower) / (upper - lower);
  return UK_SHOE_SIZES[lower] + t * (UK_SHOE_SIZES[upper] - UK_SHOE_SIZES[lower]);
}

export function calculateStepLength(heightCm: number, footLengthCm: number): number {
  const strideFromHeight = heightCm * 0.413;
  const strideFromFoot = footLengthCm * 3.5;
  const average = (strideFromHeight + strideFromFoot) / 2;
  return average / 100;
}

export function metersToSteps(meters: number, stepLengthM: number): number {
  if (stepLengthM <= 0) return Math.round(meters / 0.75);
  return Math.round(meters / stepLengthM);
}

export function stepsToMeters(steps: number, stepLengthM: number): number {
  return steps * stepLengthM;
}

export function formatSteps(steps: number): string {
  if (steps < 1000) return `${steps} steps`;
  return `${(steps / 1000).toFixed(1)}k steps`;
}
