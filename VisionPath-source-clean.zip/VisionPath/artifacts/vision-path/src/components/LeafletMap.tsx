import { useEffect, useRef } from "react";

interface LatLng { lat: number; lng: number; }

interface Props {
  userLocation: LatLng | null;
  destination: LatLng | null;
  routePolyline?: [number, number][];
  height?: string;
}

declare global {
  interface Window {
    L: typeof import("leaflet");
  }
}

let leafletLoaded = false;
let leafletPromise: Promise<void> | null = null;

function ensureLeaflet(): Promise<void> {
  if (leafletLoaded) return Promise.resolve();
  if (leafletPromise) return leafletPromise;
  leafletPromise = new Promise<void>((resolve) => {
    if (!document.getElementById("leaflet-css")) {
      const link = document.createElement("link");
      link.id = "leaflet-css";
      link.rel = "stylesheet";
      link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
      document.head.appendChild(link);
    }
    const script = document.createElement("script");
    script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
    script.onload = () => { leafletLoaded = true; resolve(); };
    document.head.appendChild(script);
  });
  return leafletPromise;
}

export default function LeafletMap({ userLocation, destination, routePolyline, height = "200px" }: Props) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<import("leaflet").Map | null>(null);
  const userMarkerRef = useRef<import("leaflet").Marker | null>(null);
  const destMarkerRef = useRef<import("leaflet").Marker | null>(null);
  const polylineRef = useRef<import("leaflet").Polyline | null>(null);
  const initDone = useRef(false);

  useEffect(() => {
    ensureLeaflet().then(() => {
      if (!mapRef.current || initDone.current) return;
      initDone.current = true;
      const L = window.L;
      const center: [number, number] = userLocation ? [userLocation.lat, userLocation.lng] : [20.5937, 78.9629];
      const map = L.map(mapRef.current, { zoomControl: false, attributionControl: false }).setView(center, 17);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap",
      }).addTo(map);
      mapInstanceRef.current = map;

      if (userLocation) addOrUpdateUser(userLocation);
      if (destination) addOrUpdateDest(destination);
      if (routePolyline && routePolyline.length > 0) drawRoute(routePolyline);
    });
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        initDone.current = false;
        userMarkerRef.current = null;
        destMarkerRef.current = null;
        polylineRef.current = null;
      }
    };
  }, []);

  function addOrUpdateUser(loc: LatLng) {
    const map = mapInstanceRef.current;
    if (!map || !window.L) return;
    const L = window.L;
    const icon = L.divIcon({
      html: `<div style="width:14px;height:14px;background:#cbd9b4;border:3px solid #1a261e;border-radius:50%;box-shadow:0 0 10px rgba(203,217,180,0.6)"></div>`,
      className: "",
      iconSize: [20, 20],
      iconAnchor: [10, 10],
    });
    if (userMarkerRef.current) {
      userMarkerRef.current.setLatLng([loc.lat, loc.lng]);
    } else {
      userMarkerRef.current = L.marker([loc.lat, loc.lng], { icon }).addTo(map);
    }
    map.setView([loc.lat, loc.lng], map.getZoom(), { animate: true });
  }

  function addOrUpdateDest(loc: LatLng) {
    const map = mapInstanceRef.current;
    if (!map || !window.L) return;
    const L = window.L;
    const icon = L.divIcon({
      html: `<div style="width:12px;height:12px;background:#c98279;border:3px solid #fff;border-radius:50%;box-shadow:0 0 8px rgba(201,130,121,0.65)"></div>`,
      className: "",
      iconSize: [18, 18],
      iconAnchor: [9, 9],
    });
    if (destMarkerRef.current) {
      destMarkerRef.current.setLatLng([loc.lat, loc.lng]);
    } else {
      destMarkerRef.current = L.marker([loc.lat, loc.lng], { icon }).addTo(map);
    }
  }

  function drawRoute(pts: [number, number][]) {
    const map = mapInstanceRef.current;
    if (!map || !window.L) return;
    const L = window.L;
    if (polylineRef.current) polylineRef.current.remove();
    polylineRef.current = L.polyline(pts, { color: "#aebf91", weight: 4, opacity: 0.9 }).addTo(map);
    map.fitBounds(polylineRef.current.getBounds(), { padding: [30, 30] });
  }

  useEffect(() => {
    if (!mapInstanceRef.current || !window.L) return;
    if (userLocation) addOrUpdateUser(userLocation);
  }, [userLocation]);

  useEffect(() => {
    if (!mapInstanceRef.current || !window.L) return;
    if (destination) addOrUpdateDest(destination);
  }, [destination]);

  useEffect(() => {
    if (!mapInstanceRef.current || !window.L) return;
    if (routePolyline && routePolyline.length > 0) drawRoute(routePolyline);
  }, [routePolyline]);

  return (
    <div ref={mapRef} style={{ width: "100%", height, background: "var(--vp-surface)" }} />
  );
}
