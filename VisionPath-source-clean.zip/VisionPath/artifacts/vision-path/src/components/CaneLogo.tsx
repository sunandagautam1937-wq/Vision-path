interface CaneLogoProps {
  size?: number;
  /** Accessible name. Pass "" to mark the logo decorative (aria-hidden). */
  label?: string;
  color?: string;
}

/** Minimal white-cane (walking stick) mark: grip, shaft, banded tip, ground sweep arc. */
export default function CaneLogo({ size = 52, label = "VisionPath logo: white cane", color = "var(--vp-accent-ink)" }: CaneLogoProps) {
  const decorative = label === "";
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeLinecap="round"
      role={decorative ? undefined : "img"}
      aria-label={decorative ? undefined : label}
      aria-hidden={decorative ? true : undefined}
      focusable="false"
    >
      <line x1="17" y1="3.5" x2="8" y2="20.5" strokeWidth="1.7" />
      <line x1="17" y1="3.5" x2="14.7" y2="7.9" strokeWidth="3.4" />
      <line x1="9.4" y1="17.9" x2="8" y2="20.5" strokeWidth="3" />
      <path d="M3.5 21.8Q8.5 23.6 13.5 21.8" strokeWidth="1.4" opacity="0.75" />
    </svg>
  );
}
