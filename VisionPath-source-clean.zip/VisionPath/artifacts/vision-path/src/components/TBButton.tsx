import { ReactNode, CSSProperties } from "react";
import { useTalkBack } from "@/contexts/TalkBackContext";

interface TBButtonProps {
  label: string;
  onClick: () => void;
  children: ReactNode;
  className?: string;
  style?: CSSProperties;
  disabled?: boolean;
}

export default function TBButton({ label, onClick, children, className, style, disabled }: TBButtonProps) {
  const { registerTap } = useTalkBack();
  const handler = registerTap(label, onClick);
  return (
    <button
      type="button"
      className={className}
      style={style}
      disabled={disabled}
      onClick={!disabled ? handler : undefined}
      aria-label={label}
    >
      {children}
    </button>
  );
}
