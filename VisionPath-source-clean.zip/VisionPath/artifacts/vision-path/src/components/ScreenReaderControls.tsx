import { useEffect, useState } from "react";
import { useAuth } from "@clerk/react";
import { useLocation } from "wouter";
import { useUser } from "@/contexts/UserContext";
import { speak, stopSpeaking } from "@/utils/speech";

function visibleScreenText(): string {
  const main = document.querySelector<HTMLElement>("main") ?? document.querySelector<HTMLElement>("#root");
  if (!main) return "";

  const readableCopy = main.cloneNode(true) as HTMLElement;
  readableCopy
    .querySelectorAll('[aria-hidden="true"], [data-screen-reader-ignore], script, style')
    .forEach((element) => element.remove());

  return (readableCopy.innerText || readableCopy.textContent || "")
    .replace(/\s+/g, " ")
    .trim();
}

export default function ScreenReaderControls() {
  const { language } = useUser();
  const { isSignedIn } = useAuth();
  const [location] = useLocation();
  const [status, setStatus] = useState("");

  useEffect(() => {
    stopSpeaking();
    setStatus("");
  }, [location]);

  useEffect(() => () => stopSpeaking(), []);

  function readScreen() {
    const text = visibleScreenText();
    if (!text) {
      setStatus("There is no screen text to read yet.");
      return;
    }
    if (!("speechSynthesis" in window)) {
      setStatus("In-app speech is unavailable in this browser. Android TalkBack remains available in device accessibility settings.");
      return;
    }

    speak(text, {
      priority: "routine",
      language,
      fallbackToSystemVoice: true,
    });
    setStatus("Reading this screen aloud. Select Stop reading to stop.");
  }

  function stopReading() {
    stopSpeaking();
    setStatus("Screen narration stopped.");
  }

  return (
    <aside
      className={`vp-screen-reader-tools${location === "/navigate" ? " vp-screen-reader-tools--nav" : ""}${!isSignedIn ? " vp-screen-reader-tools--guest" : ""}`}
      aria-label="In-app spoken reading controls"
      data-screen-reader-ignore
    >
      <button
        type="button"
        className="vp-screen-reader-button"
        onClick={readScreen}
        aria-describedby="vp-screen-reader-help"
      >
        <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M4 10v4h4l5 4V6l-5 4H4Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
          <path d="M16 9a5 5 0 0 1 0 6m3-9a9 9 0 0 1 0 12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
        <span>Read screen</span>
      </button>
      <button
        type="button"
        className="vp-screen-reader-button vp-screen-reader-stop"
        onClick={stopReading}
        aria-label="Stop in-app screen narration"
      >
        Stop
      </button>
      <span id="vp-screen-reader-help" className="sr-only">
        Reads visible screen text using the app voice. Android TalkBack remains controlled by your device.
      </span>
      <span className="sr-only" role="status" aria-live="polite" aria-atomic="true">
        {status}
      </span>
    </aside>
  );
}
