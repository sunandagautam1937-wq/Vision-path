import { useEffect, useRef, useState, type MouseEvent } from "react";
import { useLocation } from "wouter";
import { ANNOUNCE_EVENT, type AnnouncePoliteness } from "@/utils/announce";

const TITLES: Record<string, string> = {
  "/": "Home",
  "/navigate": "Navigation",
  "/sos": "SOS Emergency",
  "/family": "Family Tracker",
  "/family-view": "Family Tracker",
  "/profile": "Profile",
};

function titleFor(path: string): string {
  const key = Object.keys(TITLES).find((p) => (p === "/" ? path === "/" : path.startsWith(p)));
  return key ? TITLES[key] : "VisionPath";
}

/**
 * Provides: a skip link, two hidden live regions, and SPA route-change handling
 * (document title + focus moved to the page heading so screen readers read the new screen).
 */
export default function RouteAnnouncer() {
  const [location] = useLocation();
  const [polite, setPolite] = useState("");
  const [assertive, setAssertive] = useState("");
  const prevLocation = useRef<string | null>(null);

  useEffect(() => {
    const handler = (event: Event) => {
      const { message, politeness } = (event as CustomEvent<{ message: string; politeness: AnnouncePoliteness }>).detail;
      const set = politeness === "assertive" ? setAssertive : setPolite;
      set(""); // clear first so repeated identical messages are re-announced
      window.setTimeout(() => set(message), 60);
    };
    window.addEventListener(ANNOUNCE_EVENT, handler);
    return () => window.removeEventListener(ANNOUNCE_EVENT, handler);
  }, []);

  useEffect(() => {
    const title = titleFor(location);
    document.title = `${title} – VisionPath`;
    const previous = prevLocation.current;
    prevLocation.current = location;
    if (previous === null || previous === location) return; // skip first load (also StrictMode re-run)
    const timer = window.setTimeout(() => {
      const heading = document.querySelector<HTMLElement>("main h1");
      const target = heading ?? document.querySelector<HTMLElement>("main");
      if (target) {
        if (!target.hasAttribute("tabindex")) target.setAttribute("tabindex", "-1");
        target.focus({ preventScroll: true });
      }
      // Focusing a heading already makes TalkBack read it; only announce when there is no heading.
      if (!heading) {
        setPolite("");
        window.setTimeout(() => setPolite(`${title} screen`), 60);
      }
    }, 150);
    return () => window.clearTimeout(timer);
  }, [location]);

  function skip(event: MouseEvent) {
    event.preventDefault();
    const main = document.querySelector<HTMLElement>("main");
    if (!main) return;
    main.setAttribute("tabindex", "-1");
    main.focus();
  }

  return (
    <div data-screen-reader-ignore>
      <a
        href="#main"
        onClick={skip}
        className="sr-only focus:not-sr-only focus:fixed focus:left-2 focus:top-2 focus:z-[10000] focus:rounded-xl focus:px-4 focus:py-3 focus:font-semibold"
        style={{ background: "var(--vp-accent)", color: "var(--vp-accent-ink)" }}
      >
        Skip to main content
      </a>
      <div className="sr-only" role="status" aria-live="polite" aria-atomic="true">{polite}</div>
      <div className="sr-only" role="alert" aria-live="assertive" aria-atomic="true">{assertive}</div>
    </div>
  );
}
