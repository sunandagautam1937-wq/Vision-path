import { useEffect, useRef, useState } from "react";
import { speak } from "@/utils/speech";
import { localizedObjectName, localizedObstacle, localizedZoneName, type LanguageCode } from "@/utils/translations";

interface Detection {
  label: string;
  score: number;
  zone: "left" | "centre" | "right";
  bbox: [number, number, number, number];
}

interface Props {
  active: boolean;
  language: LanguageCode;
  onDetection?: (detections: Detection[]) => void;
}

interface DetectorModel {
  detect: (image: HTMLCanvasElement) => Promise<Array<{
    class: string;
    score: number;
    bbox: [number, number, number, number];
  }>>;
}

type DetectorStatus = "loading" | "ready" | "error" | "idle";
type DetectorError = "camera" | "unsupported" | "model" | "inference";

let modelCache: DetectorModel | null = null;
let modelLoad: Promise<DetectorModel> | null = null;

async function loadModel(): Promise<DetectorModel> {
  if (modelCache) return modelCache;
  if (!modelLoad) {
    modelLoad = (async () => {
      const tf = await import("@tensorflow/tfjs");
      await tf.ready();
      const cocoSsd = await import("@tensorflow-models/coco-ssd");
      return await cocoSsd.load({ base: "lite_mobilenet_v2" }) as DetectorModel;
    })();
  }
  try {
    modelCache = await modelLoad;
    return modelCache;
  } catch (error) {
    modelLoad = null;
    throw error;
  }
}

function errorText(error: DetectorError): string {
  if (error === "camera") return "Camera permission was denied or the camera is in use. Check browser permissions and retry.";
  if (error === "unsupported") return "Camera access requires a supported browser and a secure connection.";
  if (error === "model") return "The object-detection model could not load. Check your connection and retry.";
  return "Camera object detection stopped after an inference error. Retry to start again.";
}

export default function ObstacleDetector({ active, language, onDetection }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const lastSpokenRef = useRef<Record<string, number>>({});
  const modelRef = useRef<DetectorModel | null>(null);
  const activeRef = useRef(active);
  const inferenceRunningRef = useRef(false);
  const lastInferenceAtRef = useRef(0);
  const onDetectionRef = useRef(onDetection);
  const runDetectionRef = useRef<(() => Promise<void>) | null>(null);
  const languageRef = useRef(language);
  const [status, setStatus] = useState<DetectorStatus>("idle");
  const [detectorError, setDetectorError] = useState<DetectorError | null>(null);
  const [currentDetections, setCurrentDetections] = useState<Detection[]>([]);
  const [retryCount, setRetryCount] = useState(0);
  activeRef.current = active;
  onDetectionRef.current = onDetection;
  languageRef.current = language;

  function stopCamera() {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    inferenceRunningRef.current = false;
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.srcObject = null;
    }
  }

  function zoneFor(cx: number, imageWidth: number): Detection["zone"] {
    if (cx < imageWidth / 3) return "left";
    if (cx < imageWidth * 2 / 3) return "centre";
    return "right";
  }

  function announceDetection(label: string, zone: Detection["zone"]) {
    const key = `${label.toLowerCase()}-${zone}`;
    const now = Date.now();
    if (now - (lastSpokenRef.current[key] ?? 0) < 12_000) return;
    lastSpokenRef.current[key] = now;
    speak(localizedObstacle(label, zone, languageRef.current), { priority: "critical", language: languageRef.current });
    if (navigator.vibrate) navigator.vibrate([120, 60, 120]);
  }

  async function runDetection() {
    if (!activeRef.current || inferenceRunningRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const model = modelRef.current;
    if (!video || !canvas || !model) return;

    if (video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) {
      rafRef.current = requestAnimationFrame(() => void runDetectionRef.current?.());
      return;
    }
    const elapsed = performance.now() - lastInferenceAtRef.current;
    if (elapsed < 200) {
      rafRef.current = requestAnimationFrame(() => void runDetectionRef.current?.());
      return;
    }
    lastInferenceAtRef.current = performance.now();
    inferenceRunningRef.current = true;
    try {
      const width = video.videoWidth || 320;
      const height = video.videoHeight || 240;
      canvas.width = width;
      canvas.height = height;
      const context = canvas.getContext("2d");
      if (!context) throw new Error("Canvas is unavailable");
      context.drawImage(video, 0, 0, width, height);
      const predictions = await model.detect(canvas);
      if (!activeRef.current) return;
      const detections: Detection[] = predictions
        .filter((prediction) => Number.isFinite(prediction.score)
          && prediction.score >= 0.45
          && prediction.bbox.every(Number.isFinite))
        .sort((a, b) => b.score - a.score)
        .slice(0, 5)
        .map((prediction) => ({
          label: prediction.class,
          score: prediction.score,
          zone: zoneFor(prediction.bbox[0] + prediction.bbox[2] / 2, width),
          bbox: prediction.bbox,
        }));

      setCurrentDetections(detections);
      onDetectionRef.current?.(detections);
      // Avoid talking over the user with a burst of repeated classes in the same frame.
      const bestInZone = new Map<Detection["zone"], Detection>();
      for (const detection of detections) {
        if (!bestInZone.has(detection.zone)) bestInZone.set(detection.zone, detection);
      }
      for (const detection of bestInZone.values()) announceDetection(detection.label, detection.zone);
    } catch {
      stopCamera();
      setDetectorError("inference");
      setStatus("error");
      return;
    } finally {
      inferenceRunningRef.current = false;
    }
    if (activeRef.current) rafRef.current = requestAnimationFrame(() => void runDetectionRef.current?.());
  }

  runDetectionRef.current = runDetection;

  useEffect(() => {
    if (!active) {
      stopCamera();
      modelRef.current = null;
      setStatus("idle");
      setDetectorError(null);
      setCurrentDetections([]);
      return;
    }

    setStatus("loading");
    setDetectorError(null);
    let cancelled = false;
    let pendingStream: MediaStream | null = null;
    let stage: DetectorError = "camera";
    void (async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia || !window.isSecureContext) {
          throw new Error("unsupported");
        }
        // Prefer the rear camera for mobility assistance. Some laptops and older
        // browsers cannot satisfy facingMode/size constraints, so retry with a
        // generic video device only for constraint/device-selection failures.
        try {
          pendingStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: "environment" }, width: { ideal: 320 }, height: { ideal: 240 } },
            audio: false,
          });
        } catch (cameraError) {
          const name = cameraError instanceof DOMException ? cameraError.name : "";
          if (!["OverconstrainedError", "ConstraintNotSatisfiedError", "NotFoundError"].includes(name)) {
            throw cameraError;
          }
          pendingStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        }
        if (cancelled) {
          pendingStream.getTracks().forEach((track) => track.stop());
          return;
        }
        streamRef.current = pendingStream;
        if (!videoRef.current) throw new Error("camera");
        videoRef.current.srcObject = pendingStream;
        await videoRef.current.play();
        if (cancelled) return;

        stage = "model";
        const model = await loadModel();
        if (cancelled) return;
        modelRef.current = model;
        setStatus("ready");
        rafRef.current = requestAnimationFrame(() => void runDetectionRef.current?.());
      } catch (error) {
        if (cancelled) return;
        const message = error instanceof Error ? error.message : "";
        setDetectorError(message === "unsupported" ? "unsupported" : stage);
        setStatus("error");
        stopCamera();
      }
    })();

    return () => {
      cancelled = true;
      pendingStream?.getTracks().forEach((track) => track.stop());
      stopCamera();
    };
    // Retry is intentionally the only way to re-run camera and model setup while active.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, retryCount]);

  const zoneLabels = ["left", "centre", "right"] as const;

  return (
    <div className="relative w-full" style={{ height: "220px", background: "#000", overflow: "hidden" }}>
      <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover" playsInline muted aria-label="Live camera preview for common-object recognition" />
      <canvas ref={canvasRef} className="hidden" aria-hidden="true" />

      <div className="absolute inset-0 flex pointer-events-none" aria-hidden="true">
        {zoneLabels.map((zone, index) => {
          const detections = currentDetections.filter((detection) => detection.zone === zone);
          const detected = detections.length > 0;
          return (
            <div
              key={zone}
              className="flex-1 flex flex-col justify-between"
              style={{
                borderLeft: index > 0 ? "1px solid rgba(240,192,64,0.3)" : "none",
                background: detected ? "rgba(240,60,60,0.18)" : "transparent",
                transition: "background 0.25s",
              }}
            >
              <div className="text-center pt-1">
                <span className="text-xs font-bold px-1.5 py-0.5 rounded"
                  style={{ background: detected ? "rgba(220,40,40,0.85)" : "rgba(0,0,0,0.5)", color: detected ? "#fff" : "rgba(240,192,64,0.6)" }}>
                  {localizedZoneName(zone, language)}
                </span>
              </div>
              <div className="pb-1 px-1">
                {detections.slice(0, 2).map((detection, index) => (
                  <div key={`${detection.label}-${index}`} className="text-center mb-0.5">
                    <span className="text-xs font-semibold px-1.5 py-0.5 rounded capitalize"
                      style={{ background: "rgba(220,40,40,0.85)", color: "white" }}>
                      {localizedObjectName(detection.label, language)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {status === "loading" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center" style={{ background: "rgba(0,0,0,0.75)" }} role="status" aria-live="polite">
          <div className="w-8 h-8 border-2 border-yellow-400 border-t-transparent rounded-full animate-spin mb-2" aria-hidden="true" />
          <p className="text-xs" style={{ color: "var(--vp-accent-bright)" }}>Starting camera and loading the object detector…</p>
          <p className="mt-1 px-3 text-center text-[10px]" style={{ color: "var(--vp-text-soft)" }}>The model may need an internet connection the first time.</p>
        </div>
      )}
      {status === "error" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 px-4 text-center" style={{ background: "rgba(0,0,0,0.9)" }} role="alert">
          <p className="text-xs text-red-300">{detectorError ? errorText(detectorError) : "Object detection is unavailable."}</p>
          <button
            type="button"
            onClick={() => setRetryCount((count) => count + 1)}
            className="min-h-12 rounded-xl px-4 py-2 text-sm font-semibold focus-visible:ring-2 focus-visible:ring-yellow-300"
            style={{ background: "var(--vp-accent)", color: "var(--vp-accent-ink)" }}
          >
            Retry camera detection
          </button>
        </div>
      )}
      {status === "idle" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center" style={{ background: "rgba(0,0,0,0.85)" }}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="rgba(240,192,64,0.4)" className="mb-1" aria-hidden="true">
            <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z" />
          </svg>
          <p className="text-xs" style={{ color: "rgba(240,192,64,0.8)" }}>Camera inactive</p>
        </div>
      )}
      {status === "ready" && (
        <div className="absolute bottom-1 left-1 right-1 rounded bg-black/85 px-2 py-1 text-center text-[10px] leading-tight text-yellow-100" role="status" aria-live="polite">
          Object recognition is active. It may miss objects or misidentify them; it does not detect every obstacle, confirm hazards, or estimate distance. Do not rely on it as your only mobility aid.
        </div>
      )}
    </div>
  );
}
