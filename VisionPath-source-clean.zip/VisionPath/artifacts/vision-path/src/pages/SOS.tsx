import { useCallback, useEffect, useRef, useState } from "react";
import { useUser } from "@/contexts/UserContext";
import { speak } from "@/utils/speech";
import { translate } from "@/utils/translations";
import TBButton from "@/components/TBButton";

const COUNTDOWN_SEC = 5;

type ShareLink = { name: string; whatsapp: string; sms: string };
type RequestStatus = "recording" | "recorded" | "failed" | null;

function buildShareLinks(contacts: { name: string; phone: string }[], message: string): ShareLink[] {
  return contacts.flatMap((contact) => {
    const digits = contact.phone.replace(/\D/g, "");
    if (digits.length < 7) return [];
    const body = encodeURIComponent(message);
    return [{
      name: contact.name,
      whatsapp: `https://wa.me/${digits}?text=${body}`,
      sms: `sms:${digits}?body=${body}`,
    }];
  });
}

export default function SOS() {
  const { user, location, startTracking, isTracking, language } = useUser();
  const [countdown, setCountdown] = useState<number | null>(null);
  const [requestStatus, setRequestStatus] = useState<RequestStatus>(null);
  const [shareLinks, setShareLinks] = useState<ShareLink[]>([]);
  const [statusMessage, setStatusMessage] = useState("");
  const timerRef = useRef<number | null>(null);
  const requestInProgressRef = useRef(false);

  useEffect(() => {
    if (!isTracking) startTracking();
  }, [isTracking, startTracking]);

  useEffect(() => () => {
    if (timerRef.current !== null) window.clearInterval(timerRef.current);
  }, []);

  const buildMessage = useCallback(() => {
    const name = user?.name || "VisionPath user";
    const locationText = location
      ? `https://maps.google.com/?q=${location.lat.toFixed(6)},${location.lng.toFixed(6)}`
      : translate(language, "gpsUnavailable");
    return translate(language, "sosMessage", { name, location: locationText });
  }, [language, location, user?.name]);

  const recordSOS = useCallback(async () => {
    if (requestInProgressRef.current) return;
    requestInProgressRef.current = true;
    setCountdown(null);
    setRequestStatus("recording");
    setStatusMessage("Recording SOS request…");

    const message = buildMessage();
    setShareLinks(buildShareLinks(user?.familyContacts ?? [], message));
    if (navigator.vibrate) navigator.vibrate([500, 200, 500, 200, 500]);

    try {
      const response = await fetch("/api/visionpath/sos", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lat: location?.lat ?? null,
          lng: location?.lng ?? null,
          message,
        }),
      });
      const result = response.ok
        ? await response.json() as { status?: string }
        : null;
      if (!response.ok || result?.status !== "recorded") {
        throw new Error("SOS recording was not confirmed");
      }
      const text = translate(language, "sosRecorded");
      setRequestStatus("recorded");
      setStatusMessage(text);
      speak(text, { priority: "critical", language });
    } catch {
      const text = translate(language, "sosRecordFailed");
      setRequestStatus("failed");
      setStatusMessage(text);
      speak(text, { priority: "critical", language });
    } finally {
      requestInProgressRef.current = false;
    }
  }, [buildMessage, language, location, user?.familyContacts]);

  function startSOS(withCountdown: boolean) {
    if (timerRef.current !== null || requestInProgressRef.current) return;
    setRequestStatus(null);
    setStatusMessage("");
    setShareLinks([]);
    if (navigator.vibrate) navigator.vibrate([200, 100, 200, 100, 200]);
    if (!withCountdown) {
      void recordSOS();
      return;
    }

    let remaining = COUNTDOWN_SEC;
    setCountdown(remaining);
    speak(translate(language, "sosCountdown", { count: remaining }), { priority: "critical", language });
    timerRef.current = window.setInterval(() => {
      remaining -= 1;
      setCountdown(remaining);
      if (remaining <= 0) {
        if (timerRef.current !== null) window.clearInterval(timerRef.current);
        timerRef.current = null;
        void recordSOS();
      }
    }, 1_000);
  }

  function cancelSOS() {
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setCountdown(null);
    const text = translate(language, "sosCancelled");
    setStatusMessage(text);
    speak(text, { priority: "critical", language });
  }

  function resetResult() {
    setRequestStatus(null);
    setShareLinks([]);
    setStatusMessage("");
  }

  const contacts = user?.familyContacts ?? [];

  return (
    <main className="min-h-screen flex flex-col" style={{ background: "var(--vp-page)", color: "var(--vp-text)" }}>
      <div className="px-4 pt-4 pb-2">
        <h1 className="text-lg font-semibold" style={{ color: "var(--vp-danger)" }}>SOS Emergency</h1>
        <p className="text-xs leading-relaxed" style={{ color: "var(--vp-text-muted)" }}>
          VisionPath records an SOS request. It does not automatically contact emergency services or send messages.
        </p>
      </div>

      <div className="flex-1 px-4 pb-6">
        {requestStatus === null && countdown === null && (
          <>
            <TBButton
              label={`Record an SOS request after a ${COUNTDOWN_SEC}-second cancellation countdown`}
              onClick={() => startSOS(true)}
              className="w-full mt-4 min-h-36 rounded-3xl font-bold text-2xl flex flex-col items-center justify-center transition-all active:scale-95"
              style={{
                padding: "30px 16px",
                background: "linear-gradient(135deg, #874540, #a9534c)",
                color: "white",
                boxShadow: "0 0 40px rgba(204,0,0,0.45)",
                border: "2px solid rgba(255,100,100,0.3)",
              }}
            >
              <span aria-hidden="true">🆘</span>
              <span>SOS request</span>
              <span className="text-sm font-normal mt-1 opacity-90">5-second countdown — records in VisionPath only</span>
            </TBButton>

            <section className="mt-3 p-3 rounded-xl" style={{ background: "var(--vp-success-surface)", border: "1px solid var(--vp-border)" }}>
              <h3 className="text-xs font-medium mb-1" style={{ color: "var(--vp-success)" }}>Current location</h3>
              {location ? (
                <p className="text-xs" style={{ color: "var(--vp-text-soft)" }}>
                  {location.lat.toFixed(5)}, {location.lng.toFixed(5)} · ±{Math.round(location.accuracy)}m
                </p>
              ) : (
                <p className="text-xs" style={{ color: "var(--vp-danger)" }}>
                  GPS location unavailable. The SOS record will not include coordinates.
                </p>
              )}
            </section>

            <section className="mt-3 p-4 rounded-xl" style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}>
              <h3 className="text-sm font-medium mb-2" style={{ color: "var(--vp-accent-bright)" }}>Request includes</h3>
              <ul className="space-y-1 text-sm" style={{ color: "var(--vp-text-soft)" }}>
                <li>• Your profile name</li>
                <li>• Current GPS coordinates, if available</li>
                <li>• A map link and emergency message in the selected language</li>
              </ul>
            </section>

            {contacts.length > 0 ? (
              <section className="mt-4" aria-labelledby="sos-contacts-title">
                <h3 id="sos-contacts-title" className="text-sm font-medium mb-2" style={{ color: "var(--vp-text-muted)" }}>
                  Saved emergency contacts (not automatically notified)
                </h3>
                {contacts.map((contact) => (
                  <div key={contact.id} className="flex items-center gap-3 p-3 mb-2 rounded-xl"
                    style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}>
                    <div aria-hidden="true" className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0"
                      style={{ background: "var(--vp-accent)", color: "var(--vp-accent-ink)" }}>
                      {contact.name[0]?.toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-medium" style={{ color: "var(--vp-text-soft)" }}>{contact.name}</p>
                      <p className="text-xs" style={{ color: "var(--vp-text-muted)" }}>{contact.phone}</p>
                    </div>
                  </div>
                ))}
              </section>
            ) : (
              <section className="mt-4 p-3 rounded-xl text-center" style={{ background: "var(--vp-surface)", border: "1px dashed var(--vp-border)" }}>
                <p className="text-sm" style={{ color: "var(--vp-text-muted)" }}>No emergency contacts saved.</p>
                <p className="text-xs mt-1" style={{ color: "var(--vp-text-muted)" }}>Add contacts in your Profile.</p>
              </section>
            )}

            <TBButton
              label="Record an SOS request now without a countdown"
              onClick={() => startSOS(false)}
              className="w-full mt-4 min-h-12 py-3.5 rounded-2xl font-semibold text-base"
              style={{ background: "#23645b", color: "#ffffff", border: "1px solid #6aa99c" }}
            >
              Record now (no countdown)
            </TBButton>
          </>
        )}

        {countdown !== null && (
          <section className="mt-10 text-center" aria-labelledby="sos-countdown-title">
            <div
              className="w-36 h-36 rounded-full flex flex-col items-center justify-center mx-auto mb-6"
              style={{ background: "linear-gradient(135deg, #874540, #a9534c)", boxShadow: "0 0 42px rgba(135, 69, 64, 0.3)" }}
              role="timer"
              aria-label={`SOS request countdown: ${countdown} seconds remaining`}
              aria-live="polite"
              aria-atomic="true"
            >
              <span className="text-6xl font-bold text-white" aria-hidden="true">{countdown}</span>
              <span className="text-xs text-red-200 mt-1">recording request</span>
            </div>
            <h3 id="sos-countdown-title" className="text-xl font-semibold mb-2" style={{ color: "var(--vp-danger)" }}>
              Recording SOS request in {countdown}s
            </h3>
            <p className="text-sm mb-3" style={{ color: "var(--vp-text-muted)" }}>No message will be sent automatically. You can cancel this countdown at any time before it ends.</p>
            <TBButton
              label="Cancel the SOS request countdown"
              onClick={cancelSOS}
              className="min-h-14 px-10 py-4 rounded-2xl font-semibold text-base"
              style={{ background: "var(--vp-surface-raised)", border: "2px solid var(--vp-border-strong)", color: "var(--vp-text)" }}
            >
              Cancel
            </TBButton>
          </section>
        )}

        {requestStatus !== null && (
          <section className="mt-6 text-center" aria-labelledby="sos-result-title">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4"
              style={{
                background: requestStatus === "recorded"
                  ? "linear-gradient(135deg, #315c3f, #497b55)"
                  : requestStatus === "failed"
                    ? "linear-gradient(135deg, #874540, #a9534c)"
                    : "linear-gradient(135deg, #566748, #74865d)",
              }}
              aria-hidden="true"
            >
              {requestStatus === "recording" ? "…" : requestStatus === "recorded" ? "✓" : "!"}
            </div>
            <h3 id="sos-result-title" className="text-xl font-bold mb-2" style={{ color: requestStatus === "recorded" ? "var(--vp-success)" : "var(--vp-danger)" }}>
              {requestStatus === "recording" ? "Recording request…" : requestStatus === "recorded" ? "Request recorded" : "Request not recorded"}
            </h3>
            <p className="text-sm mb-5" role="status" aria-live="polite" style={{ color: "var(--vp-text-soft)" }}>
              {statusMessage}
            </p>
            <p className="text-sm mb-4 rounded-xl p-3" style={{ background: "var(--vp-surface)", color: "var(--vp-accent-bright)" }}>
              No message has been sent. Opening WhatsApp or SMS creates a draft; you must review it and press Send.
            </p>

            {shareLinks.length > 0 && (
              <section className="mb-4 text-left" aria-labelledby="manual-message-title">
                <h4 id="manual-message-title" className="text-sm mb-2 font-medium" style={{ color: "var(--vp-text-muted)" }}>
                  Choose a contact and send manually
                </h4>
                {shareLinks.map((link) => (
                  <div key={`${link.name}-${link.whatsapp}`} className="flex gap-2 mb-2">
                    <a
                      href={link.whatsapp}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 min-h-12 py-3 rounded-xl text-sm font-semibold text-center"
                      style={{ background: "#23645b", color: "#ffffff" }}
                    >
                      WhatsApp {link.name}
                    </a>
                    <a
                      href={link.sms}
                      className="flex-1 min-h-12 py-3 rounded-xl text-sm font-semibold text-center"
                      style={{ background: "var(--vp-surface-raised)", color: "var(--vp-text-soft)", border: "1px solid var(--vp-border)" }}
                    >
                      SMS {link.name}
                    </a>
                  </div>
                ))}
              </section>
            )}

            <TBButton
              label="Return to SOS screen"
              onClick={resetResult}
              className="min-h-12 px-8 py-3 rounded-2xl font-semibold"
              style={{ background: "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))", color: "var(--vp-accent-ink)" }}
            >
              Done
            </TBButton>
          </section>
        )}
      </div>
    </main>
  );
}
