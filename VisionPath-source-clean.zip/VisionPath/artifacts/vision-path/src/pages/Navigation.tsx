import { useState, useEffect, useRef, useCallback } from "react";
import { useUser } from "@/contexts/UserContext";
import { fetchRoute, geocodeAddress, getDistanceMeter, getRouteProgress, RouteStep } from "@/utils/navigation";
import { metersToSteps } from "@/utils/stepCalculator";
import { isSpeechPaused, pauseSpeech, repeatLastSpeech, resumeSpeech, speak, stopSpeaking } from "@/utils/speech";
import { languageInfo, localizedAction, localizedInstruction, localizedStepCount, SUPPORTED_LANGUAGES, translate, type LanguageCode } from "@/utils/translations";
import ObstacleDetector from "@/components/ObstacleDetector";
import LeafletMap from "@/components/LeafletMap";
import { announce } from "@/utils/announce";
import TBButton from "@/components/TBButton";
import { useLocation } from "wouter";

type NavState = "idle" | "searching" | "preview" | "navigating" | "arrived";

interface RouteInfo {
  steps: RouteStep[];
  totalDistanceM: number;
  totalDurationS: number;
  polyline: [number, number][];
  travelMode: "walking";
  provider: "OpenStreetMap foot routing";
}

export default function Navigation() {
  const { user, location, startTracking, isTracking, locationError, language, setLanguage, voiceAvailability } = useUser();
  const [, navigate] = useLocation();
  const [destination, setDestination] = useState("");
  const [navState, setNavState] = useState<NavState>("idle");
  const [route, setRoute] = useState<RouteInfo | null>(null);
  const [currentStepIdx, setCurrentStepIdx] = useState(0);
  const [distanceToNextSteps, setDistanceToNextSteps] = useState(0);
  const [destCoords, setDestCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [languageMessage, setLanguageMessage] = useState("");
  const [obstacleActive, setObstacleActive] = useState(false);
  const [isOnline, setIsOnline] = useState(() => navigator.onLine);
  const [speechPaused, setSpeechPaused] = useState(false);
  const lastAnnouncedStep = useRef(-1);
  const lastAnnouncedDist = useRef(9999);
  const lastProgressAlong = useRef(0);
  const lastProcessedLocationTimestamp = useRef(0);
  const offRouteSamples = useRef(0);
  const lastRerouteAt = useRef(0);
  const rerouting = useRef(false);
  const inaccurateGpsAnnounced = useRef(false);
  const navigationSession = useRef(0);
  const lastGuidanceLanguage = useRef(language);
  const stepLengthM = user?.stepLengthM ?? 0.75;

  // Screen-reader announcements for GPS and navigation state (state changes only).
  const hadLocation = useRef<boolean | null>(null);
  useEffect(() => {
    const has = !!location;
    if (hadLocation.current === has) return;
    hadLocation.current = has;
    announce(has ? "GPS location found." : "Waiting for GPS location.");
  }, [location]);

  const lastNavState = useRef(navState);
  useEffect(() => {
    if (lastNavState.current === navState) return;
    lastNavState.current = navState;
    const text: Record<string, string> = {
      searching: "Searching for route.",
      preview: "Route ready. Select Start navigation to begin.",
      idle: "Navigation stopped.",
    };
    if (text[navState]) announce(text[navState]);
  }, [navState]);

  const obstacleMounted = useRef(false);
  useEffect(() => {
    if (!obstacleMounted.current) { obstacleMounted.current = true; return; }
    announce(obstacleActive ? "Camera obstacle detection turned on." : "Camera obstacle detection turned off.");
  }, [obstacleActive]);

  useEffect(() => {
    if (!isTracking) startTracking();
  }, [isTracking, startTracking]);

  useEffect(() => {
    if (navState === "navigating") setObstacleActive(true);
  }, [navState]);

  useEffect(() => {
    const online = () => {
      setIsOnline(true);
      setError((current) => current === translate(language, "offline") ? null : current);
    };
    const offline = () => {
      setIsOnline(false);
      if (navState === "navigating") {
        const message = translate(language, "offline");
        setError(message);
        speak(message, { priority: "guidance" });
      }
    };
    window.addEventListener("online", online);
    window.addEventListener("offline", offline);
    return () => {
      window.removeEventListener("online", online);
      window.removeEventListener("offline", offline);
    };
  }, [language, navState]);

  useEffect(() => {
    if (!languageMessage) return;
    const timer = window.setTimeout(() => setLanguageMessage(""), 4_000);
    return () => window.clearTimeout(timer);
  }, [languageMessage]);

  useEffect(() => () => {
    navigationSession.current += 1;
    stopSpeaking();
  }, []);

  useEffect(() => {
    if (lastGuidanceLanguage.current === language) return;
    lastGuidanceLanguage.current = language;
    if (navState === "navigating" && route?.steps[currentStepIdx]) {
      speak(
        localizedInstruction(route.steps[currentStepIdx], language, distanceToNextSteps),
        { priority: "guidance", language },
      );
    }
  }, [language, navState, route, currentStepIdx, distanceToNextSteps]);

  async function searchAndRoute() {
    if (!destination.trim()) return;
    if (!location) {
      const message = translate(language, "gpsWait");
      setError(message);
      speak(message, { priority: "guidance" });
      return;
    }
    if (location.accuracy > 50 || Date.now() - location.timestamp > 60_000) {
      const message = translate(language, "gpsInaccurate");
      setError(message);
      speak(message, { priority: "guidance", language });
      return;
    }
    if (!isOnline) {
      const message = translate(language, "offline");
      setError(message);
      speak(message, { priority: "guidance" });
      return;
    }
    setNavState("searching"); setError(null);
    const geo = await geocodeAddress(destination);
    if (!geo) {
      const message = navigator.onLine ? translate(language, "placeNotFound") : translate(language, "offline");
      setError(message);
      speak(message, { priority: "guidance" });
      setNavState("idle");
      return;
    }
    setDestCoords({ lat: geo.lat, lng: geo.lng });
    const result = await fetchRoute(location.lat, location.lng, geo.lat, geo.lng);
    if (!result) {
      const message = navigator.onLine ? translate(language, "routeFailed") : translate(language, "offline");
      setError(message);
      speak(message, { priority: "guidance" });
      setNavState("idle");
      return;
    }
    setRoute(result);
    setNavState("preview");
  }

  function startNavigation() {
    if (!route) return;
    if (!location || location.accuracy > 50 || Date.now() - location.timestamp > 60_000) {
      const message = translate(language, "gpsInaccurate");
      setError(message);
      speak(message, { priority: "guidance", language });
      return;
    }
    navigationSession.current += 1;
    setCurrentStepIdx(0);
    lastProgressAlong.current = 0;
    lastProcessedLocationTimestamp.current = 0;
    offRouteSamples.current = 0;
    lastAnnouncedStep.current = -1;
    lastAnnouncedDist.current = 9999;
    inaccurateGpsAnnounced.current = false;
    setNavState("navigating");
    setObstacleActive(true);
    const firstStep = route.steps[0];
    if (firstStep) {
      const steps = metersToSteps(firstStep.distanceM, stepLengthM);
      speak(
        `${translate(language, "navigationStarted")} ${localizedInstruction(firstStep, language, steps)}`,
        { priority: "guidance", language },
      );
    }
  }

  function stopNavigation() {
    navigationSession.current += 1;
    stopSpeaking(); setNavState("idle"); setRoute(null);
    setCurrentStepIdx(0); setDestCoords(null); setObstacleActive(false);
    rerouting.current = false;
    offRouteSamples.current = 0;
    lastProgressAlong.current = 0;
    inaccurateGpsAnnounced.current = false;
  }

  useEffect(() => {
    if (navState !== "navigating" || !location || !route || !destCoords) return;
    if (location.timestamp <= lastProcessedLocationTimestamp.current) return;
    lastProcessedLocationTimestamp.current = location.timestamp;
    if (location.accuracy > 60 || Date.now() - location.timestamp > 30_000) {
      if (!inaccurateGpsAnnounced.current) {
        inaccurateGpsAnnounced.current = true;
        const message = translate(language, "gpsInaccurate");
        setError(message);
        speak(message, { priority: "guidance", language });
      }
      return;
    }
    inaccurateGpsAnnounced.current = false;
    const progress = getRouteProgress(location.lat, location.lng, route.polyline);
    if (!progress) return;
    const routeToleranceM = Math.min(100, Math.max(35, location.accuracy * 1.5));
    if (progress.distanceFromRouteM > routeToleranceM) {
      offRouteSamples.current += 1;
    } else {
      offRouteSamples.current = 0;
      if (error === translate(language, "rerouting")) setError(null);
    }

    if (
      offRouteSamples.current >= 2
      && !rerouting.current
      && Date.now() - lastRerouteAt.current >= 20_000
    ) {
      rerouting.current = true;
      offRouteSamples.current = 0;
      lastRerouteAt.current = Date.now();
      const session = navigationSession.current;
      const message = translate(language, "rerouting");
      setError(message);
      speak(message, { priority: "guidance", language });
      void (async () => {
        const updatedRoute = await fetchRoute(location.lat, location.lng, destCoords.lat, destCoords.lng);
        if (session !== navigationSession.current) return;
        rerouting.current = false;
        if (updatedRoute) {
          setRoute(updatedRoute);
          setCurrentStepIdx(0);
          lastProgressAlong.current = 0;
          lastProcessedLocationTimestamp.current = 0;
          lastAnnouncedStep.current = -1;
          lastAnnouncedDist.current = 9999;
          offRouteSamples.current = 0;
          setError(null);
        } else {
          const failure = translate(language, "rerouteFailed");
          setNavState("idle");
          setObstacleActive(false);
          setRoute(null);
          setDestCoords(null);
          setError(failure);
          speak(failure, { priority: "critical", language });
        }
      })();
      return;
    }

    lastProgressAlong.current = Math.max(
      Math.max(0, lastProgressAlong.current - 15),
      progress.distanceAlongM,
    );
    const currentStep = route.steps[currentStepIdx];
    if (!currentStep || rerouting.current) return;
    const distToDest = getDistanceMeter(location.lat, location.lng, destCoords.lat, destCoords.lng);
    if (distToDest < 25 && lastProgressAlong.current >= route.totalDistanceM - 35) {
      setNavState("arrived");
      // Stop camera inference when the navigation session ends.
      setObstacleActive(false);
      speak(translate(language, "arrived"), { priority: "guidance", language });
      return;
    }
    const nextStepIndex = route.steps.findIndex((step) => (
      step.endDistanceM > lastProgressAlong.current + 2
    ));
    const resolvedStepIndex = nextStepIndex === -1 ? route.steps.length - 1 : nextStepIndex;
    if (resolvedStepIndex !== currentStepIdx) setCurrentStepIdx(resolvedStepIndex);
    const activeStep = route.steps[resolvedStepIndex];
    if (!activeStep) return;
    const metersRemaining = Math.max(0, activeStep.endDistanceM - lastProgressAlong.current);
    const stepsRemaining = metersToSteps(metersRemaining, stepLengthM);
    setDistanceToNextSteps(stepsRemaining);
    if (resolvedStepIndex !== lastAnnouncedStep.current) {
      lastAnnouncedStep.current = resolvedStepIndex;
      lastAnnouncedDist.current = stepsRemaining;
      speak(localizedInstruction(activeStep, language, stepsRemaining), { priority: "guidance", language });
    } else if (stepsRemaining <= 20 && lastAnnouncedDist.current > 20) {
      lastAnnouncedDist.current = stepsRemaining;
      const nextStep = route.steps[resolvedStepIndex + 1];
      if (nextStep) {
        speak(
          localizedInstruction(nextStep, language, 20, true),
          { priority: "guidance", language },
        );
      }
    } else if (stepsRemaining <= 5 && lastAnnouncedDist.current > 5) {
      lastAnnouncedDist.current = stepsRemaining;
      // The index is derived from route progress above, not a countdown estimate.
    }
  }, [location, navState, route, currentStepIdx, destCoords, language, stepLengthM, error]);

  const totalSteps = route ? metersToSteps(route.totalDistanceM, stepLengthM) : 0;
  const currentStep = route?.steps[currentStepIdx];
  const repeatGuidance = useCallback(() => {
    if (navState === "navigating" && currentStep) {
      speak(
        localizedInstruction(currentStep, language, distanceToNextSteps),
        { priority: "guidance", language },
      );
    } else {
      repeatLastSpeech();
    }
  }, [navState, currentStep, language, distanceToNextSteps]);

  const quickDests = ["Hospital", "Police Station", "Bus Stop", "Railway Station", "Market"];

  return (
    <main className="flex flex-col" style={{ minHeight: "100vh", background: "var(--vp-page)", color: "var(--vp-text)" }}>
      <h1 className="sr-only">Navigation</h1>
      {/* Text fallback: only when in-app voice cannot speak, so TalkBack users are not told each step twice. */}
      <div className="sr-only" role="status" aria-live="polite" aria-atomic="true">
        {navState === "navigating" && currentStep && voiceAvailability !== "available"
          ? localizedInstruction(currentStep, language, distanceToNextSteps)
          : ""}
      </div>

      {/* === CAMERA + OBSTACLE DETECTION === */}
      <div className="relative" style={{ flexShrink: 0 }}>
        <ObstacleDetector active={obstacleActive} language={language} />

        {/* obstacle toggle overlay button */}
        <div className="absolute top-2 right-2 flex gap-2 z-10">
          <TBButton
            label={obstacleActive ? "Turn off obstacle detection" : "Turn on obstacle detection"}
            onClick={() => setObstacleActive(v => !v)}
            className="px-2 py-1 rounded-lg text-xs font-medium"
            style={{ background: obstacleActive ? "rgba(203, 217, 180, 0.96)" : "rgba(17, 24, 19, 0.92)", color: obstacleActive ? "var(--vp-accent-ink)" : "var(--vp-accent-bright)", border: "1px solid var(--vp-border-strong)" }}
          >
            {obstacleActive ? "CAM ON" : "CAM OFF"}
          </TBButton>
        </div>
      </div>

      <div className="flex items-center gap-3 px-3 py-2" style={{ background: "var(--vp-page-raised)", borderBottom: "1px solid var(--vp-border)" }}>
        <label htmlFor="navigation-language" className="text-sm font-semibold" style={{ color: "var(--vp-text-soft)" }}>
          {translate(language, "languageSelectorLabel")}
        </label>
        <select
          id="navigation-language"
          value={language}
           onChange={(event) => {
            const nextLanguage = event.target.value as LanguageCode;
            setLanguage(nextLanguage);
             setLanguageMessage(translate(nextLanguage, "languageSelected", { language: languageInfo(nextLanguage).name }));
          }}
          className="min-h-12 flex-1 rounded-xl px-3 py-2 text-base font-semibold focus-visible:ring-2 focus-visible:ring-yellow-300"
          style={{ background: "var(--vp-input)", border: "2px solid var(--vp-border-strong)", color: "var(--vp-text)" }}
          aria-describedby="navigation-voice-status"
        >
          {SUPPORTED_LANGUAGES.map((item) => (
            <option key={item.code} value={item.code}>{item.name}</option>
          ))}
        </select>
      </div>
      <div id="navigation-voice-status" role="status" aria-live="polite" className="px-3 pt-1 text-xs" style={{ color: "var(--vp-text-muted)" }}>
        {languageMessage
          || (voiceAvailability === "available" && translate(language, "voiceAvailable", { language: languageInfo(language).name }))
          || (voiceAvailability === "checking" && translate(language, "voiceChecking", { language: languageInfo(language).name }))
          || (voiceAvailability === "unavailable" && translate(language, "voiceUnavailable", { language: languageInfo(language).name }))
          || (voiceAvailability === "unsupported" && translate(language, "speechUnsupported"))
          || (voiceAvailability === "error" && translate(language, "speechError"))}
      </div>
      {voiceAvailability === "unavailable" && language !== "en" && (
        <button
          type="button"
          onClick={() => {
            setLanguage("en");
             setLanguageMessage(translate("en", "languageSelected", { language: languageInfo("en").name }));
          }}
          className="mx-3 mt-1 min-h-12 rounded-xl px-4 py-3 text-base font-semibold focus-visible:ring-2 focus-visible:ring-white"
          style={{ background: "var(--vp-accent)", color: "var(--vp-accent-ink)" }}
        >
          Use English voice
        </button>
      )}

      {(error || locationError || !isOnline) && (
        <div className="px-3 pt-2" role="alert">
          <p className="rounded-xl px-3 py-2 text-sm leading-relaxed" style={{ background: "var(--vp-danger-surface)", border: "1px solid var(--vp-danger-border)", color: "var(--vp-danger)" }}>
            {!isOnline ? translate(language, "offline") : locationError || error}
          </p>
        </div>
      )}

      {/* === NAVIGATION SEARCH / CONTROLS === */}
      {navState === "idle" && (
        <div className="px-3 pt-3">
          <div className="flex gap-2 mb-2">
            <input
              type="text"
              aria-label="Destination address or place"
              value={destination}
              onChange={e => setDestination(e.target.value)}
              onKeyDown={e => e.key === "Enter" && searchAndRoute()}
              placeholder="Enter destination..."
              className="flex-1 px-3 py-2.5 rounded-xl text-sm outline-none"
              style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
            />
            <TBButton
              label="Search route"
              onClick={searchAndRoute}
              className="px-4 py-2.5 rounded-xl font-semibold text-sm"
              style={{ background: "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))", color: "var(--vp-accent-ink)" }}
            >
              Go
            </TBButton>
          </div>
          {location && (
            <p className="text-xs mb-2" style={{ color: "var(--vp-success)" }}>
              Location: ±{Math.round(location.accuracy)}m accuracy
            </p>
          )}
          <div className="flex gap-2 flex-wrap mb-2">
            {quickDests.map(d => (
              <TBButton
                key={d}
                label={`Navigate to ${d}`}
                onClick={() => { setDestination(d); }}
                className="px-2.5 py-1.5 rounded-lg text-xs"
                style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)", color: "var(--vp-text-soft)" }}
              >
                {d}
              </TBButton>
            ))}
          </div>
        </div>
      )}

      {navState === "searching" && (
        <div className="flex items-center justify-center py-6">
          <div className="w-8 h-8 border-2 border-yellow-400 border-t-transparent rounded-full animate-spin mr-3" />
          <p style={{ color: "var(--vp-accent-bright)" }}>Calculating route...</p>
        </div>
      )}

      {navState === "preview" && route && (
        <div className="px-3 pt-3">
          <div className="p-3 rounded-xl mb-2" style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}>
            <p className="text-sm font-semibold" style={{ color: "var(--vp-accent-bright)" }}>Route to: {destination}</p>
            <div className="flex gap-4 text-xs mt-1" style={{ color: "var(--vp-text-muted)" }}>
              <span>{localizedStepCount(totalSteps, language)}</span>
              <span>{Math.round(route.totalDurationS / 60)} min walking</span>
            </div>
            <p className="mt-2 text-xs leading-relaxed" style={{ color: "var(--vp-text-soft)" }}>
              Pedestrian routing via OpenStreetMap foot data. Routes depend on mapped paths and may not be accessible; check your surroundings. An internet connection is required for route search and rerouting.
            </p>
          </div>
          <div className="max-h-28 overflow-y-auto mb-2 space-y-1">
            {route.steps.slice(0, -1).map((step, idx) => (
              <div key={idx} className="flex gap-2 px-3 py-2 rounded-lg" style={{ background: "var(--vp-surface)" }}>
                <span className="text-xs font-bold w-4 flex-shrink-0" style={{ color: "var(--vp-accent-bright)" }}>{idx + 1}</span>
                <div>
                  <p className="text-xs" style={{ color: "var(--vp-text-soft)" }}>{localizedAction(step, language)}</p>
                  <p className="text-xs" style={{ color: "var(--vp-text-muted)" }}>
                    {localizedStepCount(metersToSteps(step.distanceM, stepLengthM), language)}
                  </p>
                </div>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <TBButton
              label="Cancel route"
              onClick={stopNavigation}
              className="flex-1 py-2.5 rounded-xl text-sm"
              style={{ border: "1px solid var(--vp-border)", color: "var(--vp-text-muted)", background: "transparent" }}
            >
              Cancel
            </TBButton>
            <TBButton
              label="Start navigation"
              onClick={startNavigation}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold"
              style={{ background: "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))", color: "var(--vp-accent-ink)" }}
            >
              Start
            </TBButton>
          </div>
        </div>
      )}

      {navState === "navigating" && currentStep && (
        <div className="px-3 pt-2">
          <div className="p-3 rounded-2xl mb-2" style={{ background: "var(--vp-surface)", border: "2px solid var(--vp-border-strong)" }}>
            <div className="flex items-center gap-3">
              <div className="text-4xl font-bold" style={{ color: "var(--vp-accent-bright)" }}>
                {localizedStepCount(distanceToNextSteps, language)}
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold leading-snug" style={{ color: "var(--vp-text-soft)" }}>
                  {localizedAction(currentStep, language)}
                </p>
                {route && route.steps[currentStepIdx + 1] && (
                  <p className="text-xs mt-0.5" style={{ color: "var(--vp-text-muted)" }}>
                    {localizedInstruction(route.steps[currentStepIdx + 1], language, distanceToNextSteps, true)}
                  </p>
                )}
              </div>
            </div>
            {route && (
              <div className="mt-2 h-1.5 rounded-full" style={{ background: "var(--vp-border)" }}>
                <div
                  className="h-full rounded-full transition-all"
                  style={{
                    background: "linear-gradient(90deg, var(--vp-accent), var(--vp-accent-bright))",
                    width: `${Math.min(100, (currentStepIdx / Math.max(1, route.steps.length - 1)) * 100)}%`
                  }}
                />
              </div>
            )}
          </div>
          <div className="grid grid-cols-3 gap-2 mb-2">
            <button
              type="button"
              onClick={repeatGuidance}
              aria-label="Repeat spoken navigation guidance"
              className="min-h-12 rounded-xl px-2 py-3 text-sm font-semibold focus-visible:ring-2 focus-visible:ring-yellow-300"
              style={{ background: "var(--vp-surface-raised)", border: "1px solid var(--vp-border-strong)", color: "var(--vp-accent-bright)" }}
            >
              Repeat
            </button>
            <button
              type="button"
              onClick={() => {
                if (isSpeechPaused()) {
                  resumeSpeech();
                  setSpeechPaused(false);
                } else {
                  pauseSpeech();
                  setSpeechPaused(true);
                }
              }}
              aria-label={speechPaused ? "Resume spoken navigation guidance" : "Pause spoken navigation guidance"}
              className="min-h-12 rounded-xl px-2 py-3 text-sm font-semibold focus-visible:ring-2 focus-visible:ring-yellow-300"
              style={{ background: "var(--vp-surface-raised)", border: "1px solid var(--vp-border-strong)", color: "var(--vp-accent-bright)" }}
            >
              {speechPaused ? "Resume" : "Pause"}
            </button>
          </div>
          <TBButton
            label="Stop navigation"
            onClick={stopNavigation}
            className="w-full py-2.5 rounded-xl text-sm font-semibold mb-2"
            style={{ background: "var(--vp-danger-surface)", border: "1px solid var(--vp-danger-border)", color: "var(--vp-danger)" }}
          >
            Stop Navigation
          </TBButton>
        </div>
      )}

      {navState === "arrived" && (
        <div className="flex flex-col items-center py-6 px-3">
          <div className="w-14 h-14 rounded-full flex items-center justify-center mb-2"
            style={{ background: "linear-gradient(135deg, #0a5000, #0a8000)" }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="white"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" /></svg>
          </div>
          <h3 className="text-xl font-bold mb-1" style={{ color: "var(--vp-accent-bright)" }}>{translate(language, "arrived")}</h3>
          <TBButton label="Done, go back" onClick={stopNavigation} className="px-6 py-2.5 rounded-2xl font-semibold mt-2"
            style={{ background: "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))", color: "var(--vp-accent-ink)" }}>
            Done
          </TBButton>
        </div>
      )}

      {/* === MAP VIEW (always visible during nav and preview) === */}
      {(navState === "navigating" || navState === "preview" || navState === "idle") && (
        <div className="flex-1 px-3 pb-2 mt-1">
          <div className="rounded-2xl overflow-hidden" style={{ border: "1px solid var(--vp-border)", minHeight: "180px" }}>
            <LeafletMap
              userLocation={location ? { lat: location.lat, lng: location.lng } : null}
              destination={destCoords}
              routePolyline={route?.polyline}
              height="180px"
            />
          </div>
        </div>
      )}

      {/* === FLOATING SOS BUTTON — always fires immediately, no TalkBack delay === */}
      <button
        onClick={() => navigate("/sos")}
        aria-label="SOS Emergency — tap to open emergency screen"
        className="fixed z-[9999] flex flex-col items-center justify-center font-bold rounded-full"
        style={{
          bottom: "96px",
          right: "14px",
          width: "56px",
          height: "56px",
          background: "linear-gradient(135deg, #7b3b38, #b65b55)",
          color: "white",
          fontSize: "14px",
          lineHeight: 1,
          boxShadow: "0 0 20px rgba(135,69,64,0.4), 0 2px 8px rgba(0,0,0,0.28)",
          border: "2px solid rgba(240,183,174,0.72)",
        }}
      >
        <span style={{ fontSize: "18px" }} aria-hidden="true">🆘</span>
        <span style={{ fontSize: "10px", marginTop: "1px", letterSpacing: "0.5px" }}>SOS</span>
      </button>
    </main>
  );
}
