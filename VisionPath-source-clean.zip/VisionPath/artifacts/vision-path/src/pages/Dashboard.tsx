import { useState, useEffect } from "react";
import { useUser } from "@/contexts/UserContext";
import TBButton from "@/components/TBButton";
import { useLocation } from "wouter";
import { localizedCompassDirection } from "@/utils/translations";

export default function Dashboard() {
  const { user, location, startTracking, isTracking, locationError, language } = useUser();
  const [, navigate] = useLocation();
  const [compassHeading, setCompassHeading] = useState<number | null>(null);

  useEffect(() => {
    if (!isTracking) startTracking();
  }, []);

  useEffect(() => {
    if (typeof DeviceOrientationEvent !== "undefined") {
      const handler = (e: DeviceOrientationEvent) => {
        if (e.alpha !== null) setCompassHeading(Math.round(e.alpha));
      };
      window.addEventListener("deviceorientation", handler);
      return () => window.removeEventListener("deviceorientation", handler);
    }
    return undefined;
  }, []);

  function getCardinalDirection(deg: number): string {
    return localizedCompassDirection(deg, language);
  }

  return (
    <main className="min-h-screen flex flex-col" style={{ background: "var(--vp-page)", color: "var(--vp-text)" }}>
      <div className="px-4 pt-4 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-lg"
            style={{ background: "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))", color: "var(--vp-accent-ink)" }}>
            {user?.name?.[0]?.toUpperCase() || "V"}
          </div>
          <div>
            <h1 className="text-base font-semibold" style={{ color: "var(--vp-accent-bright)" }}>
              Welcome, {user?.name || "Traveler"}
            </h1>
            <p className="text-xs" style={{ color: "var(--vp-text-muted)" }}>
              Step: {user ? `${(user.stepLengthM * 100).toFixed(0)} cm` : "—"} · UK {user?.ukShoeSize || "—"}
            </p>
          </div>
        </div>
      </div>

        <section className="px-4 grid grid-cols-2 gap-3 mb-4" aria-label="Travel status">
        <div className="p-4 rounded-2xl" style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}>
          <p className="text-xs mb-1" style={{ color: "var(--vp-text-muted)" }}>Location</p>
          {location ? (
            <>
              <p className="text-sm font-semibold" style={{ color: "var(--vp-success)" }}>Active</p>
              <p className="text-xs mt-1" style={{ color: "var(--vp-text-muted)" }}>±{Math.round(location.accuracy)}m</p>
            </>
          ) : (
            <p className="text-sm" style={{ color: "var(--vp-danger)" }}>
              {locationError || "Acquiring..."}
            </p>
          )}
        </div>
        <div className="p-4 rounded-2xl" style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}>
          <p className="text-xs mb-1" style={{ color: "var(--vp-text-muted)" }}>Compass</p>
          {compassHeading !== null ? (
            <>
              <p className="text-sm font-semibold" style={{ color: "var(--vp-accent-bright)" }}>{compassHeading}°</p>
              <p className="text-xs mt-1" style={{ color: "var(--vp-text-muted)" }}>{getCardinalDirection(compassHeading)}</p>
            </>
          ) : (
            <p className="text-sm" style={{ color: "var(--vp-text-muted)" }}>Not available</p>
          )}
        </div>
      </section>

      {/* Quick Start Navigation */}
      <div className="px-4 mb-4">
        <TBButton
          label="Start Navigation — tap to open navigation screen"
          onClick={() => navigate("/navigate")}
          className="w-full min-h-14 py-3.5 rounded-2xl font-semibold text-base flex items-center justify-center gap-2"
          style={{ background: "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))", color: "var(--vp-accent-ink)" }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="var(--vp-accent-ink)" aria-hidden="true">
            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
          </svg>
          Start Navigation
        </TBButton>
      </div>

      <div className="px-4 mb-4">
        <div className="p-4 rounded-2xl" style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}>
          <p className="text-sm font-medium mb-2" style={{ color: "var(--vp-accent-bright)" }}>Camera object detection</p>
          <p className="mb-3 text-xs leading-relaxed" style={{ color: "var(--vp-text-soft)" }}>
            Live camera object detection is available on the navigation screen. It recognizes a limited set of common objects; it does not confirm hazards or measure distance.
          </p>
          <TBButton
            label="Open navigation and camera object detection"
            onClick={() => navigate("/navigate")}
            className="w-full min-h-12 rounded-xl px-3 py-2.5 text-sm font-semibold"
            style={{ background: "var(--vp-surface-raised)", border: "1px solid var(--vp-border-strong)", color: "var(--vp-accent-bright)" }}
          >
            Open navigation
          </TBButton>
        </div>
      </div>

      <div className="px-4 mb-4">
        <div className="p-4 rounded-2xl" style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}>
          <p className="text-sm font-medium mb-3" style={{ color: "var(--vp-accent-bright)" }}>Emergency action</p>
          <TBButton
            label="Open emergency SOS screen"
            onClick={() => navigate("/sos")}
            className="w-full min-h-12 text-left px-3 py-2.5 rounded-lg text-sm"
            style={{ background: "var(--vp-danger-surface)", border: "1px solid var(--vp-danger-border)", color: "var(--vp-danger)" }}
          >
            SOS emergency
          </TBButton>
        </div>
      </div>
    </main>
  );
}
