import { useState } from "react";
import { useUser, FamilyContact } from "@/contexts/UserContext";
import { UK_SHOE_SIZES, getFootLengthCm, calculateStepLength } from "@/utils/stepCalculator";
import { speak } from "@/utils/speech";
import { languageInfo, SUPPORTED_LANGUAGES, translate } from "@/utils/translations";
import { Link } from "wouter";

const ukSizes = Object.keys(UK_SHOE_SIZES).map(Number).sort((a, b) => a - b);

export default function Profile() {
  const { user, setUser, clearUser, language, setLanguage, voiceAvailability } = useUser();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user?.name || "");
  const [heightCm, setHeightCm] = useState(String(user?.heightCm || ""));
  const [ukShoeSize, setUkShoeSize] = useState(String(user?.ukShoeSize || "8"));
  const [contacts, setContacts] = useState<FamilyContact[]>(user?.familyContacts || []);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  function addContact() {
    setContacts(prev => [...prev, { id: Date.now().toString(), name: "", phone: "" }]);
  }

  function updateContact(id: string, field: "name" | "phone", value: string) {
    setContacts(prev => prev.map(c => c.id === id ? { ...c, [field]: value } : c));
  }

  function removeContact(id: string) {
    setContacts(prev => prev.filter(c => c.id !== id));
  }

  async function save() {
    const h = parseFloat(heightCm);
    const s = parseFloat(ukShoeSize);
    const completeContacts = contacts.filter((contact) => contact.name.trim() || contact.phone.trim());
    if (!name.trim() || name.trim().length > 80) {
      setError("Enter a name between 1 and 80 characters.");
      return;
    }
    if (!Number.isFinite(h) || h < 50 || h > 250) {
      setError("Enter a height between 50 and 250 cm.");
      return;
    }
    if (!Number.isFinite(s) || s < 1 || s > 15) {
      setError("Choose a valid UK shoe size.");
      return;
    }
    if (completeContacts.length > 10 || completeContacts.some((contact) =>
      !contact.name.trim() || !/^[+0-9() .-]{7,24}$/.test(contact.phone.trim()),
    )) {
      setError("Each contact needs a name and a valid phone number. Use 7–24 digits or phone symbols.");
      return;
    }
    setError(null);
    setSaving(true);
    try {
      await setUser({
        name: name.trim(),
        heightCm: h,
        ukShoeSize: s,
        familyContacts: completeContacts.map((contact) => ({
          ...contact,
          name: contact.name.trim(),
          phone: contact.phone.trim(),
        })),
      });
      setEditing(false);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Your profile could not be saved.");
    } finally {
      setSaving(false);
    }
  }

  if (!user) return null;

  return (
    <main className="min-h-screen flex flex-col" style={{ background: "var(--vp-page)", color: "var(--vp-text)" }}>
      <div className="px-4 pt-4 pb-2 flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold" style={{ color: "var(--vp-accent-bright)" }}>Profile</h1>
          <p className="text-xs" style={{ color: "var(--vp-text-muted)" }}>Your personal settings</p>
        </div>
        <button
          type="button"
          onClick={() => editing ? void save() : setEditing(true)}
          disabled={saving}
          className="px-4 py-2 rounded-xl text-sm font-medium"
          style={{ background: editing ? "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))" : "var(--vp-surface)", color: editing ? "var(--vp-accent-ink)" : "var(--vp-accent-bright)", border: editing ? "none" : "1px solid var(--vp-border)" }}
        >
          {saving ? "Saving…" : editing ? "Save" : "Edit"}
        </button>
      </div>

      <div className="px-4 space-y-4">
        {error && <p className="rounded-xl p-3 text-sm" style={{ background: "var(--vp-danger-surface)", color: "var(--vp-danger)" }} role="alert">{error}</p>}
        <section
          className="p-4 rounded-2xl"
          style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}
          aria-labelledby="voice-language-heading"
        >
          <h3 id="voice-language-heading" className="text-sm font-semibold mb-2" style={{ color: "var(--vp-accent-bright)" }}>
            {translate(language, "languageSelectorLabel")}
          </h3>
          <p className="text-xs mb-3" style={{ color: "var(--vp-text-muted)" }}>
            Choose a language for spoken directions and obstacle warnings. Language is saved on this device.
          </p>
          <label htmlFor="voice-language" className="block text-sm font-medium mb-2" style={{ color: "var(--vp-text-soft)" }}>
            Language / भाषा
          </label>
          <select
            id="voice-language"
            value={language}
            onChange={(event) => {
              const nextLanguage = event.target.value as typeof language;
              setLanguage(nextLanguage);
              speak(
                translate(nextLanguage, "languageSelected", { language: languageInfo(nextLanguage).name }),
                { priority: "critical", language: nextLanguage },
              );
            }}
            className="w-full min-h-14 px-3 py-3 rounded-xl text-base font-semibold outline-none"
            style={{ background: "var(--vp-input)", border: "2px solid var(--vp-border-strong)", color: "var(--vp-text)" }}
            aria-describedby="voice-language-status"
          >
            {SUPPORTED_LANGUAGES.map((item) => (
              <option key={item.code} value={item.code}>{item.name}</option>
            ))}
          </select>
          <p
            id="voice-language-status"
            role="status"
            aria-live="polite"
            className="mt-3 text-sm leading-relaxed"
            style={{ color: voiceAvailability === "unavailable" || voiceAvailability === "error" || voiceAvailability === "unsupported" ? "var(--vp-danger)" : "var(--vp-text-muted)" }}
          >
            {voiceAvailability === "available" && translate(language, "voiceAvailable", { language: languageInfo(language).name })}
            {voiceAvailability === "checking" && translate(language, "voiceChecking", { language: languageInfo(language).name })}
            {voiceAvailability === "unavailable" && translate(language, "voiceUnavailable", { language: languageInfo(language).name })}
            {voiceAvailability === "unsupported" && translate(language, "speechUnsupported")}
            {voiceAvailability === "error" && translate(language, "speechError")}
          </p>
          {voiceAvailability === "unavailable" && language !== "en" && (
            <button
              type="button"
              onClick={() => {
                setLanguage("en");
                speak(translate("en", "languageSelected", { language: languageInfo("en").name }), { priority: "critical", language: "en" });
              }}
              className="mt-3 min-h-12 w-full rounded-xl px-4 py-3 text-base font-semibold"
              style={{ background: "var(--vp-accent)", color: "var(--vp-accent-ink)" }}
            >
              Use English voice
            </button>
          )}
        </section>

        <div className="p-4 rounded-2xl" style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}>
          <p className="text-xs mb-3 font-medium" style={{ color: "var(--vp-text-muted)" }}>PERSONAL INFO</p>
          <div className="space-y-4">
            <div>
              <label htmlFor="profile-name" className="text-xs mb-1 block" style={{ color: "var(--vp-text-muted)" }}>Name</label>
              {editing ? (
                <input
                  id="profile-name"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  maxLength={80}
                  autoComplete="name"
                  className="w-full px-3 py-2 rounded-lg text-sm outline-none"
                  style={{ background: "var(--vp-input)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
                />
              ) : (
                <p className="text-base font-semibold" style={{ color: "var(--vp-text)" }}>{user.name}</p>
              )}
            </div>
            <div>
              <label htmlFor="profile-height" className="text-xs mb-1 block" style={{ color: "var(--vp-text-muted)" }}>Height (cm)</label>
              {editing ? (
                <input
                  id="profile-height"
                  type="number"
                  value={heightCm}
                  onChange={e => setHeightCm(e.target.value)}
                  min={50}
                  max={250}
                  className="w-full px-3 py-2 rounded-lg text-sm outline-none"
                  style={{ background: "var(--vp-input)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
                />
              ) : (
                <p className="text-base" style={{ color: "var(--vp-text)" }}>{user.heightCm} cm</p>
              )}
            </div>
            <div>
              <label htmlFor="profile-shoe-size" className="text-xs mb-1 block" style={{ color: "var(--vp-text-muted)" }}>Shoe Size (UK / India)</label>
              {editing ? (
                <select
                  id="profile-shoe-size"
                  value={ukShoeSize}
                  onChange={e => setUkShoeSize(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg text-sm outline-none"
                  style={{ background: "var(--vp-input)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
                >
                  {ukSizes.map(s => (
                    <option key={s} value={s}>UK {s} / India {s}</option>
                  ))}
                </select>
              ) : (
                <p className="text-base" style={{ color: "var(--vp-text)" }}>UK {user.ukShoeSize} / India {user.ukShoeSize}</p>
              )}
            </div>
          </div>
        </div>

        <div className="p-4 rounded-2xl" style={{ background: "var(--vp-success-surface)", border: "1px solid var(--vp-border)" }}>
          <p className="text-xs mb-2 font-medium" style={{ color: "var(--vp-text-muted)" }}>CALCULATED STEP SIZE</p>
          <p className="text-3xl font-bold" style={{ color: "var(--vp-success)" }}>
            {(user.stepLengthM * 100).toFixed(1)} cm
          </p>
          <p className="text-xs mt-1" style={{ color: "var(--vp-text-muted)" }}>
            Based on your height ({user.heightCm}cm) and shoe size (UK {user.ukShoeSize})
          </p>
        </div>

        <div className="p-4 rounded-2xl" style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}>
          <p className="text-xs mb-1 font-medium" style={{ color: "var(--vp-text-muted)" }}>FAMILY ACCESS</p>
          <p className="text-sm leading-relaxed" style={{ color: "var(--vp-text-soft)" }}>
            Create a private, expiring family access token and revoke it at any time.
          </p>
          <Link href="/family" className="mt-3 inline-flex min-h-11 items-center rounded-lg px-4 text-sm font-semibold" style={{ background: "var(--vp-accent)", color: "var(--vp-accent-ink)" }}>
            Manage family access
          </Link>
        </div>

        <div className="p-4 rounded-2xl" style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}>
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-medium" style={{ color: "var(--vp-text-muted)" }}>FAMILY CONTACTS</p>
            {editing && (
              <button onClick={addContact} className="min-h-11 text-xs" style={{ color: "var(--vp-accent-bright)" }}>+ Add</button>
            )}
          </div>
          {contacts.length === 0 && (
            <p className="text-sm" style={{ color: "var(--vp-text-muted)" }}>No contacts added yet</p>
          )}
          <div className="space-y-2">
            {contacts.map((c, idx) => (
              <div key={c.id} className="flex items-center gap-2">
                {editing ? (
                  <>
                    <input
                      aria-label={`Contact ${idx + 1} name`}
                      value={c.name}
                      onChange={e => updateContact(c.id, "name", e.target.value)}
                      placeholder="Name"
                      className="flex-1 px-2 py-1.5 rounded-lg text-xs outline-none"
                      style={{ background: "var(--vp-input)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
                    />
                    <input
                      aria-label={`Contact ${idx + 1} phone`}
                      type="tel"
                      inputMode="tel"
                      value={c.phone}
                      onChange={e => updateContact(c.id, "phone", e.target.value)}
                      placeholder="Phone"
                      className="flex-1 px-2 py-1.5 rounded-lg text-xs outline-none"
                      style={{ background: "var(--vp-input)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
                    />
                    <button type="button" onClick={() => removeContact(c.id)} className="min-h-11 min-w-11 text-xs" style={{ color: "var(--vp-danger)" }} aria-label={`Remove ${c.name || `contact ${idx + 1}`}`}>Remove</button>
                  </>
                ) : (
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold"
                      style={{ background: "var(--vp-accent)", color: "var(--vp-accent-ink)" }}>
                      {c.name?.[0]?.toUpperCase() || String(idx + 1)}
                    </div>
                    <div>
                        <p className="text-sm" style={{ color: "var(--vp-text-soft)" }}>{c.name}</p>
                        <p className="text-xs" style={{ color: "var(--vp-text-muted)" }}>{c.phone}</p>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <button
          type="button"
          onClick={async () => {
            const confirmed = window.confirm("Delete your saved profile, family contacts, location, active share tokens and SOS records? This cannot be undone.");
            if (!confirmed) return;
            try {
              await clearUser();
            } catch (cause) {
              setError(cause instanceof Error ? cause.message : "Your profile could not be deleted.");
            }
          }}
          className="w-full min-h-12 py-3 rounded-xl text-sm"
          style={{ background: "var(--vp-danger-surface)", border: "1px solid var(--vp-danger-border)", color: "var(--vp-danger)" }}
        >
          Delete profile and saved data
        </button>
      </div>
      <div className="h-8" />
    </main>
  );
}
