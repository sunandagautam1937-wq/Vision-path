import { useCallback, useEffect, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useUser } from "@/contexts/UserContext";

interface LiveLocation {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
}

interface SOSAlert {
  userName: string;
  lat: number | null;
  lng: number | null;
  timestamp: number;
  message: string;
  deliveryStatus: "recorded";
}

interface ShareMetadata {
  id: string;
  label: string;
  createdAt: string;
  expiresAt: string;
  revokedAt: string | null;
}

interface SharedData {
  userName: string;
  location: LiveLocation | null;
  sos: SOSAlert | null;
}

const panelStyle = { background: "var(--vp-surface)", border: "1px solid var(--vp-border)" };

export default function FamilyTracker() {
  const { user } = useUser();
  const [tokenInput, setTokenInput] = useState(() => {
    try {
      return new URLSearchParams(window.location.hash.replace(/^#/, "")).get("access") ?? "";
    } catch {
      return "";
    }
  });
  const [issuedToken, setIssuedToken] = useState<string | null>(null);
  const [shares, setShares] = useState<ShareMetadata[]>([]);
  const [sharedData, setSharedData] = useState<SharedData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [shareError, setShareError] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [tracking, setTracking] = useState(false);
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.CircleMarker | null>(null);
  const pollTimerRef = useRef<number | null>(null);
  const pollControllerRef = useRef<AbortController | null>(null);

  const renderMap = useCallback((location: LiveLocation) => {
    if (!mapRef.current) return;
    if (!mapInstanceRef.current) {
      mapInstanceRef.current = L.map(mapRef.current, { zoomControl: true }).setView(
        [location.lat, location.lng],
        17,
      );
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors",
        maxZoom: 19,
      }).addTo(mapInstanceRef.current);
    }
    if (markerRef.current) {
      markerRef.current.setLatLng([location.lat, location.lng]);
    } else {
      markerRef.current = L.circleMarker([location.lat, location.lng], {
        radius: 9,
        color: "#1a261e",
        weight: 3,
        fillColor: "#cbd9b4",
        fillOpacity: 1,
      }).addTo(mapInstanceRef.current);
    }
    mapInstanceRef.current.setView([location.lat, location.lng], 17);
  }, []);

  const refreshShares = useCallback(async (signal?: AbortSignal) => {
    if (!user) return;
    const response = await fetch("/api/visionpath/shares", {
      credentials: "same-origin",
      signal,
    });
    if (!response.ok) throw new Error("Family access settings could not be loaded.");
    const result = await response.json() as { shares: ShareMetadata[] };
    setShares(result.shares);
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const controller = new AbortController();
    void refreshShares(controller.signal).catch(() => {
      if (!controller.signal.aborted) setShareError("Family access settings could not be loaded.");
    });
    return () => controller.abort();
  }, [user, refreshShares]);

  useEffect(() => () => {
    if (pollTimerRef.current !== null) window.clearTimeout(pollTimerRef.current);
    pollControllerRef.current?.abort();
    mapInstanceRef.current?.remove();
    mapInstanceRef.current = null;
    markerRef.current = null;
  }, []);

  async function createShare() {
    setShareError(null);
    setStatus(null);
    try {
      const response = await fetch("/api/visionpath/shares", {
        method: "POST",
        credentials: "same-origin",
      });
      const result = await response.json() as ShareMetadata & { token?: string; error?: string };
      if (!response.ok || !result.token) {
        throw new Error(result.error || "A family access token could not be created.");
      }
      setIssuedToken(result.token);
      setStatus("Access link created. Anyone with it can view your latest shared location and recent SOS record; it expires in 30 days and can be revoked.");
      await refreshShares();
    } catch (cause) {
      setShareError(cause instanceof Error ? cause.message : "A family access token could not be created.");
    }
  }

  async function copyIssuedToken() {
    if (!issuedToken) return;
    try {
      await navigator.clipboard.writeText(issuedToken);
      setStatus("Access token copied.");
    } catch {
      setShareError("Copy was blocked. Select and copy the token text manually.");
    }
  }

  async function copyIssuedLink() {
    if (!issuedToken) return;
    const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");
    const shareUrl = `${window.location.origin}${basePath}/family-view#access=${encodeURIComponent(issuedToken)}`;
    try {
      await navigator.clipboard.writeText(shareUrl);
      setStatus("Family access link copied. The recipient must open it and choose Track location.");
    } catch {
      setShareError("Copy was blocked. Select and copy the access link manually.");
    }
  }

  async function revokeShare(shareId: string) {
    if (!window.confirm("Revoke this family access token? Anyone using it will immediately lose access.")) return;
    setShareError(null);
    try {
      const response = await fetch(`/api/visionpath/shares/${encodeURIComponent(shareId)}`, {
        method: "DELETE",
        credentials: "same-origin",
      });
      if (!response.ok) throw new Error("This access token could not be revoked.");
      setShares((current) => current.map((share) =>
        share.id === shareId ? { ...share, revokedAt: new Date().toISOString() } : share,
      ));
      setStatus("Family access revoked.");
    } catch (cause) {
      setShareError(cause instanceof Error ? cause.message : "This access token could not be revoked.");
    }
  }

  function stopTracking() {
    if (pollTimerRef.current !== null) window.clearTimeout(pollTimerRef.current);
    pollTimerRef.current = null;
    pollControllerRef.current?.abort();
    pollControllerRef.current = null;
    setTracking(false);
    setSharedData(null);
    setError(null);
    mapInstanceRef.current?.remove();
    mapInstanceRef.current = null;
    markerRef.current = null;
  }

  function startTracking() {
    const token = tokenInput.trim();
    if (!/^[A-Za-z0-9_-]{40,64}$/.test(token)) {
      setError("Enter the complete family access token.");
      return;
    }
    stopTracking();
    // The capability is read locally, then removed from browser history/address bar.
    window.history.replaceState(null, "", `${window.location.pathname}${window.location.search}`);
    const controller = new AbortController();
    pollControllerRef.current = controller;
    setTracking(true);

    const poll = async () => {
      if (controller.signal.aborted) return;
      try {
        const response = await fetch("/api/visionpath/shared/current", {
          headers: { Authorization: `Bearer ${token}` },
          signal: controller.signal,
        });
        if (response.status === 401) {
          setError("This access token is invalid, expired or revoked.");
          setTracking(false);
          return;
        }
        if (!response.ok) throw new Error("Family location is temporarily unavailable.");
        const data = await response.json() as SharedData;
        setSharedData(data);
        setError(data.location ? null : "No location is available yet. The owner must open VisionPath and allow location access.");
        if (data.location) renderMap(data.location);
      } catch {
        if (!controller.signal.aborted) {
          setError("Could not refresh family location. Check the internet connection; retrying.");
        }
      }
      if (!controller.signal.aborted) {
        pollTimerRef.current = window.setTimeout(() => void poll(), 5_000);
      }
    };
    setError(null);
    void poll();
  }

  function getTimeAgo(timestamp: number): string {
    const seconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
    if (seconds < 10) return "Just now";
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    return `${Math.floor(seconds / 3600)}h ago`;
  }

  const activeShares = shares.filter((share) =>
    !share.revokedAt && new Date(share.expiresAt).getTime() > Date.now(),
  );

  return (
    <main className="min-h-screen flex flex-col pb-6" style={{ background: "var(--vp-page)", color: "var(--vp-text)" }}>
      <header className="px-4 pt-4 pb-2">
        <h1 className="text-lg font-semibold" style={{ color: "var(--vp-accent-bright)" }}>Family Tracker</h1>
        <p className="text-xs" style={{ color: "var(--vp-text-muted)" }}>Read-only access to a shared location and recent SOS record.</p>
      </header>

      {user && (
        <section className="mx-4 mt-3 rounded-xl p-4" style={panelStyle} aria-labelledby="family-share-heading">
          <h2 id="family-share-heading" className="text-sm font-semibold" style={{ color: "var(--vp-accent-bright)" }}>
            Manage family access
          </h2>
          <p className="mt-2 text-xs leading-relaxed" style={{ color: "var(--vp-text-soft)" }}>
            Anyone with an active token can view your latest shared location and a recent SOS record. Tokens expire after 30 days and can be revoked here.
          </p>
          <button
            type="button"
            onClick={() => void createShare()}
            className="mt-3 min-h-12 w-full rounded-xl px-4 py-3 text-sm font-semibold"
            style={{ background: "var(--vp-accent)", color: "var(--vp-accent-ink)" }}
          >
            Create family access token
          </button>
          {issuedToken && (
            <div className="mt-3 rounded-xl p-3" style={{ background: "var(--vp-input)", border: "1px solid var(--vp-border)" }}>
              <label htmlFor="new-share-token" className="block text-xs font-medium" style={{ color: "var(--vp-text-soft)" }}>
                New token — copy and share it now
              </label>
              <textarea
                id="new-share-token"
                value={issuedToken}
                readOnly
                rows={3}
                className="mt-2 w-full break-all rounded-lg p-2 text-sm"
                style={{ background: "var(--vp-surface-raised)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
              />
              <button
                type="button"
                onClick={() => void copyIssuedToken()}
                className="mt-2 min-h-11 rounded-lg px-4 text-sm font-semibold"
                style={{ background: "var(--vp-success-surface)", color: "var(--vp-success)" }}
              >
                Copy token
              </button>
              <button
                type="button"
                onClick={() => void copyIssuedLink()}
                className="ml-2 mt-2 min-h-11 rounded-lg px-4 text-sm font-semibold"
                style={{ background: "var(--vp-success-surface)", color: "var(--vp-success)" }}
              >
                Copy access link
              </button>
            </div>
          )}
          {activeShares.length > 0 && (
            <ul className="mt-3 space-y-2" aria-label="Active family access tokens">
              {activeShares.map((share) => (
                <li key={share.id} className="flex items-center justify-between gap-3 rounded-lg p-3" style={{ background: "var(--vp-input)" }}>
                  <span className="text-xs">
                    Expires {new Date(share.expiresAt).toLocaleDateString()}
                  </span>
                  <button
                    type="button"
                    onClick={() => void revokeShare(share.id)}
                    className="min-h-10 rounded-lg px-3 text-xs font-semibold"
                    style={{ background: "var(--vp-danger-surface)", border: "1px solid var(--vp-danger-border)", color: "var(--vp-danger)" }}
                    aria-label={`Revoke family access token expiring ${new Date(share.expiresAt).toLocaleDateString()}`}
                  >
                    Revoke
                  </button>
                </li>
              ))}
            </ul>
          )}
          {shareError && <p className="mt-2 text-sm text-red-300" role="alert">{shareError}</p>}
          {status && <p className="mt-2 text-sm" style={{ color: "var(--vp-success)" }} role="status" aria-live="polite">{status}</p>}
        </section>
      )}

      <section className="mx-4 mt-4 rounded-xl p-4" style={panelStyle} aria-labelledby="track-share-heading">
        <h2 id="track-share-heading" className="text-sm font-semibold" style={{ color: "var(--vp-accent-bright)" }}>
          Track a family member
        </h2>
        <p className="mt-2 text-xs leading-relaxed" style={{ color: "var(--vp-text-soft)" }}>
          Enter the access token they shared with you. The token is private; do not post it publicly.
        </p>
        <label htmlFor="family-access-token" className="mt-3 block text-sm font-medium" style={{ color: "var(--vp-text-soft)" }}>
          Family access token
        </label>
        <textarea
          id="family-access-token"
          value={tokenInput}
          onChange={(event) => setTokenInput(event.target.value)}
          autoComplete="off"
          spellCheck={false}
          rows={2}
          className="mt-2 w-full rounded-xl p-3 text-sm"
          style={{ background: "var(--vp-input)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
          aria-describedby="family-token-help"
        />
        <p id="family-token-help" className="mt-1 text-xs" style={{ color: "var(--vp-text-muted)" }}>
          Tokens are stored as hashes on the server. Access stops at expiry or when the owner revokes it.
        </p>
        <div className="mt-3 flex gap-2">
          <button
            type="button"
            onClick={startTracking}
            disabled={tracking}
            className="min-h-12 flex-1 rounded-xl px-4 font-semibold disabled:opacity-50"
            style={{ background: "var(--vp-accent)", color: "var(--vp-accent-ink)" }}
          >
            {tracking ? "Tracking" : "Track location"}
          </button>
          {tracking && (
            <button
              type="button"
              onClick={stopTracking}
              className="min-h-12 rounded-xl px-4 font-semibold"
              style={{ background: "var(--vp-danger-surface)", border: "1px solid var(--vp-danger-border)", color: "var(--vp-danger)" }}
            >
              Stop
            </button>
          )}
        </div>
      </section>

      {error && <p className="mx-4 mt-3 rounded-xl p-3 text-sm" style={{ background: "var(--vp-danger-surface)", color: "var(--vp-danger)" }} role="alert">{error}</p>}

      {sharedData?.sos && (
        <section className="mx-4 mt-3 rounded-xl p-3" style={{ background: "var(--vp-danger-surface)", border: "2px solid var(--vp-danger-border)" }} aria-labelledby="sos-alert-heading">
          <h2 id="sos-alert-heading" className="text-sm font-bold" style={{ color: "var(--vp-danger)" }}>Recent SOS record from {sharedData.sos.userName}</h2>
          <p className="mt-1 text-xs" style={{ color: "var(--vp-danger)" }}>{getTimeAgo(sharedData.sos.timestamp)} · recorded by VisionPath</p>
          <p className="mt-2 whitespace-pre-wrap text-sm" style={{ color: "var(--vp-text)" }}>{sharedData.sos.message}</p>
          {sharedData.sos.lat !== null && sharedData.sos.lng !== null && (
            <a
              href={`https://maps.google.com/?q=${sharedData.sos.lat},${sharedData.sos.lng}`}
              target="_blank"
              rel="noreferrer"
              className="mt-2 inline-block min-h-11 rounded-lg px-3 py-2 text-sm font-semibold"
              style={{ background: "var(--vp-danger)", color: "var(--vp-accent-ink)" }}
            >
              Open SOS location in maps
            </a>
          )}
          <p className="mt-2 text-xs" style={{ color: "var(--vp-text-soft)" }}>A record in VisionPath does not confirm that an SMS or WhatsApp message was delivered.</p>
        </section>
      )}

      {sharedData?.location && (
        <section className="mx-4 mt-3 rounded-xl p-3" style={{ background: "var(--vp-success-surface)", border: "1px solid var(--vp-border)" }}>
          <h2 className="text-sm font-semibold" style={{ color: "var(--vp-accent-bright)" }}>{sharedData.userName}</h2>
          <p className="mt-1 text-xs" style={{ color: "var(--vp-text-muted)" }}>
            Updated {getTimeAgo(sharedData.location.timestamp)} · accuracy ±{Math.round(sharedData.location.accuracy)}m
          </p>
          <p className="mt-1 text-xs" style={{ color: "var(--vp-text-muted)" }}>
            {sharedData.location.lat.toFixed(5)}, {sharedData.location.lng.toFixed(5)}
          </p>
          <a
            href={`https://maps.google.com/?q=${sharedData.location.lat},${sharedData.location.lng}`}
            target="_blank"
            rel="noreferrer"
            className="mt-2 inline-block min-h-11 rounded-lg px-3 py-2 text-sm font-semibold"
            style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)", color: "var(--vp-accent-bright)" }}
          >
            Open in Google Maps
          </a>
        </section>
      )}

      <div
        ref={mapRef}
        className="mx-4 mt-3 flex-1 overflow-hidden rounded-2xl"
        style={{ minHeight: "280px", border: "1px solid var(--vp-border)" }}
        role="img"
        aria-label={sharedData?.location ? `Map showing ${sharedData.userName}'s shared location` : "Map appears when a valid shared location is available"}
      />
    </main>
  );
}
