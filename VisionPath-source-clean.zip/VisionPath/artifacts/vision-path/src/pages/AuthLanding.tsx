import CaneLogo from "@/components/CaneLogo";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useUser } from "@/contexts/UserContext";
import { languageInfo, SUPPORTED_LANGUAGES, translate } from "@/utils/translations";
import { speak, stopSpeaking } from "@/utils/speech";

export default function AuthLanding() {
  const { language, setLanguage, voiceAvailability } = useUser();
  const [languageMessage, setLanguageMessage] = useState("");

  useEffect(() => {
    if (!languageMessage) return;
    const timer = window.setTimeout(() => setLanguageMessage(""), 4_000);
    return () => window.clearTimeout(timer);
  }, [languageMessage]);

  return (
    <main
      className="min-h-screen flex flex-col items-center justify-center px-6 pt-16 pb-32"
      aria-labelledby="visionpath-welcome-title"
      style={{ background: "radial-gradient(circle at 50% 0%, #25372c 0%, var(--vp-page) 60%)" }}
    >
      <div className="w-full max-w-sm text-center">
        <div
          className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-[1.65rem] border shadow-lg"
          style={{ background: "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))", borderColor: "var(--vp-border-strong)", boxShadow: "0 12px 32px rgba(8, 18, 11, .34)" }}
        >
          <CaneLogo size={52} />
        </div>
        <h1 id="visionpath-welcome-title" className="text-4xl font-bold tracking-tight" style={{ color: "var(--vp-accent-bright)" }}>VisionPath</h1>
        <p className="mb-6 mt-2 text-xs tracking-[0.22em] uppercase" style={{ color: "var(--vp-text-muted)" }}>A calmer way forward</p>
        <p className="mb-8 text-base leading-relaxed" style={{ color: "var(--vp-text-soft)" }}>
          Step-by-step pedestrian guidance, voice directions, and family location sharing.
        </p>

        <section className="mb-5 rounded-3xl p-4 text-left shadow-lg" style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)", boxShadow: "0 12px 30px rgba(0, 0, 0, .18)" }}>
          <label htmlFor="landing-language" className="mb-2 block text-sm font-semibold" style={{ color: "var(--vp-accent-bright)" }}>
            {translate(language, "languageSelectorLabel")}
          </label>
          <select
            id="landing-language"
            value={language}
            onChange={(event) => {
              const nextLanguage = event.target.value as typeof language;
              setLanguage(nextLanguage);
              setLanguageMessage(translate(nextLanguage, "languageSelected", {
                language: languageInfo(nextLanguage).name,
              }));
            }}
            className="min-h-14 w-full rounded-xl px-3 py-3 text-base font-semibold"
            style={{ background: "var(--vp-input)", border: "2px solid var(--vp-border-strong)", color: "var(--vp-text)" }}
            aria-describedby="landing-voice-status landing-accessibility"
          >
            {SUPPORTED_LANGUAGES.map((item) => (
              <option key={item.code} value={item.code}>{item.name}</option>
            ))}
          </select>
          <p id="landing-voice-status" role="status" aria-live="polite" className="mt-2 text-xs leading-relaxed" style={{ color: "var(--vp-text-muted)" }}>
            {languageMessage
              || (voiceAvailability === "available" && translate(language, "voiceAvailable", { language: languageInfo(language).name }))
              || (voiceAvailability === "checking" && translate(language, "voiceChecking", { language: languageInfo(language).name }))
              || (voiceAvailability === "unavailable" && translate(language, "voiceUnavailable", { language: languageInfo(language).name }))
              || (voiceAvailability === "unsupported" && translate(language, "speechUnsupported"))
              || (voiceAvailability === "error" && translate(language, "speechError"))}
          </p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                speak(translate(language, "languageSelected", { language: languageInfo(language).name }), {
                  priority: "critical",
                  language,
                  fallbackToSystemVoice: true,
                });
                setLanguageMessage("Voice test requested. If silent, check Android Text-to-speech and media volume.");
              }}
              className="min-h-12 rounded-xl px-3 py-2 text-sm font-semibold"
              style={{ background: "var(--vp-surface-raised)", border: "1px solid var(--vp-border-strong)", color: "var(--vp-accent-bright)" }}
            >
              Test voice
            </button>
            <button
              type="button"
              onClick={() => {
                stopSpeaking();
                setLanguageMessage("Speech stopped.");
              }}
              className="min-h-12 rounded-xl px-3 py-2 text-sm font-semibold"
              style={{ background: "var(--vp-surface-raised)", border: "1px solid var(--vp-border-strong)", color: "var(--vp-accent-bright)" }}
            >
              Stop voice
            </button>
          </div>
          {voiceAvailability === "unavailable" && language !== "en" && (
            <button
              type="button"
              onClick={() => {
                setLanguage("en");
                setLanguageMessage(translate("en", "languageSelected", { language: languageInfo("en").name }));
                speak(translate("en", "languageSelected", { language: languageInfo("en").name }), {
                  priority: "critical", language: "en", fallbackToSystemVoice: true,
                });
              }}
              className="mt-3 min-h-12 w-full rounded-xl px-3 py-2 text-sm font-semibold"
              style={{ background: "var(--vp-accent)", color: "var(--vp-accent-ink)" }}
            >
              Use English voice
            </button>
          )}
          <p id="landing-accessibility" className="mt-3 border-t pt-3 text-xs leading-relaxed" style={{ borderColor: "var(--vp-border)", color: "var(--vp-text-muted)" }}>
            Works with Android TalkBack. Use Read screen for separate in-app narration.
          </p>
        </section>

        <Link
          href="/sign-up"
          className="block min-h-14 w-full rounded-2xl py-4 text-lg font-semibold shadow-md"
          style={{ background: "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))", color: "var(--vp-accent-ink)" }}
        >
          Create account
        </Link>
        <Link
          href="/sign-in"
          className="mt-3 block min-h-14 w-full rounded-2xl border py-4 text-base font-semibold"
          style={{ background: "var(--vp-surface)", borderColor: "var(--vp-border)", color: "var(--vp-accent-bright)" }}
        >
          Sign in
        </Link>
        <p className="mt-4 text-xs leading-relaxed" style={{ color: "var(--vp-text-muted)" }}>
          Location sharing and saved profile data require an account. You control family access and can revoke it.
        </p>
      </div>
    </main>
  );
}
