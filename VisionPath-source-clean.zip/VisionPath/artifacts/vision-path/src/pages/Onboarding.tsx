import CaneLogo from "@/components/CaneLogo";
import { useState } from "react";
import { useUser } from "@/contexts/UserContext";
import { UK_SHOE_SIZES } from "@/utils/stepCalculator";
import { speak } from "@/utils/speech";
import { languageInfo, SUPPORTED_LANGUAGES, translate } from "@/utils/translations";

const ukSizes = Object.keys(UK_SHOE_SIZES).map(Number).sort((a, b) => a - b);

export default function Onboarding() {
  const { setUser, language, setLanguage, voiceAvailability } = useUser();
  const [step, setStep] = useState<"welcome" | "profile" | "contacts">("welcome");
  const [name, setName] = useState("");
  const [heightCm, setHeightCm] = useState("");
  const [ukShoeSize, setUkShoeSize] = useState("8");
  const [contacts, setContacts] = useState([{ id: "1", name: "", phone: "" }]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  function validateProfile() {
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = "Name is required";
    const h = parseFloat(heightCm);
    if (isNaN(h) || h < 50 || h > 250) errs.height = "Enter a valid height between 50 and 250 cm";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function addContact() {
    setContacts(prev => [...prev, { id: Date.now().toString(), name: "", phone: "" }]);
  }

  function updateContact(id: string, field: "name" | "phone", value: string) {
    setContacts(prev => prev.map(c => c.id === id ? { ...c, [field]: value } : c));
  }

  function removeContact(id: string) {
    setContacts(prev => prev.filter(c => c.id !== id));
  }

  async function handleSubmit(skipContacts = false) {
    if (!validateProfile()) {
      setStep("profile");
      return;
    }
    const suppliedContacts = skipContacts ? [] : contacts.filter(c => c.name.trim() || c.phone.trim());
    if (suppliedContacts.length > 10 || suppliedContacts.some((contact) =>
      !contact.name.trim() || !/^[+0-9() .-]{7,24}$/.test(contact.phone.trim()),
    )) {
      setErrors((current) => ({ ...current, contacts: "Each contact needs a name and a valid phone number." }));
      return;
    }
    setErrors({});
    setSaveError(null);
    setSaving(true);
    try {
      await setUser({
        name: name.trim(),
        heightCm: parseFloat(heightCm),
        ukShoeSize: parseFloat(ukShoeSize),
        familyContacts: suppliedContacts.map(contact => ({
          ...contact,
          name: contact.name.trim(),
          phone: contact.phone.trim(),
        })),
      });
    } catch (cause) {
      setSaveError(cause instanceof Error ? cause.message : "Your profile could not be saved. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  if (step === "welcome") {
    return (
      <main className="min-h-screen flex flex-col items-center justify-center px-6 pt-12 pb-32" style={{ background: "radial-gradient(circle at 50% 0%, #25372c 0%, var(--vp-page) 60%)" }}>
        <div className="w-full max-w-sm text-center">
          <div className="mb-8 flex justify-center">
            <div className="w-20 h-20 rounded-[1.65rem] flex items-center justify-center border shadow-lg" style={{ background: "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))", borderColor: "var(--vp-border-strong)" }}>
              <CaneLogo size={52} />
            </div>
          </div>
          <h1 className="text-4xl font-bold mb-2" style={{ color: "var(--vp-accent-bright)" }}>VisionPath</h1>
          <p className="text-xs uppercase tracking-[0.22em] mb-8" style={{ color: "var(--vp-text-muted)" }}>A calmer way forward</p>
          <p className="mb-8 text-base leading-relaxed" style={{ color: "var(--vp-text-soft)" }}>
            Your intelligent navigation companion. Step-by-step guidance tailored to your stride.
          </p>
          <div className="mb-6 rounded-3xl p-4 text-left" style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}>
            <label htmlFor="onboarding-language" className="mb-2 block text-sm font-semibold" style={{ color: "var(--vp-accent-bright)" }}>
              {translate(language, "languageSelectorLabel")}
            </label>
            <select
              id="onboarding-language"
              value={language}
              onChange={(event) => {
                const nextLanguage = event.target.value as typeof language;
                setLanguage(nextLanguage);
                speak(
                  translate(nextLanguage, "languageSelected", { language: languageInfo(nextLanguage).name }),
                  { priority: "critical", language: nextLanguage },
                );
              }}
              className="min-h-14 w-full rounded-xl px-3 py-3 text-base font-semibold"
              style={{ background: "var(--vp-input)", border: "2px solid var(--vp-border-strong)", color: "var(--vp-text)" }}
              aria-describedby="onboarding-voice-status"
            >
              {SUPPORTED_LANGUAGES.map((item) => (
                <option key={item.code} value={item.code}>{item.name}</option>
              ))}
            </select>
            <p id="onboarding-voice-status" role="status" aria-live="polite" className="mt-2 text-xs leading-relaxed" style={{ color: "var(--vp-text-muted)" }}>
              {voiceAvailability === "available" && translate(language, "voiceAvailable", { language: languageInfo(language).name })}
              {voiceAvailability === "checking" && translate(language, "voiceChecking", { language: languageInfo(language).name })}
              {voiceAvailability === "unavailable" && translate(language, "voiceUnavailable", { language: languageInfo(language).name })}
              {voiceAvailability === "unsupported" && translate(language, "speechUnsupported")}
              {voiceAvailability === "error" && translate(language, "speechError")}
            </p>
            {voiceAvailability === "unavailable" && language !== "en" && (
              <button
                type="button"
                onClick={() => {
                  setLanguage("en");
                  speak(translate("en", "languageSelected", { language: languageInfo("en").name }), { priority: "critical", language: "en" });
                }}
                className="mt-3 min-h-12 w-full rounded-xl px-4 py-3 text-base font-semibold"
                style={{ background: "var(--vp-accent)", color: "var(--vp-accent-ink)" }}
              >
                Use English voice
              </button>
            )}
          </div>
          <button
            onClick={() => setStep("profile")}
            className="w-full min-h-14 py-4 rounded-2xl font-semibold text-lg transition-all active:scale-[0.99]"
            style={{ background: "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))", color: "var(--vp-accent-ink)" }}
          >
            Get Started
          </button>
        </div>
      </main>
    );
  }

  if (step === "profile") {
    return (
      <div className="min-h-screen flex flex-col px-6 pt-10 pb-32" style={{ background: "var(--vp-page)" }}>
        <div className="w-full max-w-sm mx-auto">
          <button onClick={() => setStep("welcome")} className="mb-6 min-h-11 text-sm" style={{ color: "var(--vp-text-muted)" }}>
            ← Back
          </button>
          <h2 className="text-2xl font-bold mb-2" style={{ color: "var(--vp-accent-bright)" }}>Your Profile</h2>
          <p className="text-sm mb-8" style={{ color: "var(--vp-text-muted)" }}>We'll use this to calculate your exact step size</p>

          <div className="space-y-6">
            <div>
              <label htmlFor="onboarding-name" className="block text-sm font-medium mb-2" style={{ color: "var(--vp-text-soft)" }}>Full Name</label>
              <input
                id="onboarding-name"
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Enter your name"
                autoComplete="name"
                maxLength={80}
                required
                aria-invalid={!!errors.name}
                aria-describedby={errors.name ? "onboarding-name-error" : undefined}
                className="w-full px-4 py-3 rounded-xl text-base outline-none"
                style={{ background: "var(--vp-input)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
              />
              {errors.name && <p id="onboarding-name-error" className="mt-1 text-sm text-red-300" role="alert">{errors.name}</p>}
            </div>

            <div>
              <label htmlFor="onboarding-height" className="block text-sm font-medium mb-2" style={{ color: "var(--vp-text-soft)" }}>Height (cm)</label>
              <input
                id="onboarding-height"
                type="number"
                value={heightCm}
                onChange={e => setHeightCm(e.target.value)}
                placeholder="e.g. 170"
                min="50"
                max="250"
                required
                aria-invalid={!!errors.height}
                aria-describedby={errors.height ? "onboarding-height-error" : undefined}
                className="w-full px-4 py-3 rounded-xl text-base outline-none"
                style={{ background: "var(--vp-input)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
              />
              {errors.height && <p id="onboarding-height-error" className="mt-1 text-sm text-red-300" role="alert">{errors.height}</p>}
            </div>

            <div>
              <label htmlFor="onboarding-shoe-size" className="block text-sm font-medium mb-2" style={{ color: "var(--vp-text-soft)" }}>
                Shoe Size (UK / India)
              </label>
              <select
                id="onboarding-shoe-size"
                value={ukShoeSize}
                onChange={e => setUkShoeSize(e.target.value)}
                className="w-full px-4 py-3 rounded-xl text-base outline-none"
                style={{ background: "var(--vp-input)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
              >
                {ukSizes.map(size => (
                  <option key={size} value={size}>UK {size} / India {size}</option>
                ))}
              </select>
              <p className="mt-1 text-xs" style={{ color: "var(--vp-text-muted)" }}>UK and Indian shoe sizes are equivalent</p>
            </div>
          </div>

          <button
            onClick={() => { if (validateProfile()) setStep("contacts"); }}
            className="w-full mt-10 min-h-14 py-4 rounded-2xl font-semibold text-lg transition-all active:scale-[0.99]"
            style={{ background: "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))", color: "var(--vp-accent-ink)" }}
          >
            Next: Add Family Contacts
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col px-6 pt-10 pb-32" style={{ background: "var(--vp-page)" }}>
      <div className="w-full max-w-sm mx-auto">
        <button onClick={() => setStep("profile")} className="mb-6 min-h-11 text-sm" style={{ color: "var(--vp-text-muted)" }}>
          ← Back
        </button>
        <h2 className="text-2xl font-bold mb-2" style={{ color: "var(--vp-accent-bright)" }}>Family Contacts</h2>
        <p className="text-sm mb-8" style={{ color: "var(--vp-text-muted)" }}>Add family members you can contact manually during an emergency. VisionPath does not send SOS messages automatically.</p>

        <div className="space-y-4">
          {contacts.map((contact, idx) => (
              <div key={contact.id} className="p-4 rounded-2xl" style={{ background: "var(--vp-surface)", border: "1px solid var(--vp-border)" }}>
              <div className="flex justify-between items-center mb-3">
                <span className="text-sm font-medium" style={{ color: "var(--vp-accent-bright)" }}>Contact {idx + 1}</span>
                {contacts.length > 1 && (
                <button type="button" onClick={() => removeContact(contact.id)} className="min-h-11 px-3 text-sm" style={{ color: "var(--vp-danger)" }} aria-label={`Remove contact ${idx + 1}`}>Remove</button>
                )}
              </div>
              <label htmlFor={`contact-name-${contact.id}`} className="sr-only">Contact {idx + 1} name</label>
              <input
                id={`contact-name-${contact.id}`}
                type="text"
                value={contact.name}
                onChange={e => updateContact(contact.id, "name", e.target.value)}
                placeholder="Contact name"
                className="w-full px-3 py-2 rounded-lg text-sm mb-2 outline-none"
                style={{ background: "var(--vp-input)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
              />
              <label htmlFor={`contact-phone-${contact.id}`} className="sr-only">Contact {idx + 1} phone number</label>
              <input
                id={`contact-phone-${contact.id}`}
                type="tel"
                inputMode="tel"
                value={contact.phone}
                onChange={e => updateContact(contact.id, "phone", e.target.value)}
                placeholder="Phone number"
                className="w-full px-3 py-2 rounded-lg text-sm outline-none"
                style={{ background: "var(--vp-input)", border: "1px solid var(--vp-border)", color: "var(--vp-text)" }}
              />
            </div>
          ))}
        </div>
        {errors.contacts && <p className="mt-3 text-sm" style={{ color: "var(--vp-danger)" }} role="alert">{errors.contacts}</p>}
        {saveError && <p className="mt-3 text-sm" style={{ color: "var(--vp-danger)" }} role="alert">{saveError}</p>}

        <button
          onClick={addContact}
          className="w-full mt-4 py-3 rounded-xl text-sm font-medium"
          style={{ border: "1px dashed var(--vp-border-strong)", color: "var(--vp-text-muted)", background: "transparent" }}
        >
          + Add Another Contact
        </button>

        <button
          onClick={() => void handleSubmit()}
          disabled={saving}
          className="w-full mt-6 py-4 rounded-2xl font-semibold text-lg transition-all active:scale-95"
          style={{ background: "linear-gradient(135deg, var(--vp-accent), var(--vp-accent-bright))", color: "var(--vp-accent-ink)" }}
        >
          {saving ? "Saving profile…" : "Start Using VisionPath"}
        </button>

        <button
          onClick={() => void handleSubmit(true)}
          disabled={saving}
          className="w-full mt-3 py-3 text-sm"
          style={{ color: "var(--vp-text-muted)", background: "transparent", border: "none" }}
        >
          Skip contacts for now
        </button>
      </div>
    </div>
  );
}
