import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { useAuth } from "@clerk/react";
import { calculateStepLength, getFootLengthCm } from "@/utils/stepCalculator";
import {
  getVoiceAvailability,
  setSpeechLanguage,
  speak,
  subscribeSpeechStatus,
  type VoiceAvailability,
} from "@/utils/speech";
import { gpsErrorMessage, languageInfo, normalizeLanguage, type LanguageCode } from "@/utils/translations";

export interface FamilyContact {
  id: string;
  name: string;
  phone: string;
}

export interface UserProfile {
  name: string;
  heightCm: number;
  ukShoeSize: number;
  stepLengthM: number;
  familyContacts: FamilyContact[];
}

export interface LocationData {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
}

interface UserContextType {
  user: UserProfile | null;
  profileLoading: boolean;
  profileError: string | null;
  retryProfileLoad: () => void;
  setUser: (profile: Omit<UserProfile, "stepLengthM">) => Promise<void>;
  location: LocationData | null;
  locationError: string | null;
  locationSyncError: string | null;
  startTracking: () => void;
  stopTracking: () => void;
  isTracking: boolean;
  clearUser: () => Promise<void>;
  language: LanguageCode;
  setLanguage: (language: LanguageCode) => void;
  voiceAvailability: VoiceAvailability;
}

const UserContext = createContext<UserContextType | null>(null);
const LEGACY_PROFILE_KEY = "visionpath_user";
const LANGUAGE_STORAGE_KEY = "visionpath_language";

function isValidLegacyProfile(value: unknown): value is {
  name: string;
  heightCm: number;
  ukShoeSize: number;
  familyContacts?: unknown;
} {
  if (!value || typeof value !== "object") return false;
  const profile = value as Record<string, unknown>;
  return typeof profile.name === "string"
    && profile.name.trim().length > 0
    && Number.isFinite(profile.heightCm)
    && Number(profile.heightCm) >= 50
    && Number(profile.heightCm) <= 250
    && Number.isFinite(profile.ukShoeSize)
    && Number(profile.ukShoeSize) >= 1
    && Number(profile.ukShoeSize) <= 15;
}

function legacyProfileForUpload(value: unknown): Omit<UserProfile, "stepLengthM"> | null {
  if (!isValidLegacyProfile(value)) return null;
  const profile = value as {
    name: string;
    heightCm: number;
    ukShoeSize: number;
    familyContacts?: unknown;
  };
  const familyContacts = Array.isArray(profile.familyContacts)
    ? profile.familyContacts
      .slice(0, 10)
      .filter((contact): contact is Record<string, unknown> => !!contact && typeof contact === "object")
      .map((contact, index) => ({
        id: typeof contact.id === "string" && contact.id.trim()
          ? contact.id.slice(0, 80)
          : `legacy-${index + 1}`,
        name: typeof contact.name === "string" ? contact.name.trim().slice(0, 80) : "",
        phone: typeof contact.phone === "string" ? contact.phone.trim().slice(0, 24) : "",
      }))
      .filter((contact) => contact.name && contact.phone.length >= 7 && /^[+0-9() .-]+$/.test(contact.phone))
    : [];
  return {
    name: profile.name.trim().slice(0, 80),
    heightCm: Number(profile.heightCm),
    ukShoeSize: Number(profile.ukShoeSize),
    familyContacts,
  };
}

/** Turns a failed profile request into an accurate, readable cause (never a silent success). */
async function profileFailureMessage(response: Response | null, error?: unknown): Promise<string> {
  const base = "Your profile could not be loaded or saved.";
  if (!response) {
    console.error("Profile request failed before reaching the API:", error);
    return `${base} The app could not reach the VisionPath server. Check your connection and retry.`;
  }
  let apiMessage: string | null = null;
  try {
    const body = await response.clone().json() as { error?: unknown };
    if (typeof body.error === "string") apiMessage = body.error;
  } catch {
    apiMessage = null;
  }
  console.error(`Profile request failed: HTTP ${response.status}`, apiMessage);
  if (response.status === 401) return `${base} The server did not accept your sign-in (HTTP 401). Sign out and in again; if it persists, check the Clerk keys.`;
  if (apiMessage === null) return `${base} The API server is not responding (HTTP ${response.status}). Make sure it is running.`;
  if (response.status >= 500) return `${base} The server reported an error (HTTP ${response.status}). Check the database connection and the API terminal log.`;
  return `${base} ${apiMessage}`;
}

export function UserProvider({ children }: { children: ReactNode }) {
  const { isLoaded: authLoaded, isSignedIn, userId } = useAuth();
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    try {
      return normalizeLanguage(localStorage.getItem(LANGUAGE_STORAGE_KEY));
    } catch {
      return "en";
    }
  });
  const [voiceAvailability, setVoiceAvailability] = useState<VoiceAvailability>(() => getVoiceAvailability(language));
  const [user, setUserState] = useState<UserProfile | null>(null);
  const [profileLoading, setProfileLoading] = useState(true);
  const [profileError, setProfileError] = useState<string | null>(null);
  const [profileLoadAttempt, setProfileLoadAttempt] = useState(0);
  const [location, setLocation] = useState<LocationData | null>(null);
  const [locationErrorCode, setLocationErrorCode] = useState<number | null>(null);
  const [locationSyncError, setLocationSyncError] = useState<string | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const watchIdRef = useRef<number | null>(null);
  const retryTimerRef = useRef<number | null>(null);
  const retryAttemptsRef = useRef(0);
  const lastPushRef = useRef(0);
  const languageRef = useRef(language);
  const speechLanguageRef = useRef<LanguageCode | null>(null);
  const locationError = locationErrorCode === null ? null : gpsErrorMessage(locationErrorCode, language);
  languageRef.current = language;

  const retryProfileLoad = useCallback(() => setProfileLoadAttempt((attempt) => attempt + 1), []);

  useEffect(() => {
    if (!authLoaded) {
      setProfileLoading(true);
      return;
    }
    if (!isSignedIn || !userId) {
      setUserState(null);
      setProfileError(null);
      setProfileLoading(false);
      return;
    }

    const controller = new AbortController();
    setProfileLoading(true);
    setProfileError(null);
    void (async () => {
      try {
        const response = await fetch("/api/visionpath/profile", {
          credentials: "same-origin",
          signal: controller.signal,
        });
        if (!response.ok) {
          const message = await profileFailureMessage(response);
          if (controller.signal.aborted) return;
          setProfileError(message);
          setUserState(null);
          return;
        }
        const result = await response.json() as { profile: UserProfile | null };
        if (controller.signal.aborted) return;
        if (result.profile) {
          setUserState(result.profile);
          return;
        }

        // Migrate an existing device-local profile once, after the signed-in server profile is absent.
        let legacy: unknown = null;
        try {
          const stored = localStorage.getItem(LEGACY_PROFILE_KEY);
          if (stored) legacy = JSON.parse(stored);
        } catch {
          legacy = null;
        }
        const migration = legacyProfileForUpload(legacy);
        if (!migration) {
          setUserState(null);
          return;
        }
        const saveResponse = await fetch("/api/visionpath/profile", {
          method: "PUT",
          credentials: "same-origin",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(migration),
          signal: controller.signal,
        });
        if (!saveResponse.ok) {
          const message = await profileFailureMessage(saveResponse);
          if (controller.signal.aborted) return;
          setProfileError(message);
          setUserState(null);
          return;
        }
        const migrated = await saveResponse.json() as UserProfile;
        if (controller.signal.aborted) return;
        setUserState(migrated);
        try {
          localStorage.removeItem(LEGACY_PROFILE_KEY);
          for (let index = localStorage.length - 1; index >= 0; index -= 1) {
            const key = localStorage.key(index);
            if (key?.startsWith("visionpath_live_")) localStorage.removeItem(key);
          }
        } catch {
          // The server copy is authoritative; a failed local cleanup does not undo migration.
        }
      } catch (error) {
        if (!controller.signal.aborted) {
          setProfileError(await profileFailureMessage(null, error));
          setUserState(null);
        }
      } finally {
        if (!controller.signal.aborted) setProfileLoading(false);
      }
    })();
    return () => controller.abort();
  }, [authLoaded, isSignedIn, userId, profileLoadAttempt]);

  const setLanguage = useCallback((nextLanguage: LanguageCode) => {
    setLanguageState(nextLanguage);
    try {
      localStorage.setItem(LANGUAGE_STORAGE_KEY, nextLanguage);
    } catch {
      // The current session still uses the selected language when storage is unavailable.
    }
    setSpeechLanguage(nextLanguage);
    speechLanguageRef.current = nextLanguage;
    setVoiceAvailability(getVoiceAvailability(nextLanguage));
  }, []);

  const setUser = useCallback(async (profile: Omit<UserProfile, "stepLengthM">) => {
    const response = await fetch("/api/visionpath/profile", {
      method: "PUT",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...profile,
        name: profile.name.trim(),
        familyContacts: profile.familyContacts,
      }),
    });
    if (!response.ok) {
      const message = response.status === 400
        ? "Check that your name, height, shoe size and contact phone numbers are valid."
        : (await profileFailureMessage(response)).replace("loaded or saved", "saved");
      throw new Error(message);
    }
    const saved = await response.json() as UserProfile;
    setUserState(saved);
    setProfileError(null);
  }, []);

  const clearUser = useCallback(async () => {
    const response = await fetch("/api/visionpath/profile", {
      method: "DELETE",
      credentials: "same-origin",
    });
    if (!response.ok) throw new Error("Your profile could not be reset. Please try again.");
    setUserState(null);
    setLocation(null);
    setLocationErrorCode(null);
  }, []);

  const startTracking = useCallback(() => {
    if (watchIdRef.current !== null) return;
    if (!navigator.geolocation) {
      setLocationErrorCode(2);
      setIsTracking(false);
      speak(gpsErrorMessage(2, languageRef.current), { priority: "guidance", language: languageRef.current });
      return;
    }
    if (retryTimerRef.current !== null) {
      window.clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
    setLocationErrorCode(null);
    setIsTracking(true);
    try {
      watchIdRef.current = navigator.geolocation.watchPosition(
        (position) => {
          const loc: LocationData = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: position.timestamp,
          };
          if (
            !Number.isFinite(loc.lat) || loc.lat < -90 || loc.lat > 90
            || !Number.isFinite(loc.lng) || loc.lng < -180 || loc.lng > 180
            || !Number.isFinite(loc.accuracy) || loc.accuracy < 0
          ) {
            setLocationErrorCode(2);
            return;
          }
          retryAttemptsRef.current = 0;
          setLocation(loc);
          setLocationErrorCode(null);
          setIsTracking(true);

          const now = Date.now();
          if (userId && now - lastPushRef.current >= 4_000) {
            lastPushRef.current = now;
            void fetch("/api/visionpath/location", {
              method: "POST",
              credentials: "same-origin",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                lat: loc.lat,
                lng: loc.lng,
                accuracy: loc.accuracy,
                timestamp: loc.timestamp,
              }),
            }).then((response) => {
              if (!response.ok) throw new Error("Location sync failed");
              setLocationSyncError(null);
            }).catch(() => {
              setLocationSyncError("Location is available on this device but could not be synced to family sharing.");
            });
          }
        },
        (error) => {
          setLocationErrorCode(error.code);
          setIsTracking(false);
          if (watchIdRef.current !== null) {
            navigator.geolocation.clearWatch(watchIdRef.current);
            watchIdRef.current = null;
          }
          speak(gpsErrorMessage(error.code, languageRef.current), {
            priority: "guidance",
            language: languageRef.current,
          });
          if (error.code !== 1 && retryAttemptsRef.current < 3) {
            retryAttemptsRef.current += 1;
            const delayMs = Math.min(30_000, 2_000 * 2 ** (retryAttemptsRef.current - 1));
            retryTimerRef.current = window.setTimeout(() => {
              retryTimerRef.current = null;
              startTracking();
            }, delayMs);
          }
        },
        { enableHighAccuracy: true, maximumAge: 5_000, timeout: 15_000 },
      );
    } catch {
      setLocationErrorCode(2);
      setIsTracking(false);
      watchIdRef.current = null;
    }
  }, [userId]);

  const stopTracking = useCallback(() => {
    if (watchIdRef.current !== null && navigator.geolocation) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    if (retryTimerRef.current !== null) {
      window.clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
    retryAttemptsRef.current = 0;
    setIsTracking(false);
  }, []);

  useEffect(() => {
    document.documentElement.lang = languageInfo(language).locale;
    if (speechLanguageRef.current !== language) {
      setSpeechLanguage(language);
      speechLanguageRef.current = language;
    }
    setVoiceAvailability(getVoiceAvailability(language));
    return subscribeSpeechStatus((changedLanguage, status) => {
      if (changedLanguage === language) setVoiceAvailability(status);
    });
  }, [language]);

  useEffect(() => () => {
    if (watchIdRef.current !== null && navigator.geolocation) {
      navigator.geolocation.clearWatch(watchIdRef.current);
    }
    if (retryTimerRef.current !== null) window.clearTimeout(retryTimerRef.current);
  }, []);

  return (
    <UserContext.Provider value={{
      user,
      profileLoading,
      profileError,
      retryProfileLoad,
      setUser,
      location,
      locationError,
      locationSyncError,
      startTracking,
      stopTracking,
      isTracking,
      clearUser,
      language,
      setLanguage,
      voiceAvailability,
    }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const ctx = useContext(UserContext);
  if (!ctx) throw new Error("useUser must be used inside UserProvider");
  return ctx;
}
