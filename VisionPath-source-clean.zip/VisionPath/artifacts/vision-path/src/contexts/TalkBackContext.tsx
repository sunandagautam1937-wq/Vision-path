import { createContext, useCallback, useContext, type MouseEvent, type ReactNode, type TouchEvent } from "react";

interface TalkBackContextType {
  registerTap: (label: string, action: () => void) => (event: MouseEvent | TouchEvent) => void;
}

const TalkBackContext = createContext<TalkBackContextType | null>(null);

/**
 * Keep the legacy button wrapper as a plain semantic-button passthrough.
 * Native Android TalkBack owns focus, exploration, and activation; adding an
 * app-managed double-tap gesture here blocks the platform accessibility action.
 */
export function TalkBackProvider({ children }: { children: ReactNode }) {
  const registerTap = useCallback(
    (_label: string, action: () => void) => (_event: MouseEvent | TouchEvent) => action(),
    [],
  );

  return (
    <TalkBackContext.Provider value={{ registerTap }}>
      {children}
    </TalkBackContext.Provider>
  );
}

export function useTalkBack() {
  const ctx = useContext(TalkBackContext);
  if (!ctx) throw new Error("useTalkBack must be inside TalkBackProvider");
  return ctx;
}
