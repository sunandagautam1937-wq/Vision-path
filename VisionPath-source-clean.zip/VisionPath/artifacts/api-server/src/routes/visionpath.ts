import { createHash, randomBytes } from "node:crypto";
import { getAuth } from "@clerk/express";
import {
  and,
  desc,
  eq,
  gt,
  isNull,
} from "drizzle-orm";
import { Router, type RequestHandler } from "express";
import {
  db,
  visionPathLocations,
  visionPathProfiles,
  visionPathShareTokens,
  visionPathSosAlerts,
} from "@workspace/db";
import {
  RecordVisionPathSosBody,
  RevokeVisionPathShareParams,
  SaveVisionPathProfileBody,
  UpdateVisionPathLocationBody,
} from "@workspace/api-zod";

const router = Router();
const rateLimits = new Map<string, { count: number; resetAt: number }>();
const shareLifetimeMs = 30 * 24 * 60 * 60 * 1000;

function authenticatedUserId(req: Parameters<RequestHandler>[0]): string | null {
  return getAuth(req).userId;
}

const requireAuthentication: RequestHandler = (req, res, next) => {
  const userId = authenticatedUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Sign in is required for this action." });
    return;
  }
  res.locals.userId = userId;
  next();
};

function enforceLimit(
  key: string,
  limit: number,
  windowMs: number,
  res: Parameters<RequestHandler>[1],
): boolean {
  const now = Date.now();
  let bucket = rateLimits.get(key);
  if (!bucket || bucket.resetAt <= now) {
    bucket = { count: 0, resetAt: now + windowMs };
    rateLimits.set(key, bucket);
  }
  bucket.count += 1;
  if (rateLimits.size > 5_000) {
    for (const [entryKey, entry] of rateLimits) {
      if (entry.resetAt <= now) rateLimits.delete(entryKey);
    }
    if (rateLimits.size > 5_000) rateLimits.clear();
  }
  if (bucket.count <= limit) return true;
  res.setHeader("Retry-After", String(Math.max(1, Math.ceil((bucket.resetAt - now) / 1000))));
  res.status(429).json({ error: "Too many requests. Please wait and try again." });
  return false;
}

function tokenDigest(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

function calculateStepLengthM(heightCm: number, ukShoeSize: number): number {
  const footLengths: Record<number, number> = {
    1: 22, 2: 22.7, 3: 23.3, 4: 24, 5: 24.6, 6: 25.3, 7: 26,
    8: 26.7, 9: 27.3, 10: 28, 11: 28.7, 12: 29.3, 13: 30,
    14: 30.7, 15: 31.3,
  };
  const lower = Math.floor(ukShoeSize);
  const upper = Math.ceil(ukShoeSize);
  const lowFoot = footLengths[lower] ?? 26;
  const highFoot = footLengths[upper] ?? 26;
  const footLength = lower === upper
    ? lowFoot
    : lowFoot + (ukShoeSize - lower) * (highFoot - lowFoot);
  return ((heightCm * 0.413 + footLength * 3.5) / 2) / 100;
}

router.get("/visionpath/profile", requireAuthentication, async (_req, res) => {
  const userId = res.locals.userId as string;
  const [profile] = await db
    .select()
    .from(visionPathProfiles)
    .where(eq(visionPathProfiles.clerkUserId, userId))
    .limit(1);
  if (!profile) {
    res.json({ profile: null });
    return;
  }
  res.json({
    profile: {
      name: profile.name,
      heightCm: profile.heightCm,
      ukShoeSize: profile.ukShoeSize,
      familyContacts: profile.familyContacts,
      stepLengthM: calculateStepLengthM(profile.heightCm, profile.ukShoeSize),
    },
  });
});

router.put("/visionpath/profile", requireAuthentication, async (req, res) => {
  const parsed = SaveVisionPathProfileBody.strict().safeParse(req.body);
  if (!parsed.success || !parsed.data.name.trim()) {
    res.status(400).json({ error: "Check the name, height, shoe size and contact details." });
    return;
  }
  const userId = res.locals.userId as string;
  const profile = {
    ...parsed.data,
    name: parsed.data.name.trim(),
    familyContacts: parsed.data.familyContacts.map((contact) => ({
      ...contact,
      name: contact.name.trim(),
      phone: contact.phone.trim(),
    })),
  };
  if (profile.familyContacts.some((contact) => !contact.name || !contact.phone)) {
    res.status(400).json({ error: "Each family contact needs a name and phone number." });
    return;
  }
  const [saved] = await db
    .insert(visionPathProfiles)
    .values({
      clerkUserId: userId,
      name: profile.name,
      heightCm: profile.heightCm,
      ukShoeSize: profile.ukShoeSize,
      familyContacts: profile.familyContacts,
      updatedAt: new Date(),
    })
    .onConflictDoUpdate({
      target: visionPathProfiles.clerkUserId,
      set: {
        name: profile.name,
        heightCm: profile.heightCm,
        ukShoeSize: profile.ukShoeSize,
        familyContacts: profile.familyContacts,
        updatedAt: new Date(),
      },
    })
    .returning();
  res.json({
    name: saved.name,
    heightCm: saved.heightCm,
    ukShoeSize: saved.ukShoeSize,
    familyContacts: saved.familyContacts,
    stepLengthM: calculateStepLengthM(saved.heightCm, saved.ukShoeSize),
  });
});

router.delete("/visionpath/profile", requireAuthentication, async (_req, res) => {
  const userId = res.locals.userId as string;
  await db.delete(visionPathProfiles).where(eq(visionPathProfiles.clerkUserId, userId));
  res.status(204).end();
});

router.post("/visionpath/location", requireAuthentication, async (req, res) => {
  const userId = res.locals.userId as string;
  if (!enforceLimit(`location:${userId}`, 1, 2_000, res)) return;
  const parsed = UpdateVisionPathLocationBody.strict().safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Location coordinates or accuracy are invalid." });
    return;
  }
  const { lat, lng, accuracy, timestamp } = parsed.data;
  if (Math.abs(Date.now() - timestamp) > 5 * 60 * 1000) {
    res.status(400).json({ error: "Location timestamp is stale or invalid." });
    return;
  }
  const [profile] = await db
    .select({ clerkUserId: visionPathProfiles.clerkUserId })
    .from(visionPathProfiles)
    .where(eq(visionPathProfiles.clerkUserId, userId))
    .limit(1);
  if (!profile) {
    res.status(409).json({ error: "Complete your profile before sharing location." });
    return;
  }
  const capturedAt = new Date(timestamp);
  await db
    .insert(visionPathLocations)
    .values({ clerkUserId: userId, lat, lng, accuracyM: accuracy, capturedAt })
    .onConflictDoUpdate({
      target: visionPathLocations.clerkUserId,
      set: { lat, lng, accuracyM: accuracy, capturedAt },
    });
  res.json({ ok: true, capturedAt: capturedAt.toISOString() });
});

router.get("/visionpath/shares", requireAuthentication, async (_req, res) => {
  const userId = res.locals.userId as string;
  const shares = await db
    .select({
      id: visionPathShareTokens.id,
      label: visionPathShareTokens.label,
      createdAt: visionPathShareTokens.createdAt,
      expiresAt: visionPathShareTokens.expiresAt,
      revokedAt: visionPathShareTokens.revokedAt,
    })
    .from(visionPathShareTokens)
    .where(eq(visionPathShareTokens.clerkUserId, userId))
    .orderBy(desc(visionPathShareTokens.createdAt))
    .limit(50);
  res.json({ shares });
});

router.post("/visionpath/shares", requireAuthentication, async (_req, res) => {
  const userId = res.locals.userId as string;
  if (!enforceLimit(`shares:${userId}`, 5, 60 * 60 * 1000, res)) return;
  const [profile] = await db
    .select({ clerkUserId: visionPathProfiles.clerkUserId })
    .from(visionPathProfiles)
    .where(eq(visionPathProfiles.clerkUserId, userId))
    .limit(1);
  if (!profile) {
    res.status(409).json({ error: "Complete your profile before creating a share token." });
    return;
  }
  const token = randomBytes(32).toString("base64url");
  const now = new Date();
  const expiresAt = new Date(now.getTime() + shareLifetimeMs);
  const [share] = await db
    .insert(visionPathShareTokens)
    .values({
      clerkUserId: userId,
      tokenHash: tokenDigest(token),
      createdAt: now,
      expiresAt,
    })
    .returning({
      id: visionPathShareTokens.id,
      label: visionPathShareTokens.label,
      createdAt: visionPathShareTokens.createdAt,
      expiresAt: visionPathShareTokens.expiresAt,
      revokedAt: visionPathShareTokens.revokedAt,
    });
  res.status(201).json({ ...share, token });
});

router.delete("/visionpath/shares/:shareId", requireAuthentication, async (req, res) => {
  const userId = res.locals.userId as string;
  const parsed = RevokeVisionPathShareParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Share ID is invalid." });
    return;
  }
  const [share] = await db
    .update(visionPathShareTokens)
    .set({ revokedAt: new Date() })
    .where(and(
      eq(visionPathShareTokens.id, parsed.data.shareId),
      eq(visionPathShareTokens.clerkUserId, userId),
      isNull(visionPathShareTokens.revokedAt),
    ))
    .returning({ id: visionPathShareTokens.id });
  if (!share) {
    res.status(404).json({ error: "Share does not exist or is already revoked." });
    return;
  }
  res.status(204).end();
});

router.get("/visionpath/shared/current", async (req, res) => {
  const bearer = req.get("authorization")?.match(/^Bearer ([A-Za-z0-9_-]{40,64})$/)?.[1];
  if (!bearer) {
    res.status(401).json({ error: "A valid family access token is required." });
    return;
  }
  const now = new Date();
  const [share] = await db
    .select()
    .from(visionPathShareTokens)
    .where(and(
      eq(visionPathShareTokens.tokenHash, tokenDigest(bearer)),
      isNull(visionPathShareTokens.revokedAt),
      gt(visionPathShareTokens.expiresAt, now),
    ))
    .limit(1);
  if (!share) {
    res.status(401).json({ error: "This family access token is invalid, expired or revoked." });
    return;
  }
  if (!enforceLimit(`shared:${share.id}`, 60, 60_000, res)) return;
  const [[profile], [location], [alert]] = await Promise.all([
    db.select().from(visionPathProfiles).where(eq(visionPathProfiles.clerkUserId, share.clerkUserId)).limit(1),
    db.select().from(visionPathLocations).where(eq(visionPathLocations.clerkUserId, share.clerkUserId)).limit(1),
    db.select().from(visionPathSosAlerts)
      .where(and(
        eq(visionPathSosAlerts.clerkUserId, share.clerkUserId),
        gt(visionPathSosAlerts.createdAt, new Date(Date.now() - 10 * 60 * 1000)),
      ))
      .orderBy(desc(visionPathSosAlerts.createdAt))
      .limit(1),
  ]);
  if (!profile) {
    res.status(401).json({ error: "This family access token is no longer valid." });
    return;
  }
  res.json({
    userName: profile.name,
    location: location ? {
      lat: location.lat,
      lng: location.lng,
      accuracy: location.accuracyM,
      timestamp: location.capturedAt.getTime(),
    } : null,
    sos: alert ? {
      userName: profile.name,
      lat: alert.lat,
      lng: alert.lng,
      timestamp: alert.createdAt.getTime(),
      message: alert.message,
      deliveryStatus: "recorded" as const,
    } : null,
  });
});

router.post("/visionpath/sos", requireAuthentication, async (req, res) => {
  const userId = res.locals.userId as string;
  if (!enforceLimit(`sos:${userId}`, 5, 10 * 60 * 1000, res)) return;
  const parsed = RecordVisionPathSosBody.strict().safeParse(req.body);
  if (!parsed.success || ((parsed.data.lat === null) !== (parsed.data.lng === null))) {
    res.status(400).json({ error: "SOS message or coordinates are invalid." });
    return;
  }
  const [profile] = await db
    .select({ clerkUserId: visionPathProfiles.clerkUserId })
    .from(visionPathProfiles)
    .where(eq(visionPathProfiles.clerkUserId, userId))
    .limit(1);
  if (!profile) {
    res.status(409).json({ error: "Complete your profile before recording an SOS." });
    return;
  }
  const [alert] = await db
    .insert(visionPathSosAlerts)
    .values({
      clerkUserId: userId,
      lat: parsed.data.lat,
      lng: parsed.data.lng,
      message: parsed.data.message.trim(),
      deliveryStatus: "recorded",
    })
    .returning({
      id: visionPathSosAlerts.id,
      createdAt: visionPathSosAlerts.createdAt,
    });
  res.status(201).json({ id: alert.id, status: "recorded", createdAt: alert.createdAt.toISOString() });
});

export default router;
