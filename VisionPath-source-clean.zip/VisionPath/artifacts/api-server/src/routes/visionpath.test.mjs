import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { once } from "node:events";
import express from "express";
import { after, before, mock, test } from "node:test";

const authState = { userId: null };
const profileColumn = { table: "profiles", name: "clerkUserId" };
const sosTable = {
  id: { table: "sos", name: "id" },
  createdAt: { table: "sos", name: "createdAt" },
};
const visionPathProfiles = { clerkUserId: profileColumn };
const visionPathLocations = { clerkUserId: { table: "locations" } };
const visionPathShareTokens = {
  clerkUserId: { table: "shares" },
  createdAt: { table: "shares", name: "createdAt" },
};
const visionPathSosAlerts = sosTable;

let profileRow = null;
const db = {
  select() {
    let table;
    const query = {
      from(selectedTable) {
        table = selectedTable;
        return query;
      },
      where() {
        return query;
      },
      async limit() {
        return table === visionPathProfiles && profileRow ? [profileRow] : [];
      },
    };
    return query;
  },
  insert(table) {
    let values;
    const query = {
      values(nextValues) {
        values = nextValues;
        return query;
      },
      onConflictDoUpdate({ set }) {
        values = { ...values, ...set };
        return query;
      },
      async returning() {
        if (table === visionPathProfiles) {
          profileRow = { ...values, clerkUserId: authState.userId };
          return [profileRow];
        }
        if (table === visionPathSosAlerts) {
          return [{
            id: "sos-test-1",
            createdAt: new Date("2026-10-28T12:00:00.000Z"),
          }];
        }
        return [];
      },
    };
    return query;
  },
};

mock.module("@clerk/express", {
  exports: { getAuth: () => ({ userId: authState.userId }) },
});
mock.module("@workspace/db", {
  exports: {
    db,
    visionPathProfiles,
    visionPathLocations,
    visionPathShareTokens,
    visionPathSosAlerts,
  },
});
mock.module("drizzle-orm", {
  exports: {
    and: (...conditions) => conditions,
    desc: (column) => column,
    eq: (column, value) => ({ column, value }),
    gt: (column, value) => ({ column, value }),
    isNull: (column) => ({ column, isNull: true }),
  },
});

const { default: routes } = await import("./index.ts");
const app = express();
app.use(express.json());
app.use("/api", routes);

let server;
let baseUrl;

before(async () => {
  server = app.listen(0, "127.0.0.1");
  await once(server, "listening");
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  if (!server) return;
  await new Promise((resolve, reject) => {
    server.close((error) => (error ? reject(error) : resolve()));
  });
});

function setProfile(profile) {
  profileRow = profile;
}

async function request(path, options) {
  return fetch(new URL(path, baseUrl), options);
}

test("frontend profile and SOS URLs match the API's mounted routes", async () => {
  const [appSource, indexSource, routeSource, userContext, sosPage] = await Promise.all([
    readFile(new URL("../app.ts", import.meta.url), "utf8"),
    readFile(new URL("./index.ts", import.meta.url), "utf8"),
    readFile(new URL("./visionpath.ts", import.meta.url), "utf8"),
    readFile(new URL("../../../../artifacts/vision-path/src/contexts/UserContext.tsx", import.meta.url), "utf8"),
    readFile(new URL("../../../../artifacts/vision-path/src/pages/SOS.tsx", import.meta.url), "utf8"),
  ]);

  const apiPrefix = appSource.match(/app\.use\(\s*["']([^"']+)["']\s*,\s*router\s*\)/)?.[1];
  const profileRoute = routeSource.match(/router\.get\(\s*["']([^"']+)["']\s*,\s*requireAuthentication/)?.[1];
  const sosRoute = routeSource.match(/router\.post\(\s*["']([^"']+\/sos)["']\s*,\s*requireAuthentication/)?.[1];
  const frontendProfilePath = userContext.match(/fetch\(\s*["']([^"']+\/profile)["']/)?.[1];
  const frontendSosPath = sosPage.match(/fetch\(\s*["']([^"']+\/sos)["']/)?.[1];

  assert.equal(apiPrefix, "/api");
  assert.match(indexSource, /router\.use\(visionpathRouter\)/);
  assert.doesNotMatch(indexSource, /router\.use\(\s*["']\/visionpath["']\s*,\s*visionpathRouter/);
  assert.equal(frontendProfilePath, `${apiPrefix}${profileRoute}`);
  assert.equal(frontendSosPath, `${apiPrefix}${sosRoute}`);
});

test("anonymous profile requests return 401 from the mounted profile endpoint", async () => {
  authState.userId = null;
  setProfile(null);

  const response = await request("/api/visionpath/profile");
  assert.equal(response.status, 401);
  assert.deepEqual(await response.json(), {
    error: "Sign in is required for this action.",
  });
});

test("authenticated profile requests return the profile response shape", async () => {
  authState.userId = "user-test-1";
  setProfile({
    clerkUserId: authState.userId,
    name: "Asha",
    heightCm: 170,
    ukShoeSize: 7,
    familyContacts: [{ id: "contact-1", name: "Ravi", phone: "+441234567890" }],
  });

  const response = await request("/api/visionpath/profile");
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.profile.name, "Asha");
  assert.equal(body.profile.heightCm, 170);
  assert.equal(body.profile.ukShoeSize, 7);
  assert.deepEqual(body.profile.familyContacts, [
    { id: "contact-1", name: "Ravi", phone: "+441234567890" },
  ]);
  assert.ok(Number.isFinite(body.profile.stepLengthM));
});

test("authenticated profile saves return the saved profile shape", async () => {
  authState.userId = "user-test-2";
  setProfile(null);

  const response = await request("/api/visionpath/profile", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "Maya",
      heightCm: 165,
      ukShoeSize: 6,
      familyContacts: [{ id: "contact-2", name: "Leela", phone: "+441234567890" }],
    }),
  });

  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.name, "Maya");
  assert.equal(body.heightCm, 165);
  assert.equal(body.ukShoeSize, 6);
  assert.deepEqual(body.familyContacts, [
    { id: "contact-2", name: "Leela", phone: "+441234567890" },
  ]);
  assert.ok(Number.isFinite(body.stepLengthM));
});

test("authenticated SOS requests return the recorded response shape", async () => {
  authState.userId = "user-test-3";
  setProfile({
    clerkUserId: authState.userId,
    name: "Asha",
    heightCm: 170,
    ukShoeSize: 7,
    familyContacts: [],
  });

  const response = await request("/api/visionpath/sos", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      lat: 51.5,
      lng: -0.12,
      message: "I need help.",
    }),
  });

  assert.equal(response.status, 201);
  assert.deepEqual(await response.json(), {
    id: "sos-test-1",
    status: "recorded",
    createdAt: "2026-10-28T12:00:00.000Z",
  });
});
