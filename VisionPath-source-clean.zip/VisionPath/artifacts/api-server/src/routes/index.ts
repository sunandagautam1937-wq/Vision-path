import { Router, type IRouter } from "express";
import healthRouter from "./health";
import visionpathRouter from "./visionpath";

const router: IRouter = Router();

router.use(healthRouter);
router.use(visionpathRouter);

export default router;
