import { Router, type IRouter } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";
import { pool } from "@workspace/db";

const router: IRouter = Router();

router.get("/healthz", (_req, res) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
});

// Readiness: confirms the database connection works (used by `pnpm dev` and for troubleshooting).
router.get("/readyz", async (_req, res) => {
  try {
    await pool.query("select 1");
    res.json({ status: "ready", database: "connected" });
  } catch (error) {
    res.status(503).json({
      status: "not_ready",
      database: "unreachable",
      error: "Database connection failed. Check DATABASE_URL and that PostgreSQL is running.",
      ...(process.env.NODE_ENV !== "production" && error instanceof Error ? { detail: error.message } : {}),
    });
  }
});

export default router;
