import fs from "node:fs";
import path from "node:path";
import express, { type Express } from "express";
import { clerkMiddleware } from "@clerk/express";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { clerkProxyMiddleware, CLERK_PROXY_PATH } from "./middlewares/clerkProxyMiddleware";

const app: Express = express();

app.use((req, res, next) => {
  if (!["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) {
    next();
    return;
  }
  const fetchSite = req.get("sec-fetch-site");
  if (fetchSite && fetchSite !== "same-origin" && fetchSite !== "none") {
    res.status(403).json({ error: "Cross-site requests are not allowed." });
    return;
  }
  const origin = req.get("origin");
  if (!fetchSite && origin) {
    try {
      const expectedHost = req.get("x-forwarded-host")?.split(",")[0].trim() || req.get("host");
      if (!expectedHost || new URL(origin).host !== expectedHost) {
        res.status(403).json({ error: "Cross-site requests are not allowed." });
        return;
      }
    } catch {
      res.status(403).json({ error: "Request origin is invalid." });
      return;
    }
  }
  if (!fetchSite && !origin) {
    res.status(403).json({ error: "Request origin is required." });
    return;
  }
  next();
});

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());
app.use(clerkMiddleware());
app.use(express.json({ limit: "32kb" }));
app.use(express.urlencoded({ extended: true, limit: "32kb" }));

app.use("/api", router);

// Single-link hosting: in production the API also serves the built frontend (same origin, no CORS/proxy needed).
// Build the frontend first: pnpm --filter @workspace/vision-path build. Override the folder with STATIC_DIR.
if (process.env.NODE_ENV === "production") {
  const staticDir = process.env.STATIC_DIR ?? path.resolve(process.cwd(), "..", "vision-path", "dist", "public");
  if (fs.existsSync(path.join(staticDir, "index.html"))) {
    app.use(express.static(staticDir, { index: false, maxAge: "1h" }));
    app.use((req, res, next) => {
      if (req.method !== "GET" || req.path.startsWith("/api")) {
        next();
        return;
      }
      res.sendFile(path.join(staticDir, "index.html"));
    });
  } else {
    logger.warn({ staticDir }, "Frontend build not found; serving the API only.");
  }
}

app.use((error: unknown, _req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (res.headersSent) {
    next(error);
    return;
  }
  logger.error(
    {
      errorName: error instanceof Error ? error.name : "UnknownError",
      // Details only outside production, so local debugging shows e.g. missing tables or DB errors.
      ...(process.env.NODE_ENV !== "production" && error instanceof Error ? { errorMessage: error.message } : {}),
    },
    "Unhandled API request error",
  );
  res.status(500).json({ error: "The service could not complete this request. Please try again." });
});

export default app;
