import { useEffect, useState, type CSSProperties, type ReactNode } from "react";
import "./_group.css";

type Language = "en" | "hi";
type LanguageItem = { code: Language; name: string };
type VoiceAvailability = "available" | "checking" | "unavailable" | "unsupported" | "error";

const SUPPORTED_LANGUAGES: LanguageItem[] = [
  { code: "en", name: "English" },
  { code: "hi", name: "Hindi" },
];

function useUser() {
  const [language, setLanguage] = useState<Language>("en");
  return { language, setLanguage, voiceAvailability: "checking" as VoiceAvailability };
}

function languageInfo(language: Language) {
  return SUPPORTED_LANGUAGES.find((item) => item.code === language) ?? SUPPORTED_LANGUAGES[0];
}

function translate(
  _language: Language,
  key: string,
  values?: Record<string, string>,
) {
  if (key === "languageSelectorLabel") return "Voice guidance language";
  if (key === "languageSelected") return `Voice guidance set to ${values?.language ?? "English"}.`;
  if (key === "voiceAvailable") return `Voice guidance is available in ${values?.language ?? "English"}.`;
  if (key === "voiceChecking") return `Checking for a speech voice in ${values?.language ?? "English"}.`;
  if (key === "voiceUnavailable") return `No speech voice found for ${values?.language ?? "English"}.`;
  if (key === "speechUnsupported") return "Speech is not supported in this browser.";
  return "Speech could not be started.";
}

function speak(_text: string, _options: {
  priority: string;
  language: Language;
  fallbackToSystemVoice?: boolean;
}) {}

function stopSpeaking() {}

function Link({
  href,
  className,
  style,
  children,
}: {
  href: string;
  className: string;
  style: CSSProperties;
  children: ReactNode;
}) {
  return (
    <a href={href} className={className} style={style} onClick={(event) => event.preventDefault()}>
      {children}
    </a>
  );
}

export function Current() {
  const { language, setLanguage, voiceAvailability } = useUser();
  const [languageMessage, setLanguageMessage] = useState("");

  useEffect(() => {
    if (!languageMessage) return;
    const timer = window.setTimeout(() => setLanguageMessage(""), 4_000);
    return () => window.clearTimeout(timer);
  }, [languageMessage]);

  return (
    <main
      className="min-h-screen flex flex-col items-center justify-center px-6"
      style={{ background: "linear-gradient(135deg, #0a0a0a 0%, #1a1200 50%, #0a0a0a 100%)" }}
    >
      <div className="w-full max-w-sm text-center">
        <div
          className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-3xl"
          style={{ background: "linear-gradient(135deg, #c8960c, #f0c040)" }}
          aria-hidden="true"
        >
          <svg width="52" height="52" viewBox="0 0 24 24" fill="none">
            <path d="M10 3C10 3 7 3 7 6c0 2.5 2.5 2.5 3.5 1.5M10.5 7.5l5 13" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
            <circle cx="15.5" cy="21.2" r="1.3" fill="white" />
          </svg>
        </div>
        <h1 className="text-4xl font-bold" style={{ color: "#f0c040" }}>VisionPath</h1>
        <p className="mb-6 mt-2 text-xs tracking-widest" style={{ color: "#9a8060" }}>MOBILITY COCKPIT</p>
        <p className="mb-8 text-base leading-relaxed" style={{ color: "#d0c0a0" }}>
          Step-by-step pedestrian guidance, voice directions, and family location sharing.
        </p>

        <section className="mb-5 rounded-2xl p-4 text-left" style={{ background: "#1a1400", border: "1px solid #3a2800" }}>
          <label htmlFor="landing-language" className="mb-2 block text-sm font-semibold" style={{ color: "#f0c040" }}>
            {translate(language, "languageSelectorLabel")}
          </label>
          <select
            id="landing-language"
            value={language}
            onChange={(event) => {
              const nextLanguage = event.target.value as Language;
              setLanguage(nextLanguage);
              setLanguageMessage(translate(nextLanguage, "languageSelected", {
                language: languageInfo(nextLanguage).name,
              }));
            }}
            className="min-h-14 w-full rounded-xl px-3 py-3 text-base font-semibold focus-visible:ring-2 focus-visible:ring-yellow-300"
            style={{ background: "#0a0a00", border: "2px solid #c8960c", color: "#f0e0a0" }}
            aria-describedby="landing-voice-status"
          >
            {SUPPORTED_LANGUAGES.map((item) => (
              <option key={item.code} value={item.code}>{item.name}</option>
            ))}
          </select>
          <p id="landing-voice-status" role="status" aria-live="polite" className="mt-2 text-xs" style={{ color: "#c0a080" }}>
            {languageMessage
              || (voiceAvailability === "available" && translate(language, "voiceAvailable", { language: languageInfo(language).name }))
              || (voiceAvailability === "checking" && translate(language, "voiceChecking", { language: languageInfo(language).name }))
              || (voiceAvailability === "unavailable" && translate(language, "voiceUnavailable", { language: languageInfo(language).name }))
              || (voiceAvailability === "unsupported" && translate(language, "speechUnsupported"))
              || (voiceAvailability === "error" && translate(language, "speechError"))}
          </p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                speak(translate(language, "languageSelected", { language: languageInfo(language).name }), {
                  priority: "critical",
                  language,
                  fallbackToSystemVoice: true,
                });
                setLanguageMessage("Voice test requested. If silent, check Android Text-to-speech and media volume.");
              }}
              className="min-h-12 rounded-xl px-3 py-2 text-sm font-semibold focus-visible:outline focus-visible:outline-2 focus-visible:outline-white"
              style={{ background: "#2b2208", border: "1px solid #c8960c", color: "#f0c040" }}
            >
              Test voice
            </button>
            <button
              type="button"
              onClick={() => {
                stopSpeaking();
                setLanguageMessage("Speech stopped.");
              }}
              className="min-h-12 rounded-xl px-3 py-2 text-sm font-semibold focus-visible:outline focus-visible:outline-2 focus-visible:outline-white"
              style={{ background: "#2b2208", border: "1px solid #c8960c", color: "#f0c040" }}
            >
              Stop voice
            </button>
          </div>
          {voiceAvailability === "unavailable" && language !== "en" && (
            <button
              type="button"
              onClick={() => {
                setLanguage("en");
                setLanguageMessage(translate("en", "languageSelected", { language: languageInfo("en").name }));
                speak(translate("en", "languageSelected", { language: languageInfo("en").name }), {
                  priority: "critical", language: "en", fallbackToSystemVoice: true,
                });
              }}
              className="mt-3 min-h-12 w-full rounded-xl px-3 py-2 text-sm font-semibold focus-visible:outline focus-visible:outline-2 focus-visible:outline-white"
              style={{ background: "#c8960c", color: "#1a1000" }}
            >
              Use English voice
            </button>
          )}
        </section>

        <Link
          href="/sign-up"
          className="block min-h-14 w-full rounded-2xl py-4 text-lg font-semibold"
          style={{ background: "linear-gradient(135deg, #c8960c, #f0c040)", color: "#1a1000" }}
        >
          Create account
        </Link>
        <Link
          href="/sign-in"
          className="mt-3 block min-h-14 w-full rounded-2xl border py-4 text-base font-semibold"
          style={{ background: "#1a1400", borderColor: "#3a2800", color: "#f0c040" }}
        >
          Sign in
        </Link>
        <p className="mt-4 text-xs leading-relaxed" style={{ color: "#9a8060" }}>
          Location sharing and saved profile data require an account. You control family access and can revoke it.
        </p>
      </div>
    </main>
  );
}
