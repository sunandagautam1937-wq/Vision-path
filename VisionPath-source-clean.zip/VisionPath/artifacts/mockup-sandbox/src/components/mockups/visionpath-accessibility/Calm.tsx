import { useEffect, useState } from "react";
import "./_group.css";

type Language = "en" | "hi";

const languageNames: Record<Language, string> = {
  en: "English",
  hi: "Hindi",
};

function stopSpeech() {
  if ("speechSynthesis" in window) window.speechSynthesis.cancel();
}

function speak(text: string, language: Language, onEnd?: () => void) {
  if (!("speechSynthesis" in window)) return false;
  stopSpeech();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = language === "hi" ? "hi-IN" : "en-US";
  utterance.rate = 0.92;
  if (onEnd) utterance.onend = onEnd;
  window.speechSynthesis.speak(utterance);
  return true;
}

export function Calm() {
  const [language, setLanguage] = useState<Language>("en");
  const [status, setStatus] = useState("Voice guidance is ready to test.");

  useEffect(() => () => stopSpeech(), []);

  const testVoice = () => {
    const message = language === "hi"
      ? "आवाज़ मार्गदर्शन हिंदी में सेट है।"
      : "Voice guidance is set to English.";
    if (speak(message, language)) {
      setStatus(`Playing a short ${languageNames[language]} voice test.`);
    } else {
      setStatus("Speech is not available in this browser.");
    }
  };

  const stopVoice = () => {
    stopSpeech();
    setStatus("Speech stopped.");
  };

  const readSummary = () => {
    const summary = `Welcome to VisionPath. Get step-by-step pedestrian guidance with spoken directions and optional family location sharing. Choose a voice language, test or stop voice guidance, create an account, or sign in. Location sharing and saved profile data require an account. You control family access and can revoke it.`;
    if (speak(summary, "en")) {
      setStatus("Reading the welcome summary aloud.");
    } else {
      setStatus("Speech is not available in this browser.");
    }
  };

  const keepHere = (event: React.MouseEvent<HTMLAnchorElement>) => {
    event.preventDefault();
    setStatus("This prototype keeps account navigation on this screen.");
  };

  return (
    <main className="vp-calm">
      <style>{`
        .vp-calm {
          --ink: #213c38;
          --ink-soft: #526d66;
          --muted: #667d75;
          --paper: #f7f6ef;
          --paper-deep: #eeefe5;
          --sage: #dce8dc;
          --sage-deep: #b9d0c1;
          --teal: #245e56;
          --teal-dark: #184b45;
          --line: #d4dfd4;
          --clay: #aa684c;
          min-height: 100dvh;
          padding: max(22px, env(safe-area-inset-top)) 22px max(24px, env(safe-area-inset-bottom));
          color: var(--ink);
          background:
            radial-gradient(ellipse at 88% 3%, rgba(218, 232, 219, .72), transparent 32%),
            var(--paper);
          font-family: "Avenir Next", Avenir, "Segoe UI", sans-serif;
          -webkit-font-smoothing: antialiased;
        }
        .vp-calm *, .vp-calm *::before, .vp-calm *::after { box-sizing: border-box; }
        .vp-shell { width: min(100%, 452px); margin: 0 auto; }
        .vp-topline { display: flex; justify-content: space-between; align-items: center; margin-bottom: 21px; }
        .vp-brand { display: inline-flex; align-items: center; gap: 10px; color: var(--ink); }
        .vp-brand-mark {
          width: 37px; height: 37px; display: grid; place-items: center; border-radius: 13px;
          background: var(--teal); color: #f7f6ef;
        }
        .vp-brand-name { font-family: Georgia, "Times New Roman", serif; font-size: 20px; letter-spacing: -.45px; }
        .vp-summary-button {
          display: inline-flex; align-items: center; gap: 7px; min-height: 44px; padding: 8px 11px;
          border: 1px solid var(--line); border-radius: 999px; background: rgba(255,255,255,.44);
          color: var(--teal-dark); font: 600 12px/1.2 inherit; cursor: pointer;
        }
        .vp-summary-button svg { flex: none; }
        .vp-art {
          position: relative; height: 184px; overflow: hidden; margin-bottom: 24px;
          border: 1px solid rgba(145, 171, 151, .32); border-radius: 26px;
          background: linear-gradient(137deg, #e7eee3 0%, #d5e5d7 56%, #dce9e4 100%);
        }
        .vp-art::before, .vp-art::after {
          content: ""; position: absolute; border: 1px solid rgba(77, 125, 105, .13); border-radius: 50%;
        }
        .vp-art::before { width: 216px; height: 216px; top: -102px; right: -41px; }
        .vp-art::after { width: 286px; height: 286px; top: -137px; right: -75px; }
        .vp-art-caption {
          position: absolute; top: 21px; left: 21px; z-index: 1; color: #45685d;
          font-size: 10px; font-weight: 700; letter-spacing: 1.6px; text-transform: uppercase;
        }
        .vp-route { position: absolute; inset: 0; width: 100%; height: 100%; }
        .vp-eyebrow { margin: 0 0 8px; color: var(--clay); font-size: 11px; font-weight: 700; letter-spacing: 1.55px; text-transform: uppercase; }
        .vp-title {
          max-width: 390px; margin: 0; color: var(--ink);
          font: 400 clamp(35px, 9vw, 45px)/1.06 Georgia, "Times New Roman", serif;
          letter-spacing: -1.5px;
        }
        .vp-intro { max-width: 380px; margin: 12px 0 21px; color: var(--ink-soft); font-size: 15px; line-height: 1.55; }
        .vp-control-card {
          padding: 16px; border: 1px solid var(--line); border-radius: 20px;
          background: rgba(255, 255, 255, .58); box-shadow: 0 8px 28px rgba(40, 70, 56, .045);
        }
        .vp-card-heading { display: flex; align-items: flex-start; gap: 11px; margin-bottom: 13px; }
        .vp-sound-mark {
          display: grid; place-items: center; width: 36px; height: 36px; flex: none;
          border-radius: 12px; background: #e4eee5; color: var(--teal);
        }
        .vp-card-heading h2 { margin: 1px 0 3px; color: var(--ink); font-size: 14px; font-weight: 700; }
        .vp-card-heading p { margin: 0; color: var(--muted); font-size: 12px; line-height: 1.4; }
        .vp-label { display: block; margin: 0 0 7px; color: var(--ink-soft); font-size: 12px; font-weight: 650; }
        .vp-select {
          display: block; width: 100%; min-height: 52px; padding: 0 13px; border: 1px solid #a9c0b0;
          border-radius: 13px; background: #fffefa; color: var(--ink); font: 600 15px inherit;
        }
        .vp-voice-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 9px; margin-top: 10px; }
        .vp-button {
          min-height: 48px; padding: 10px 12px; border: 1px solid #b9ccbd; border-radius: 13px;
          background: #edf3ec; color: var(--teal-dark); font: 650 13px inherit; cursor: pointer;
          transition: transform .16s ease, opacity .16s ease;
        }
        .vp-button:hover, .vp-summary-button:hover, .vp-secondary:hover { opacity: .88; }
        .vp-button:active, .vp-primary:active { transform: translateY(1px); }
        .vp-status { min-height: 19px; margin: 10px 1px 0; color: var(--muted); font-size: 11px; line-height: 1.45; }
        .vp-summary-note {
          display: flex; align-items: flex-start; gap: 9px; margin: 13px 1px 0; padding-top: 12px;
          border-top: 1px solid #e3e9df; color: #4f6b63; font-size: 11px; line-height: 1.45;
        }
        .vp-summary-note svg { flex: none; margin-top: 1px; color: var(--teal); }
        .vp-account { margin-top: 17px; }
        .vp-primary, .vp-secondary {
          display: flex; align-items: center; justify-content: center; width: 100%; min-height: 54px;
          border-radius: 15px; text-decoration: none; font-size: 15px; font-weight: 700;
          transition: transform .16s ease, opacity .16s ease;
        }
        .vp-primary { background: var(--teal); color: #fffdf6; box-shadow: 0 7px 17px rgba(36, 94, 86, .16); }
        .vp-secondary { margin-top: 9px; border: 1px solid #b7cbbd; background: rgba(255,255,255,.4); color: var(--teal-dark); }
        .vp-privacy { margin: 13px auto 0; max-width: 405px; color: #526d65; font-size: 11px; line-height: 1.55; text-align: center; }
        .vp-privacy strong { color: #35574e; }
        .vp-calm button:focus-visible, .vp-calm select:focus-visible, .vp-calm a:focus-visible {
          outline: 3px solid #a65c3b; outline-offset: 3px;
        }
        @media (min-width: 600px) {
          .vp-calm { padding-top: 30px; padding-bottom: 34px; }
          .vp-shell { padding: 14px 0; }
          .vp-art { height: 202px; margin-bottom: 27px; }
          .vp-intro { margin-bottom: 24px; }
        }
        @media (prefers-reduced-motion: reduce) {
          .vp-calm *, .vp-calm *::before, .vp-calm *::after { transition-duration: .01ms !important; }
        }
      `}</style>

      <div className="vp-shell">
        <header className="vp-topline">
          <div className="vp-brand" aria-label="VisionPath">
            <span className="vp-brand-mark" aria-hidden="true">
              <svg width="23" height="23" viewBox="0 0 24 24" fill="none">
                <path d="M7 4.5c3.2 0 3.2 3.1 1.2 4.3l4.2 10.7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
                <circle cx="14.2" cy="20" r="1.4" fill="currentColor" />
                <path d="M15.2 6.4c1.5.8 2.6 2.1 3.2 3.8M16 3.8c2.4 1.2 4.2 3.2 5 5.7" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" opacity=".78" />
              </svg>
            </span>
            <span className="vp-brand-name">VisionPath</span>
          </div>
          <button className="vp-summary-button" type="button" onClick={readSummary} aria-label="Read welcome screen summary aloud">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M4 10v4h4l5 4V6l-5 4H4Z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
              <path d="M16 9a5 5 0 0 1 0 6m2.5-8.5a8.5 8.5 0 0 1 0 11" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
            </svg>
            Read summary
          </button>
        </header>

        <div className="vp-art" aria-hidden="true">
          <span className="vp-art-caption">A little more ease, step by step</span>
          <svg className="vp-route" viewBox="0 0 430 184" fill="none">
            <path d="M-8 152C58 149 74 117 134 120c53 3 47-42 103-40 46 1 51 37 103 22 25-7 48-26 95-25" stroke="#f7f6ef" strokeWidth="23" strokeLinecap="round" opacity=".78" />
            <path d="M-8 152C58 149 74 117 134 120c53 3 47-42 103-40 46 1 51 37 103 22 25-7 48-26 95-25" stroke="#6e9580" strokeWidth="2.5" strokeDasharray="2 7" strokeLinecap="round" />
            <circle cx="73" cy="136" r="14" fill="#f8f6ed" />
            <circle cx="73" cy="136" r="7" fill="#356c5c" />
            <circle cx="340" cy="103" r="19" fill="#f7f6ef" />
            <circle cx="340" cy="103" r="11" fill="#bd7959" />
            <path d="M336.5 103h7M340 99.5v7" stroke="white" strokeWidth="1.6" strokeLinecap="round" />
            <path d="M228 68c6-8 12-12 21-14" stroke="#759783" strokeWidth="1.6" strokeLinecap="round" opacity=".75" />
            <circle cx="251" cy="52" r="3" fill="#759783" opacity=".75" />
            <path d="M286 136c8-8 15-12 25-13" stroke="#759783" strokeWidth="1.6" strokeLinecap="round" opacity=".55" />
          </svg>
        </div>

        <section aria-labelledby="welcome-title">
          <p className="vp-eyebrow">Your way, at your pace</p>
          <h1 className="vp-title" id="welcome-title">A clearer path through the day.</h1>
          <p className="vp-intro">
            Step-by-step pedestrian guidance, spoken directions, and optional family location sharing—all in one thoughtful companion.
          </p>
        </section>

        <section className="vp-control-card" aria-labelledby="voice-heading">
          <div className="vp-card-heading">
            <span className="vp-sound-mark" aria-hidden="true">
              <svg width="19" height="19" viewBox="0 0 24 24" fill="none">
                <path d="M4 10v4h4l5 4V6l-5 4H4Z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
                <path d="M16 9a5 5 0 0 1 0 6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
              </svg>
            </span>
            <div>
              <h2 id="voice-heading">Make the voice yours</h2>
              <p>Choose a language and try a short sample.</p>
            </div>
          </div>
          <label className="vp-label" htmlFor="vp-language">Voice guidance language</label>
          <select
            className="vp-select"
            id="vp-language"
            value={language}
            onChange={(event) => {
              const next = event.target.value as Language;
              setLanguage(next);
              setStatus(`Voice guidance set to ${languageNames[next]}.`);
            }}
            aria-describedby="vp-live-status"
          >
            <option value="en">English</option>
            <option value="hi">Hindi</option>
          </select>
          <div className="vp-voice-actions">
            <button className="vp-button" type="button" onClick={testVoice}>Test voice</button>
            <button className="vp-button" type="button" onClick={stopVoice}>Stop voice</button>
          </div>
          <p className="vp-status" id="vp-live-status" role="status" aria-live="polite">{status}</p>
          <div className="vp-summary-note">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M12 3v18M5 7h14M7 7c0 4-2 6-4 7m14-7c0 4 2 6 4 7M7 7l-3 7h6L7 7Zm10 0-3 7h6l-3-7Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round" />
            </svg>
            <span>Android TalkBack uses your phone’s accessibility settings. This screen is built with standard, screen-reader-friendly controls.</span>
          </div>
        </section>

        <nav className="vp-account" aria-label="Account options">
          <a className="vp-primary" href="/sign-up" onClick={keepHere}>Create account</a>
          <a className="vp-secondary" href="/sign-in" onClick={keepHere}>Sign in</a>
        </nav>
        <p className="vp-privacy">
          <strong>Your location stays yours.</strong> Location sharing and saved profile data require an account. You choose who in your family can access your location, and you can revoke access.
        </p>
      </div>
    </main>
  );
}
