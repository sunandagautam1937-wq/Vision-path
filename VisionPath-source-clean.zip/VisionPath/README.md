# VisionPath — pedestrian mobility assistance prototype

VisionPath is a web application prototype for accessible walking navigation, camera-based object recognition, SOS request recording, and family location sharing.

> **Safety notice:** This prototype is not a certified mobility aid or emergency-response service. Object detection can miss or misclassify hazards and cannot reliably estimate collision distance. Do not rely on it as your only navigation aid. SOS recording does not automatically contact emergency services or deliver SMS/WhatsApp messages.

## Replit setup

1. Import/upload this repository ZIP into a new Replit Node.js project, preserving the folder structure.
2. This is a **pnpm workspace**. Run `pnpm install` from the repository root; do not use `npm install` or `yarn install` because the root preinstall deliberately rejects them.
3. Configure the required deployment secrets before expecting authenticated features to work:
   - `VITE_CLERK_PUBLISHABLE_KEY` — a Clerk **publishable** key for the web app.
   - `DATABASE_URL` — PostgreSQL connection string for the API server.
   - Configure the API server's Clerk verification/proxy settings according to the deployment setup and the variables in `artifacts/vision-path/.env.example`.
4. From the repository root, start the workspace app using `pnpm --filter @workspace/vision-path dev` (or run `pnpm dev` in `artifacts/vision-path` after workspace installation). The Vite server binds to `0.0.0.0`; use the Replit web preview.
5. If Replit asks for a run command, use `pnpm --filter @workspace/vision-path dev`. API-backed profile/location/SOS features also require the API server and a provisioned/migrated database; starting only Vite is not the same as running the full stack.
6. Open the preview over HTTPS and grant camera/location permissions when prompted.

## Test commands

From the repository root, after dependencies install:

```sh
pnpm --filter @workspace/vision-path test
pnpm --filter @workspace/vision-path typecheck
pnpm --filter @workspace/vision-path build
```

The route/language utility tests can also run without package installation on Node.js 22:

```sh
node --experimental-strip-types --test artifacts/vision-path/src/utils/*.test.mjs
```

## Known verification limits

The included repair report records what has and has not been checked. A successful ZIP check or utility unit tests do not establish that a production build, backend/database, Clerk login, camera inference, live GPS rerouting, or emergency-contact delivery works. Those need the configured Replit environment and device-level tests.

## TalkBack vs. VisionPath speech

Android TalkBack is an operating-system screen reader; it is separate from the browser `speechSynthesis` used for route/object narration. If TalkBack is silent across Android Settings as well as this app, troubleshoot Android's TalkBack service, text-to-speech engine/voice data, and audio output first. A website cannot repair the OS screen-reader service.
